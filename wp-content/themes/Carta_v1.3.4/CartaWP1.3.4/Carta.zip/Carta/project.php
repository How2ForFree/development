<?php
/*
	Project View
*/

get_header();

$size = array(700, ca_projects_ai_height);

switch (ca_projects_view) {
	case 'Default Template':
		$v = 1;
	break;
	case 'Left Sidebar':
		$v = 2;
	break;
	case 'Blank Page (No Sidebar)':
		$v = 3;
		$size[0] = 940;
	break;
}
?>

<?php if ($v == 2) : ?>
	<!-- side column -->
	<div id="sidebar" class="col-s left">
		
		<?php get_sidebar(); ?>
		
	<!-- closing: side column (right) -->
	</div>
<?php endif; ?>

	<!-- main column -->
	<div class="type <?php if ($v == 1 || $v == 2) echo 'col-xl '; if ($v == 2) echo 'right'; ?>">
		
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<?php
		/* Auto Project Image */
		if (ca_projects_ai) {
			$vic = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full', true);
			echo '<img src="'.timthumb.'?q=100&amp;w='.$size[0].'&amp;h='.$size[1].'&amp;zc=1&amp;src='.$vic[0].'" alt="'.get_the_title().'" />';
			echo '<div class="space"></div>';
		}
		?>

		<?php the_content(); ?>
							
		<?php endwhile; endif; ?>
		
	<!-- closing: main column (left) -->
	</div>

<?php if ($v == 1) : ?>
	<!-- side column -->
	<div id="sidebar" class="col-s">
		
		<?php get_sidebar(); ?>
		
	<!-- closing: side column (right) -->
	</div>
<?php endif; ?>

<?php get_footer(); ?>