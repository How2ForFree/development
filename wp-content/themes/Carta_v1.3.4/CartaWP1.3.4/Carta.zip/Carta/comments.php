<?php
/*
	Comment Form & Comments Listing
*/

function comments($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;
	switch ($comment->comment_type) :
		case '' :
?>
	
	<li id="comment-<?php comment_ID(); ?>">
			
		<div class="align-left">
			<?php echo get_avatar($comment, 60); ?>
		</div>
		
<?php if ($comment->comment_approved == '0') : ?>
		<em><?php _e('Your comment is awaiting moderation.', 'carta'); ?></em>
<?php endif; ?>

		<div class="comment">
			<span class="meta">
				<cite>
					<?php printf(__('%s on', 'carta'), sprintf('%s', get_comment_author_link())); ?>
					<a href="<?php echo esc_url(get_comment_link($comment->comment_ID)); ?>">
						<?php printf(__('%1$s at %2$s', 'carta'), get_comment_date(), get_comment_time()); ?>
					</a>
					<?php edit_comment_link(__('(Edit)', 'carta'), ' '); ?>
				</cite>
<?php if (get_the_author_meta('ID') == $comment->user_id) : ?>
					<span class="author-mark"><?php _e('Author', 'carta'); ?></span>
<?php endif; ?>
				<?php comment_reply_link(array_merge($args, array( 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
			</span>
			
			<div class="text">
				<?php comment_text(); ?>
			</div>
		</div>
		
	</li>
	
<?php
		break;
		case 'pingback' :
		case 'trackback' :
?>
	
	<li class="post pingback">
		<p><?php _e('Pingback:', 'carta'); ?><?php comment_author_link(); ?><?php edit_comment_link(__('(Edit)', 'carta'), ' '); ?></p>
	</li>
	
<?php
		break;		
	endswitch;
}
?>

<div id="comments">

<?php if (post_password_required()) : ?>
	<p><?php _e('This post is password protected. Enter the password to view any comments.', 'carta'); ?></p>
<?php return; endif; ?>

<?php if (have_comments()) : ?>
		
		<div class="header">
			<h3><?php comments_number(__('No Responses', 'carta'), __('One Response', 'carta'), __('% Responses', 'carta') );?></h3>
		</div>
	
		<ol class="commentlist">
			<?php wp_list_comments(array('callback' => 'comments')); ?>
		</ol>
	
<?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
		<p><?php previous_comments_link('&larr; '.__('Older Comments', 'carta')); ?><?php next_comments_link(__('Newer Comments', 'carta').' &rarr;'); ?></p>
<?php endif; ?>
<?php else : if (!comments_open()) : ?>
	
		<p class="nocomments"><?php _e('Comments are closed.', 'carta'); ?></p>
		
<?php endif; ?>
	
<?php endif; ?>

<?php if ($post->comment_status == 'open') : ?>

<div class="header">
	<h3><?php comment_form_title(__('Leave a Reply', 'carta'), __('Leave a Reply to %s', 'carta')); ?></h3>
</div>

<div id="respond">	
	
<?php if (get_option('comment_registration') && !$user_ID) : ?>
		<p><?php _e('You must be logged in to post a comment.', 'carta'); ?> <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php echo urlencode(get_permalink()); ?>"><?php _e('Login', 'carta'); ?></a></p>
<?php else : ?>
	
	<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
	
<?php if ($user_ID) : ?>
		<p><?php _e('Logged in as', 'carta'); ?> <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Log out of this account"><?php _e('Log out', 'carta'); ?> &raquo;</a></p>
<?php else : ?>
		<p>
			<input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" class="input-text" tabindex="1" />
			<label for="author"><?php if ($req) : ?><span class="red">*</span><?php endif; ?> <?php _e('Name', 'carta'); ?></label>
		</p>
		<p>
			<input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" class="input-text" tabindex="2" />
			<label for="email"><?php if ($req) : ?><span class="red">*</span><?php endif; ?> <?php _e('Mail', 'carta'); ?> <small><?php _e('(will not be published)', 'carta'); ?></small></label>
		</p>
		<p>
			<input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" class="input-text" tabindex="3" />
			<label for="url"><?php _e('Website', 'carta'); ?></label>
		</p>
<?php endif; ?>
		
	<p>
		<textarea name="comment" cols="70%" rows="10" tabindex="4"></textarea>
	</p>
	
	<?php /*<p><strong>XHTML:</strong> You can use these tags: <code><?php echo allowed_tags(); ?></code></p>*/ ?>
	
	<p>
		<input name="submit" type="submit" id="submit" tabindex="5" value="<?php _e('Submit Comment', 'carta'); ?>" />
		<?php comment_id_fields(); ?>
		<small><?php cancel_comment_reply_link(); ?></small>
	</p>
	
	<?php do_action('comment_form', $post->ID); ?>
	
	</form>
	
<?php endif; ?>
	</div>
<?php endif; ?>
</div>
