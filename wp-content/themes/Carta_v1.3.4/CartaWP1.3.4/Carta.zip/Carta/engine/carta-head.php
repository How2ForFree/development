<?php
/*
	jQuery & Plugins
*/

function carta_seo() {
	if (ca_seo) : ?>
	<!-- seo -->
	<meta name="robots" content="<?php echo ca_seo_robots ?>" />
	<meta name="description" content="<?php echo ca_seo_description ?>" />
	<meta name="keywords" content="<?php echo ca_seo_keywords ?>" />
<?php endif;
}

function carta_incl_jquery() {
	if (!ca_disable_jquery) :
if (ca_jquery_local) : ?>
	<!-- jquery -->
	<script type="text/javascript" src="<?php echo templatedir ?>/js/jquery-1.5.min.js"></script>
<?php else : ?>
	<!-- jquery -->
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.0/jquery.min.js"></script>
<?php endif;
	endif;
}

function carta_incl_plugins() {
if (!ca_disable_wb) : ?>
	<!-- carta plugins -->
	<script type="text/javascript" src="<?php echo templatedir ?>/js/jquery.carta.js"></script>
<?php endif; ?>
<?php if (is_front_page() && ca_slider == 'Nivo Slider' && !ca_disable_nivoslider) : ?>
	<!-- nivo slider -->
	<script type="text/javascript" src="<?php echo templatedir ?>/js/jquery.nivo.slider.pack.js"></script>
<?php endif; ?>
<?php if (!ca_disable_cufon) : ?>
	<!-- cufon -->
	<script type="text/javascript" src="<?php echo templatedir ?>/js/cufon-yui.js"></script>
	<script type="text/javascript" src="<?php echo templatedir ?>/js/fonts/<?php echo ca_cufon_font; ?>"></script>
	<script type="text/javascript">
	Cufon.replace('<?php echo ca_cufon_selectors; ?>');
	</script>
<?php endif; ?>
<?php if (!ca_disable_jeasing) : ?>
	<!-- jquery easing -->
	<script type="text/javascript" src="<?php echo templatedir ?>/js/jquery.easing.1.3.js"></script>
<?php endif; ?>
<?php if (!ca_disable_superfish) : ?>
	<!-- superfish dropdown -->
	<script type="text/javascript" src="<?php echo templatedir ?>/js/superfish.js"></script>
<?php endif; ?>
<?php if (!ca_disable_fancybox) : ?>
	<!-- fancybox lightbox -->
	<script type="text/javascript" src="<?php echo templatedir ?>/js/jquery.fancybox-1.3.4.pack.js"></script>
<?php endif; ?>
<?php if (!ca_disable_init) : ?>
	<script type="text/javascript" src="<?php echo templatedir ?>/js/init.js"></script>
<?php endif; ?>
<?php if (!ca_disable_ddbpng) : ?>
	<!--[if IE 6]>
	<script type="text/javascript" src="<?php echo templatedir ?>/js/DD_belatedPNG_0.0.8a-min.js"></script> 
	<![endif]-->
<?php endif;
}

function carta_call_slider() {
	if (ca_slider != 'None' && is_front_page()) : ?>
	<script type="text/javascript">
	jQuery(document).ready(function($){
		$(window).load(function(){
<?php if (ca_slider == 'Carta Accordion' && !ca_disable_wb) : ?>
<?php if (!ca_accordion_custom) : ?>
			jQuery("#featured").wbaccordion()
<?php else : ?>
			jQuery("#featured").wbaccordion({
				first: <?php echo (ca_accordion_first ? ca_accordion_first : 1); ?>,
				fullwidth: <?php echo ca_accordion_fullwidth; ?>,
				dropshadow: <?php echo (ca_accordion_dropshadow ? 'true' : 'false'); ?>,
				hovercolor: '#<?php echo ca_accordion_hovercolor; ?>',
				hoveropacity: <?php echo ca_accordion_hoveropacity; ?>,
				speed: <?php echo stripslashes(ca_accordion_speed); ?>,
				easing: '<?php echo ca_accordion_easing; ?>'
			})
<?php endif; endif; ?>

<?php if (ca_slider == 'Nivo Slider'  && !ca_disable_nivoslider) : ?>
<?php if (!ca_nivoslider_custom) : ?>
			jQuery("#featured #nivo").nivoSlider();
<?php else : ?>
			jQuery("#featured #nivo").nivoSlider({
				effect: '<?php echo ca_nivoslider_effect; ?>',
				slices: <?php echo ca_nivoslider_slices; ?>,
				animSpeed: <?php echo stripslashes(ca_nivoslider_speed); ?>,
				pauseTime: <?php echo ca_nivoslider_pause; ?>,
				startSlide: <?php $i = ca_nivoslider_start - 1; echo $i ?>,
				directionNav: <?php echo (ca_nivoslider_nav ? 'true' : 'false'); ?>,
				directionNavHide: <?php echo (ca_nivoslider_navhide ? 'true' : 'false'); ?>,
				controlNav: <?php echo (ca_nivoslider_controls ? 'true' : 'false'); ?>,
				keyboardNav: <?php echo (ca_nivoslider_keyboard ? 'true' : 'false'); ?>,
				pauseOnHover: <?php echo (ca_nivoslider_hover ? 'true' : 'false'); ?>,
				manualAdvance: <?php echo (ca_nivoslider_manual ? 'true' : 'false'); ?>,
				captionOpacity: <?php echo ca_nivoslider_opacity; ?>

			})
<?php endif; endif; ?>
		})
	})
	</script>
	<?php endif;
}

add_action('wp_head', 'carta_seo');
add_action('wp_head', 'carta_incl_jquery');
add_action('wp_head', 'carta_incl_plugins');
add_action('wp_head', 'carta_call_slider');
?>