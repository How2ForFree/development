<?php
/*
	Carta Options
*/

$wpcats = get_categories('hide_empty=0&orderby=name');  
$categories = array();
foreach ($wpcats as $wpcat) {
	$categories[$wpcat->cat_ID] = $wpcat->cat_name;
}
array_unshift($categories, __('Choose a category', 'carta'));

$wppages = get_pages();  
$pages = array();
foreach ($wppages as $wppage) {
	$pages[$wppage->ID] = $wppage->post_name;
}
array_unshift($pages, __('Choose a page', 'carta'));

$themes = scandir(TEMPLATEPATH.'/themes/');
$i = 0;
foreach ($themes as $css) {
	if (substr($css, -4) != '.css') unset($themes[$i]); $i++;
}

$fonts = scandir(TEMPLATEPATH.'/js/fonts/');
$o = 0;
foreach ($fonts as $js) {
	if (substr($js, -3) != '.js') unset($fonts[$o]); $o++;
}

$options = array(
	array('::' => '::opentab'),
	array('::' => '::open', '(white)' => true),
		
	array(
		'(name)' => __('Frontpage', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Take content from', 'carta'),
		'(desc)' => __('Select an existing page to use as frontpage content.', 'carta'),
		'(ID)' => 'ca_frontpage',
		'::' => ':select',
		'(select:list)' => $pages
	),
	array(
		'(name)' => __('Frontpage Slider', 'carta'),
		'(desc)' => __('Select the type of slider that you prefer.', 'carta'),
		'(ID)' => 'ca_slider',
		'::' => ':select',
		'(select:list)' => array('None', 'Carta Accordion', 'Nivo Slider'),
		'(DEF)' => 'Carta Accordion'
	),
	
	array('::' => '::close'),	
	array('::' => '::open'),
		
	array(
		'(name)' => __('Aesthetics', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Theme Stylesheet', 'carta'),
		'(desc)' => __('Select a colour scheme for your site. Themes are located in the <code>/themes</code> folder.', 'carta'),
		'(ID)' => 'ca_theme',
		'::' => ':select',
		'(select:list)' => $themes,
		'(DEF)' => 'Aqua.css'
	),
	array(
		'(name)' => __('Headings font', 'carta'),
		'(desc)' => __('Choose a font for your website. Fonts are stored in the <code>/js/fonts</code> folder.', 'carta'),
		'::' => ':select',
		'(select:list)' => $fonts,
		'(addendum)' => '<a href="#" class="shownext">'.__('Edit selectors list..', 'carta').'</a>',
		'(ID)' => 'ca_cufon_font',
		'(DEF)' => 'ChunkFive.js'
	),
	array(
		'(name)' => __('Apply to:', 'carta'),
		'(ID)' => 'ca_cufon_selectors',
		'::' => ':textarea',
		'(desc)' => __('Type here, using a CSS Selector, every text element you want to apply Cuf&oacute;n on. (I.E. <code>.myclass</code>, <code>#myid</code>)', 'carta'),
		'(hidden)' => true,
		'(DEF)' => '#menu strong, #toolbar strong, #toolbar b, .pag strong, h1:not(.classic), h2:not(.classic), h3:not(.classic), h4:not(.classic), h5:not(.classic), h6:not(.classic), .ca_note_widget a.goto, .pagination a'
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
		
	array(
		'(name)' => __('Social Profiles', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Twitter Username', 'carta'),
		'(ID)' => 'ca_social_twitter',
		'::' => ':text'
	),
	array(
		'(name)' => __('Facebook Profile', 'carta'),
		'(ID)' => 'ca_social_facebook',
		'::' => ':text'
	),
	array(
		'(name)' => __('Flickr ID', 'carta'),
		'(ID)' => 'ca_social_flickr',
		'::' => ':text',
		'(desc)' => __('Troubles finding your Flickr ID? Try with <a target="_blank" href="http://idgettr.com/">idgettr.com</a>', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
		
	array(
		'(name)' => __('Analytics Settings', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Tracking Code', 'carta'),
		'(desc)' => __('Paste your analytics service code up here (like Google Analytics).', 'carta'),
		'(ID)' => 'ca_analytics',
		'::' => ':textarea',
	),
	array(
		'(name)' => __('Position', 'carta'),
		'(ID)' => 'ca_analytics_position',
		'::' => ':checkbox',
		'(checkbox:left)' => 'head',
		'(checkbox:right)' => 'body'
	),
	
	array('::' => '::close'),

	array('::' => '::closetab'),
	array('::' => '::opentab'),
	
	array('::' => '::open'),
		
	array(
		'(name)' => __('Logo Image', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Upload:', 'carta'),
		'(ID)' => 'ca_file_logo',
		'::' => ':file',
		'(desc)' => __('Upload your logo, then take a look at the "Logo Adjustments" section for any retouch.', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
		
	array(
		'(name)' => __('Favorite Icon', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Upload:', 'carta'),
		'(ID)' => 'ca_file_favicon',
		'::' => ':file'
	),
	
	array('::' => '::close'),
	array('::' => '::open', '(white)' => true),
		
	array(
		'(name)' => __('Plain Text Logo', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Use Textual Logo','carta'),
		'(ID)' => 'ca_plain_logo',
		'::' => ':checkbox'
	),
	array(
		'(ID)' => 'ca_plain_logo_text',
		'(DEF)' => get_bloginfo('(name)'),
		'::' => ':text',
		'(desc)' => __('See the "Logo Adjustments" section below to adapt the logo text to your needs.','carta')
	),
		
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Logo Adjustments', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Custom <code>CSS</code>', 'carta'),
		'(ID)' => 'ca_header_custom_css',
		'(desc)' => __('Activate to enable the settings below.', 'carta'),
		'::' => ':checkbox',
		'(checkbox:left)' => __('Enable', 'carta'),
		'(checkbox:right)' => __('Disable', 'carta')
	),
	array(
		'(name)' => __('Logo Font Size', 'carta'),
		'(ID)' => 'ca_logo_text_size',
		'(desc)' => 'pixels',
		'(DEF)' => 53,
		'::' => ':plusminus'
	),
	array(
		'(name)' => __('Logo Font Color', 'carta'),
		'(ID)' => 'ca_logo_text_color',
		'(DEF)' => '000000',
		'::' => ':picker'
	),
	array(
		'(name)' => '&darr; '.__('Top Spacing', 'carta'),
		'(ID)' => 'ca_logo_top',
		'(desc)' => 'pixels',
		'(DEF)' => 57,
		'::' => ':plusminus'
	),
	array(
		'(name)' => '&rarr; '.__('Left Spacing', 'carta'),
		'(ID)' => 'ca_logo_left',
		'(desc)' => 'pixels',
		'(DEF)' => 0,
		'::' => ':plusminus'
	),
	array(
		'(name)' => '&harr; '.__('Width', 'carta'),
		'(ID)' => 'ca_logo_width',
		'(desc)' => __('Usually you have to increase the default width if the logo text or image doesn\'t fit', 'carta'),
		'(DEF)' => 179,
		'::' => ':slider',
		'(slider:type)' => 3
	),
	array(
		'(name)' => '&#8597; '.__('Height', 'carta'),
		'(ID)' => 'ca_logo_height',
		'(DEF)' => 38,
		'::' => ':slider',
		'(slider:type)' => 3
	),
	
	array('::' => '::close'),
	
	array('::' => '::closetab'),
	array('::' => '::opentab'),
	
	array('::' => '::open', '(white)' => true),
	
	array(
		'(name)' => __('Copyright', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Copyright & Credits text', 'carta'),
		'(ID)' => 'ca_copyright',
		'::' => ':text',
		'(DEF)' => 'Copyright &copy; 2010 '.get_bloginfo('(name)').'. All rights reserved. Proudly powered by WordPress.'
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Social Networks Icons', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Twitter', 'carta'),
		'(ID)' => 'ca_hide_twitter',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(ID)' => 'ca_file_twitter_icon',
		'::' => ':file'
	),
	array(
		'(name)' => __('Facebook', 'carta'),
		'(ID)' => 'ca_hide_facebook',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(ID)' => 'ca_file_facebook_icon',
		'::' => ':file'
	),
	array(
		'(name)' => __('Flickr', 'carta'),
		'(ID)' => 'ca_hide_flickr',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(ID)' => 'ca_file_flickr_icon',
		'::' => ':file'
	),
	
	array('::' => '::close'),
		
	array('::' => '::closetab'),
	array('::' => '::opentab'),

	array('::' => '::open', '(white)' => true),
	
	array(
		'(name)' => __('Assign', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Use this page as Gallery', 'carta'),
		'(desc)' => __('You can also assign the <code>Gallery</code> template to any page from the wp-admin Pages section.', 'carta'),
		'(ID)' => 'ca_gallery_page',
		'::' => ':select',
		'(select:list)' => $pages
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Navigation', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Intro Message', 'carta'),
		'(desc)' => __('This message will show up just before the Gallery boxes.', 'carta'),
		'(ID)' => 'ca_gallery_intro',
		'::' => ':text'
	),
	array(
		'(name)' => __('Boxes per page', 'carta'),
		'(ID)' => 'ca_gallery_bpp',
		'::' => ':plusminus',
		'(plusminus:all)' => true,
		'(DEF)' => 9
	),
	array(
		'(name)' => __('Layout', 'carta'),
		'(ID)' => 'ca_gallery_layout',
		'::' => ':select',
		'(select:list)' => array('4 Columns', '3 Columns', '2 Columns', '1 Column'),
		'(DEF)' => 3
	),
	array(
		'(name)' => __('Order by', 'carta'),
		'(ID)' => 'ca_gallery_orderby',
		'::' => ':select',
		'(select:list)' => array('Author', 'Date', 'Title', 'Modified', 'Parent', 'ID', 'Rand', 'None'),
		'(DEF)' => 'Date'
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Filtering', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Filtering', 'carta'),
		'(ID)' => 'ca_gallery_filtering',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta'),
	),
	array(
		'(name)' => __('Replace Titles with Type', 'carta'),
		'(ID)' => 'ca_gallery_titletype',
		'::' => ':checkbox',
		'(desc)' => __('Every Gallery entry will display its Type (filtering) instead of the title.', 'carta'),
	),
	array(
		'(name)' => __('Labels', 'carta'),
		'(ID)' => 'ca_gallery_filtering_show',
		'::' => ':text',
		'(DEF)' => __('Show:', 'carta')
	),
	array(
		'(ID)' => 'ca_gallery_filtering_reset',
		'::' => ':text',
		'(DEF)' => __('All', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Boxes', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Lightbox Zoom Style', 'carta'),
		'(ID)' => 'ca_gallery_lightbox',
		'::' => ':select',
		'(select:list)' => array('zoom', 'fullzoom'),
		'(DEF)' => 'zoom',
		'(desc)' => __('Select the Lightbox Style that you prefer.', 'carta')
	),
	array(
		'(name)' => __('Group Lightbox', 'carta'),
		'(ID)' => 'ca_gallery_group',
		'::' => ':checkbox',
		'(desc)' => __('Activating this feature every Gallery entry will be grouped and the Next-Previous navigation will be active.', 'carta')
	),
	array(
		'(name)' => __('Boxes Titles', 'carta'),
		'(ID)' => 'ca_gallery_title',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta'),
		'(desc)' => __('All titles will be hidden. You can hide a single box title just leaving empty the "Title" field when adding a new box.', 'carta')
	),
	array(
		'(name)' => __('Featured Images', 'carta'),
		'(ID)' => 'ca_gallery_video',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Always', 'carta'),
		'(checkbox:right)' => __('Normal', 'carta'),
		'(desc)' => __('Media Gallery Boxes will not use Original Video Thumbnails.', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Image Resizing', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('TimThumb', 'carta'),
		'(desc)' => __('TimThumb automatically resizes all Gallery thumbnails.', 'carta'),
		'(ID)' => 'ca_gallery_resize',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	array(
		'(ID)' => 'ca_gallery_resize_type',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Normal', 'carta'),
		'(checkbox:right)' => __('Crop', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Disable', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Gallery', 'carta'),
		'(desc)' => __('If you don\'t need this feature, you can disable it temporarily and it will disappear from the wp-admin sidebar.', 'carta'),
		'(ID)' => 'ca_gallery_disable',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Disable', 'carta'),
		'(checkbox:right)' => __('Enable', 'carta')
	),
		
	array('::' => '::close'),
			
	array('::' => '::closetab'),
	array('::' => '::opentab'),
	
	array('::' => '::open', '(white)' => true),
	
	array(
		'(name)' => __('Assign', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Use this page as Projects', 'carta'),
		'(desc)' => __('You can also assign the <code>Projects</code> template to any page from the wp-admin Pages section.', 'carta'),
		'(ID)' => 'ca_projects_page',
		'::' => ':select',
		'(select:list)' => $pages
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Navigation', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Intro Message', 'carta'),
		'(desc)' => __('This message will show up just before the Projects entries.', 'carta'),
		'(ID)' => 'ca_projects_intro',
		'::' => ':text'
	),
	array(
		'(name)' => __('Projects per page', 'carta'),
		'(ID)' => 'ca_projects_ppp',
		'::' => ':plusminus',
		'(plusminus:all)' => true,
		'(DEF)' => 6
	),
	array(
		'(name)' => __('Layout', 'carta'),
		'(ID)' => 'ca_projects_layout',
		'::' => ':select',
		'(select:list)' => array('3 Columns', '2 Columns', '1 Column'),
		'(DEF)' => 2
	),
	array(
		'(name)' => __('Order by', 'carta'),
		'(ID)' => 'ca_projects_orderby',
		'::' => ':select',
		'(select:list)' => array('Author', 'Date', 'Title', 'Modified', 'Parent', 'ID', 'Rand', 'None'),
		'(DEF)' => 'Date'
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Filtering', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Filtering', 'carta'),
		'(ID)' => 'ca_projects_filtering',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta'),
	),
	array(
		'(name)' => __('Replace Titles with Type', 'carta'),
		'(ID)' => 'ca_projects_titletype',
		'::' => ':checkbox',
		'(desc)' => __('Every Project entry will display its Type (filtering) instead of the title.', 'carta'),
	),
	array(
		'(name)' => __('Labels', 'carta'),
		'(ID)' => 'ca_projects_filtering_show',
		'::' => ':text',
		'(DEF)' => __('Show:', 'carta')
	),
	array(
		'(ID)' => 'ca_projects_filtering_reset',
		'::' => ':text',
		'(DEF)' => __('All', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Entries', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Popup Message', 'carta'),
		'(ID)' => 'ca_projects_popup',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(ID)' => 'ca_projects_popup_text',
		'::' => ':text',
		'(DEF)' => __('See % details..', 'carta')
	),
	array(
		'(name)' => __('Projects Excerpts', 'carta'),
		'(ID)' => 'ca_projects_excerpt',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(name)' => __('Projects Titles', 'carta'),
		'(ID)' => 'ca_projects_title',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Project View', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Page Template', 'carta'),
		'(ID)' => 'ca_projects_view',
		'::' => ':select',
		'(select:list)' => array('Default Template', 'Left Sidebar', 'Blank Page (No Sidebar)'),
		'(DEF)' => 1
	),
	array(
		'(name)' => __('Auto Project Picture', 'carta'),
		'(desc)' => __('Automatically displays the Project picture in the details page. You can use <code>[project-image]</code> to add it manually.', 'carta'),
		'(ID)' => 'ca_projects_ai',
		'::' => ':checkbox',
		'(checkbox:left)' => __('On', 'carta'),
		'(checkbox:right)' => __('Off', 'carta')
	),
	array(
		'(desc)' => __('Picture Height', 'carta'),
		'(ID)' => 'ca_projects_ai_height',
		'(DEF)' => 130,
		'::' => ':slider',
		'(slider:type)' => 3
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Image Resizing', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('TimThumb', 'carta'),
		'(desc)' => __('TimThumb automatically resizes all Projects pictures.', 'carta'),
		'(ID)' => 'ca_projects_resize',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	array(
		'(ID)' => 'ca_projects_resize_type',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Normal', 'carta'),
		'(checkbox:right)' => __('Crop', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Links Structure', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Permalink Slug', 'carta'),
		'(ID)' => 'ca_projects_slug',
		'::' => ':text',
		'(text:type)' => ':slug',
		'(DEF)' => 'project',
		'(desc)' => '<code>'.__('Warning!', 'carta').'</code> '.__('Always make sure to re-assign the Permalinks Structure in Settings &rarr; Permalinks after any change.', 'carta'),
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Disable', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Projects', 'carta'),
		'(ID)' => 'ca_projects_disable',
		'(desc)' => __('If you don\'t need this feature, you can disable it temporarily and it will disappear from the wp-admin sidebar.', 'carta'),
		'::' => ':checkbox',
		'(checkbox:left)' => __('Disable', 'carta'),
		'(checkbox:right)' => __('Enable', 'carta')
	),
	
	array('::' => '::close'),
		
	array('::' => '::closetab'),
	array('::' => '::opentab'),

	array('::' => '::open', '(white)' => true),
	
	array(
		'(name)' => __('Assign', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Use this page as Blog', 'carta'),
		'(desc)' => __('You can also assign the <code>Blog</code> template to any page from the wp-admin Pages section.', 'carta'),
		'(ID)' => 'ca_blog_page',
		'::' => ':select',
		'(select:list)' => $pages
	),
	
	array('::' => '::close'),
	array('::' => '::open'),

	array(
		'(name)' => __('Pagination', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Posts per page', 'carta'),
		'(ID)' => 'ca_blog_ppp',
		'(desc)' => __('posts', 'carta'),
		'::' => ':plusminus',
		'(plusminus:all)' => true,
		'(DEF)' => 5
	),

	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Exclude Categories', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Select a category', 'carta'),
		'(ID)' => 'ca_blog_exclude',
		'::' => ':select',
		'(select:list)' => $categories
	),
	array(
		'(ID)' => 'ca_blog_exclude_list',
		'(desc)' => __('or type a series of Category IDs (I.E. <code>1,3,8</code>)', 'carta'),
		'::' => ':text'
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Posts Listing', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('View Style', 'carta'),
		'(ID)' => 'ca_blog_view',
		'::' => ':select',
		'(select:list)' => array('Classic', 'Plain', 'Sidebar', 'Sidebar (Left)'),
		'(DEF)' => 'Classic'
	),
	array(
		'(name)' => __('Order by', 'carta'),
		'(ID)' => 'ca_blog_orderby',
		'::' => ':select',
		'(select:list)' => array('Author', 'Date', 'Title', 'Modified', 'Parent', 'ID', 'Rand', 'None', 'Comment Count'),
		'(DEF)' => 'Date'
	),
	array(
		'(name)' => __('Use Cuf&oacute;n on titles', 'carta'),
		'(ID)' => 'ca_blog_cufon_titles',
		'::' => ':checkbox',
		'(desc)' => __('By default posts headings are not in the Cuf&oacute;n selectors list.', 'carta'),
	),
	array(
		'(name)' => __('Author', 'carta'),
		'(ID)' => 'ca_blog_author',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(name)' => __('Date', 'carta'),
		'(ID)' => 'ca_blog_date',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(name)' => __('Category', 'carta'),
		'(ID)' => 'ca_blog_category',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(name)' => __('Comments Count', 'carta'),
		'(ID)' => 'ca_blog_comments',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Post View', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('View Style', 'carta'),
		'(ID)' => 'ca_post_view',
		'::' => ':select',
		'(select:list)' => array('Classic', 'Plain', 'Sidebar', 'Sidebar (Left)'),
		'(DEF)' => 'Classic'
	),
	array(
		'(name)' => __('Related Posts', 'carta'),
		'(ID)' => 'ca_blog_related',
		'(desc)' => __('Hide the related posts or choose below how many posts you want to display.', 'carta'),
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(ID)' => 'ca_blog_related_posts',
		'::' => ':plusminus',
		'(plusminus:all)' => true,
		'(DEF)' => 3,
		'(desc)' => __('posts', 'carta')
	),
	array(
		'(name)' => __('Author Bio', 'carta'),
		'(ID)' => 'ca_blog_bio',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Toolbar', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Toolbar', 'carta'),
		'(ID)' => 'ca_blog_toolbar_disable',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(name)' => __('Archives', 'carta'),
		'(ID)' => 'ca_blog_toolbar_archives',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(name)' => __('Categories', 'carta'),
		'(ID)' => 'ca_blog_toolbar_cats',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	array(
		'(name)' => __('Tags', 'carta'),
		'(ID)' => 'ca_blog_toolbar_tags',
		'(desc)' => '<code>'.__('Caution:', 'carta').'</code> '.__('If you have used many Tags it will generate a long list that may result unhandy.', 'carta'),
		'::' => ':checkbox',
		'(checkbox:left)' => __('Show', 'carta'),
		'(checkbox:right)' => __('Hide', 'carta')
	),
	array(
		'(name)' => __('Search', 'carta'),
		'(ID)' => 'ca_blog_toolbar_search',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hide', 'carta'),
		'(checkbox:right)' => __('Show', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Sharing', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Twitter', 'carta'),
		'(desc)' => (get_option('ca_social_twitter') ? __('You have configurated a twitter account. The source of the share will be also associated to ', 'carta').' <code>'.get_option('ca_social_twitter').'</code>' : ''),
		'(ID)' => 'ca_blog_share_twitter',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Disable', 'carta'),
		'(checkbox:right)' => __('Enable', 'carta')
	),
	array(
		'(name)' => __('Facebook', 'carta'),
		'(desc)' => __('Select the share type below.', 'carta'),
		'(ID)' => 'ca_blog_share_fb',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Disable', 'carta'),
		'(checkbox:right)' => __('Enable', 'carta')
	),
	array(
		'(ID)' => 'ca_blog_share_fbtype',
		'::' => ':select',
		'(select:list)' => array('like', 'recommend'),
		'(DEF)' => 'recommend',
		'disabled' => (get_option('ca_blog_share_fb') ? true : false)
	),
	
	array('::' => '::close'),
	
	array('::' => '::closetab'),
	array('::' => '::opentab'),
	
	array('::' => '::open', '(white)' => true),
	
	array(
		'(name)' => __('Contact Form', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Send emails to:', 'carta'),
		'(desc)' => __('You can add a Contact Form to any page using the <code>[wb_contact-form]</code> shortcode.', 'carta'),
		'(ID)' => 'ca_contact_email',
		'::' => ':text',
		'(DEF)' => get_bloginfo('admin_email')
	),
	array(
		'(name)' => __('Show help message', 'carta'),
		'(ID)' => 'ca_contact_help',
		'(desc)' => __('Your email will be displayed (encrypted) below the Contact Form.', 'carta'),
		'::' => ':checkbox',
	),
	array(
		'(ID)' => 'ca_contact_help_text',
		'::' => ':text',
		'(DEF)' => __('Troubles with the form? Contact us at %', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),

	array(
		'(name)' => __('Custom Inputs', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Name', 'carta'),
		'(ID)' => 'ca_contact_label_name',
		'::' => ':text',
		'(DEF)' => __("Your name", 'carta')
	),
	array(
		'(name)' => __('Email', 'carta'),
		'(ID)' => 'ca_contact_label_email',
		'::' => ':text',
		'(DEF)' => __("Your email", 'carta')
	),
	array(
		'(name)' => __('Website', 'carta'),
		'(ID)' => 'ca_contact_label_website',
		'::' => ':text',
		'(DEF)' => __("Your website", 'carta')
	),
	array(
		'(ID)' => 'ca_contact_input_website',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Required', 'carta'),
		'(checkbox:right)' => __('Not Required', 'carta')
	),
	array(
		'(name)' => __('Send button', 'carta'),
		'(ID)' => 'ca_contact_go',
		'::' => ':text',
		'(DEF)' => __('Submit message', 'carta')
	),
	
	array('::' => '::close'),	
	array('::' => '::open'),
	
	array(
		'(name)' => __('Custom Messages', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Success', 'carta'),
		'(ID)' => 'ca_contact_str_success',
		'::' => ':text',
		'(DEF)' => __('Thank you, We have received your message.', 'carta')
	),
	array(
		'(name)' => __('Error', 'carta'),
		'(ID)' => 'ca_contact_str_general',
		'::' => ':text',
		'(DEF)' => __('Please, fill out all required fields properly.', 'carta')
	),
	array(
		'(name)' => __('Address not valid', 'carta'),
		'(ID)' => 'ca_contact_str_email',
		'::' => ':text',
		'(DEF)' => __('Please, enter a valid email address.', 'carta')
	),
	array(
		'(name)' => __('Server error', 'carta'),
		'(ID)' => 'ca_contact_str_unexpected',
		'::' => ':text',
		'(DEF)' => __('An error occured. Please, try again later.', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Custom Email', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Email Subject', 'carta'),
		'(ID)' => 'ca_contact_subject',
		'::' => ':text',
		'(DEF)' => get_bloginfo('name'),
		'(desc)' => __('You can change the look of the emails you will receive editing the <code>mail-tmpl.html</code> file.', 'carta')
	),
	
	array('::' => '::close'),
	
	array('::' => '::closetab'),
	array('::' => '::opentab'),
	
	array('::' => '::open', '(white)' => true),
	
	array(
		'(name)' => __('Custom Options Panel', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Panel Name', 'carta'),
		'(ID)' => 'ca_opn',
		'::' => ':text',
		'(DEF)' => 'Carta'
	),
	array(
		'(name)' => __('Icon', 'carta'),
		'(ID)' => 'ca_file_opn_ico',
		'::' => ':file',
		'(DEF)' => includes.'ui/carta_ui.png'
	),
	
	array('::' => '::close'),
	
	array('::' => '::open'),
	
	array(
		'(name)' => __('Custom WP Login Logo', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Upload', 'carta'),
		'(ID)' => 'ca_file_extra_login',
		'::' => ':file',
		'(DEF)' => includes.'images/custom_login.png'
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Custom Gravatar Image', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Upload', 'carta'),
		'(ID)' => 'ca_file_extra_gravatar',
		'(desc)' => __('Upload your custom avatar and make it default in Settings &rarr; Discussion', 'carta'),
		'::' => ':file',
		'(DEF)' => includes.'images/custom_gravatar.png'
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('Custom Sidebar Labels', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Gallery', 'carta'),
		'(ID)' => 'ca_gallery_label',
		'::' => ':text',
		'(DEF)' => __('Gallery', 'carta'),
	),
	array(
		'(name)' => __('Projects', 'carta'),
		'(ID)' => 'ca_projects_label',
		'::' => ':text',
		'(DEF)' => __('Projects', 'carta')
	),
	
	array('::' => '::close'),
	
	array('::' => '::open'),
	
	array(
		'(name)' => __('Search Engines Optimization', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Carta Built-In Seo', 'carta'),
		'(ID)' => 'ca_seo',
		'::' => ':checkbox',
		'(checkbox:left)' => __('On', 'carta'),
		'(checkbox:right)' => __('Off', 'carta')
	),
	array(
		'(name)' => __('Description', 'carta'),
		'(ID)' => 'ca_seo_description',
		'::' => ':text',
		'(DEF)' => get_bloginfo('description'),
	),
	array(
		'(name)' => __('Keywords', 'carta'),
		'(ID)' => 'ca_seo_keywords',
		'::' => ':text',
		'(desc)' => __('Enter a series of keywords that match the arguments treated by your website. (I.E. <code>books, writing, literature</code>)', 'carta'),
	),
	array(
		'(name)' => __('Robots', 'carta'),
		'(ID)' => 'ca_seo_robots',
		'::' => ':text',
		'(DEF)' => __('index, follow', 'carta'),
	),
	
	array('::' => '::close'),
	
	array('::' => '::open'),
	
	array(
		'(name)' => __('Carta', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Check for updates', 'carta'),
		'(ID)' => 'ca_updates',
		'(desc)' => __('If a new version of Carta is available, a notification will be displayed.', 'carta'),
		'::' => ':checkbox'
	),
	
	array('::' => '::close'),
	
	array('::' => '::closetab'),
	array('::' => '::opentab'),
	
	array('::' => '::open'),
	
	array(
		'(name)' => __('Frontpage Slider', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Slides Manager','carta'),
		'(ID)' => 'ca_alt_slides_manager',
		'(desc)' => __('The Simplified Slides Manager relies completely on the WordPress system.', 'carta'),
		'::' => ':checkbox',
		'(checkbox:left)' => __('Simplified', 'carta'),
		'(checkbox:right)' => __('Carta', 'carta')
	),
	
	array('::' => '::close'),
	array('::' => '::open'),
	
	array(
		'(name)' => __('jQuery Location', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Choose', 'carta'),
		'(ID)' => 'ca_jquery_local',
		'(desc)' => __('Loading jQuery from Google servers improves the overall loading performances.', 'carta'),
		'::' => ':checkbox',
		'(checkbox:left)' => $_SERVER['HTTP_HOST'],
		'(checkbox:right)' => __('Google APIs', 'carta')
	),
	
	array('::' => '::close'),

	array('::' => '::open'),
	
	array(
		'(name)' => __('Disable Javascript Plugins (Be careful!)', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => 'jQuery',
		'(ID)' => 'ca_disable_jquery',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	array(
		'(name)' => 'Carta Plugins',
		'(ID)' => 'ca_disable_wb',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	array(
		'(name)' => 'Nivo Slider',
		'(ID)' => 'ca_disable_nivoslider',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	array(
		'(name)' => 'Cufon',
		'(ID)' => 'ca_disable_cufon',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	array(
		'(name)' => 'jQuery Easing',
		'(ID)' => 'ca_disable_jeasing',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	array(
		'(name)' => 'jQuery Superfish',
		'(ID)' => 'ca_disable_superfish',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	array(
		'(name)' => 'jQuery Fancybox',
		'(ID)' => 'ca_disable_fancybox',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	array(
		'(name)' => 'DD_belatedPNG (IE)',
		'(ID)' => 'ca_disable_ddbpng',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	array(
		'(name)' => __('Plugins Initialization', 'carta'),
		'(ID)' => 'ca_disable_init',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Off', 'carta'),
		'(checkbox:right)' => __('On', 'carta')
	),
	
	array('::' => '::close'),	
	array('::' => '::closetab'),
);
?>