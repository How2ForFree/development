<?php
/*
	Options page structure
*/
global $options;

if (is_wb() && isset($_REQUEST['action'])) {
	switch ($_REQUEST['action']) {
		case 'save':
			foreach ($options as $i) {
				if (substr(@$i['(ID)'], 0, 7) == 'ca_file') {
					if (substr(@$_FILES[@$i['(ID)']]['type'], 0, 5) == 'image') {
						$wupload = wp_handle_upload($_FILES[$i['(ID)']], array('test_form' => false));
						$wurl = $wupload['url'];
						update_option($i['(ID)'], $wurl);
					}
				}
				else {
					update_option(@$i['(ID)'], @$_REQUEST[$i['(ID)']]);
				}
			}
		break;
		case 'reset':
			foreach ($options as $i) {
				delete_option(@$i['(ID)']);
			}
		break;
	}
}
if (is_wb() && isset($_GET['snipe']) && get_option(base64_decode($_GET['snipe']))) {
	delete_option(base64_decode($_GET['snipe']));
}
?>

<div class="wrap options-wrap" id="poststuff">

<?php
if (ca_updates && carta_update(1) && isset($_GET['updates'])) {
	echo '<div class="updates-print">'.carta_update(2).'</div>';
}
else if (isset($_REQUEST['save'])) {
	echo '<div class="options-message pop updated"><p><strong>'.__('Settings updated', 'carta').'</strong></p></div>';
}
else if (isset($_REQUEST['reset'])) {
	echo '<META HTTP-EQUIV="refresh" CONTENT="0">';
}
?>

<form method="post" action="" enctype="multipart/form-data">

	<div id="tabs">
	
	<ul id="tab-items">
		<li><a href="#tabs-1"><?php _e('General', 'carta') ?></a></li>
		<li><a href="#tabs-2"><?php _e('Brand', 'carta') ?></a></li>
		<li><a href="#tabs-3"><?php _e('Footer', 'carta') ?></a></li>
		<li><a href="#tabs-4"><?php _e('Gallery', 'carta') ?></a></li>
		<li><a href="#tabs-5"><?php _e('Projects', 'carta') ?></a></li>
		<li><a href="#tabs-6"><?php _e('Blog', 'carta') ?></a></li>
		<li><a href="#tabs-7"><?php _e('Contact', 'carta') ?></a></li>
		<li><a href="#tabs-8"><?php _e('Extras', 'carta') ?></a></li>
		<li><a href="#tabs-9"><?php _e('Debug', 'carta') ?></a></li>
		<li><a href="#tabs-reset"><?php _e('Reset', 'carta') ?></a></li>
		
<?php if (ca_updates && carta_update(1)) : ?>
		<li id="mark" class="update"><?php _e('Update Available', 'carta'); ?></li>
<?php else : ?>
		<li id="mark"><img src="<?php echo includes; ?>ui/options_ui.png" /></li>
<?php endif; ?>
		<li id="save">
			<input name="save" type="submit" class="button blink" value="<?php _e('Save Changes', 'carta') ?>" />
			<input type="hidden" name="action" value="save" />
		</li>
	</ul>
				
<?php include_once(dir.'framework/options-layout.php'); ?>
			
	</form>
	
	<div id="tabs-reset">
		<div class="stuffbox white">
			<h3><label><?php _e('Reset All Settings', 'carta') ?></label></h3>
			<div class="inside">
				<form method="post">
					<p class="submit">
						<input name="reset" type="submit" value="Reset" />
						<input type="hidden" name="action" value="reset" />
						<code><?php _e('Warning!', 'carta') ?></code> <?php _e('This operation is irreversible.', 'carta') ?>
					</p>
				</form>
			</div>
		</div>
	</div>
	
	<p class="submit">
		<input name="save" type="submit" class="button-primary savechanges" value="<?php _e('Save Changes', 'carta') ?>" />    
		<input type="hidden" name="action" value="save" />
	</p>
	
	</div>
			
</div>