<?php
/*
	Columns Shortcodes
*/
function cols($atts, $content = null) {
	extract(shortcode_atts(array('align' => ''), $atts));
	return '<div class="col-s type '.esc_attr($align).'">'.do_shortcode($content).'</div>';
}
function colm($atts, $content = null) {
	extract(shortcode_atts(array('align' => ''), $atts));
	return '<div class="col-m '.esc_attr($align).'">'.do_shortcode($content).'</div>';
}
function colxm($atts, $content = null) {
	extract(shortcode_atts(array('align' => ''), $atts));
	return '<div class="col-xm '.esc_attr($align).'">'.do_shortcode($content).'</div>';
}
function coll($atts, $content = null) {
	extract(shortcode_atts(array('align' => ''), $atts));
	return '<div class="col-l type '.esc_attr($align).'">'.do_shortcode($content).'</div>';
}
function colxl($atts, $content = null) {
	extract(shortcode_atts(array('align' => ''), $atts));
	return '<div class="col-xl type '.esc_attr($align).'">'.do_shortcode($content).'</div>';
}
function colhalf($atts, $content = null) {
	extract(shortcode_atts(array('align' => ''), $atts));
	return '<div class="col-half type '.esc_attr($align).'">'.do_shortcode($content).'</div>';
}
function colfifty($atts, $content = null) {
	extract(shortcode_atts(array('align' => ''), $atts));
	return '<div class="col-50 type '.esc_attr($align).'">'.do_shortcode($content).'</div>';
}
function clear() {
	return '<div class="clear"></div>';
}
function space() {
	return '<div class="space"></div>';
}
function separator($atts, $content = null) {
	return '<div class="separator"></div>';
}

/*
	Misc Shortcodes
*/
function promo($atts, $content = null) {
	return '<span class="promo">'.$content.'</span>';
}
function img($atts, $content = null) {
	extract(shortcode_atts(array('size' => '', 'align' => ''), $atts));
	$image = '<img';
	if (esc_attr($align)) $image .= ' class="align-'.esc_attr($align).'" ';
	$image .= ' src="';
	if (esc_attr($size)) {
		$image .= timthumb.'?q=100&amp;';
		if ($size == 's') { $image .= 'w=130&amp;h=130'; }
		else if ($size == 'm') { $image .= 'w=420&amp;h=236'; }
		else if ($size == 'l') { $image .= 'w=700&amp;h=394'; }
		else {
			$custom = explode('x', $size);
			$image .= 'w='.$custom[0].'&amp;h='.$custom[1];
		}
		$image .= '&amp;src=';
	}
	$image .= do_shortcode($content).'" alt="" />';
	return $image;
}
function quote($atts, $content = null) {
	extract(shortcode_atts(array('cite' => ''), $atts));
	return '<blockquote><p>'.$content.' <cite>'.esc_attr($cite).'</cite></p></blockquote>';
}
function headr($atts, $content = null) {
	return '<div class="header"><h2>'.$content.'</h2></div>';
}

/*
	Lightbox Shortcode
*/
function zoom($atts, $content = null) {
	extract(shortcode_atts(array('type' => '', 'href' => ''), $atts));
	return '<a class="zoom '.esc_attr($type).'" href="'.esc_attr($href).'">'.do_shortcode($content).'</a>';
}
function fullzoom($atts, $content = null) {
	extract(shortcode_atts(array('type' => '', 'href' => ''), $atts));
	return '<a class="fullzoom '.esc_attr($type).'" href="'.esc_attr($href).'">'.do_shortcode($content).'</a>';
}
function window($atts, $content = null) {
	extract(shortcode_atts(array('href' => ''), $atts));
	return '<a class="fullzoom iframe" href="'.esc_attr($href).'">'.do_shortcode($content).'</a>';
}
function media($atts, $content = null) {
	extract(shortcode_atts(array('href' => '', 'thumb' => ''), $atts));
	$href = esc_attr($href);
	$thumb = esc_attr($thumb);
	if (strpos($href, 'youtube.com') !== false) {
		$lightbox = 'youtube';
		if ($thumb) {
			$id = wb_get_video_id($href, 'youtube.com');
			$pic = wb_get_video_thumb($id, 'youtube.com');
			$content = '<img src="'.timthumb.'?w=150&amp;h=84&amp;src='.$pic.'" title="'.do_shortcode($content).'" />';
		}
	}
	else if (strpos($href, 'vimeo.com') !== false) {
		$lightbox = 'vimeo';
		if ($thumb) {
			$id = wb_get_video_id($href, 'vimeo.com');
			$pic = wb_get_video_thumb($id, 'vimeo.com');
			$content = '<img src="'.timthumb.'?w=150&amp;h=84&amp;src='.$pic.'" title="'.do_shortcode($content).'" />';
		}
	}
	else {
		$lightbox = 'media';
		$content = do_shortcode($content);
	}
	return '<a class="'.$lightbox.'" href="'.esc_attr($href).'">'.$content.'</a>';
}

/*
	Notification Messages	
*/
function notice($atts, $content = null) {
	extract(shortcode_atts(array('type' => ''), $atts));
	return '<p class="message notice '.esc_attr($type).'">'.do_shortcode($content).'</p>';
}
function success($atts, $content = null) {
	extract(shortcode_atts(array('type' => ''), $atts));
	return '<p class="message success '.esc_attr($type).'">'.do_shortcode($content).'</p>';
}
function error($atts, $content = null) {
	extract(shortcode_atts(array('type' => ''), $atts));
	return '<p class="message error '.esc_attr($type).'">'.do_shortcode($content).'</p>';
}

/*
	Video Shortcode
*/
function youtube($atts, $content = null) {
	$id = wb_get_video_id(do_shortcode($content), 'youtube.com');
	return '
	<div class="sc-video">
		<div>
			<object type="application/x-shockwave-flash" style="width:570px; height:347px;" data="http://www.youtube.com/v/'.$id.'&amp;hl=en_US&amp;fs=1&amp;">
				<param name="movie" value="http://www.youtube.com/v/'.$id.'&amp;fs=1&amp;" />
			</object>
		</div>
	</div>';
}
function vimeo($atts, $content = null) {
	$id = wb_get_video_id(do_shortcode($content), 'vimeo.com');
	return '
	<div class="sc-video">
		<div>
			<iframe src="http://player.vimeo.com/video/'.$id.'" width="570" height="321" frameborder="0"></iframe>
		</div>
	</div>';
}
function swf($atts, $content = null) {
	$swf = do_shortcode($content);
	return '
	<div class="sc-video">
		<div>
			<object width="570" height="321">
				<param name="movie" value="'.$swf.'">
				<embed src="'.$swf.'" width="570" height="321">
				</embed>
			</object>
		</div>
	</div>';
}

/*
	Google Chart Shortcode
*/
function chart_shortcode( $atts ) {
	extract(shortcode_atts(array(
	    'data' => '',
	    'colors' => '',
	    'size' => '400x200',
	    'bg' => 'ffffff',
	    'title' => '',
	    'labels' => '',
	    'advanced' => '',
	    'type' => 'pie'
	), $atts));
	switch ($type) {
		case 'line' :
			$charttype = 'lc'; break;
		case 'xyline' :
			$charttype = 'lxy'; break;
		case 'sparkline' :
			$charttype = 'ls'; break;
		case 'meter' :
			$charttype = 'gom'; break;
		case 'scatter' :
			$charttype = 's'; break;
		case 'venn' :
			$charttype = 'v'; break;
		case 'pie' :
			$charttype = 'p3'; break;
		case 'pie2d' :
			$charttype = 'p'; break;
		default :
			$charttype = $type;
		break;
	}
 	if ($title) $string .= '&chtt='.$title.'';
	if ($labels) $string .= '&chl='.$labels.'';
	if ($colors) $string .= '&chco='.$colors.'';
	$string .= '&chs='.$size.'';
	$string .= '&chd=t:'.$data.'';
	$string .= '&chf='.$bg.'';
 	return '<img title="'.$title.'" src="http://chart.apis.google.com/chart?cht='.$charttype.''.$string.$advanced.'" alt="'.$title.'" />';
}

/*
	Google Static Map Image
*/
function gsmap($atts, $content = null) {
	extract(shortcode_atts(array('center' => '', 'size' => '', 'zoom' => ''), $atts));
	$center = (do_shortcode($center) ? do_shortcode($center) : "40.714728,-73.998672");
	$zoom = (do_shortcode($zoom) ? do_shortcode($zoom) : 12);
	$size = (do_shortcode($size) ? do_shortcode($size) : "150x150");
	return '<img src="http://maps.google.com/maps/api/staticmap?center='.$center.'&zoom='.$zoom.'&size='.$size.'&sensor=false" alt="" />';
}

/*
	Carta Contact Form
	<kompulsive@gmail.com> <winterbits.com>
*/
function wbcontactform($atts) {
	extract(shortcode_atts(array('help' => '', 'email' => ''), $atts));
	$sendto = (esc_attr($email) ? esc_attr($email) : ca_contact_email);
	$encoded = null; for ($i = 0; $i < strlen($sendto); $i++) $encoded .= '&#'.ord($sendto[$i]).';'; 
	$sendto = base64_encode($sendto);
	$subject = base64_encode(ca_contact_subject);
	$key = uniqid('wbcf_');
	$form = '
	<script type="text/javascript">
	jQuery(document).ready(function($){
		$("form#'.$key.'").wbform({
			str: {
				general: "'.ca_contact_str_general.'",
				email: "'.ca_contact_str_email.'",
				success: "'.ca_contact_str_success.'",
				unexpected: "'.ca_contact_str_unexpected.'"
			}
		});
	})
	</script>
	<form action="'.templatedir.enginedir.'contact/carta-mail.php" method="post" id="'.$key.'" class="contact-form">
		<fieldset>
			<p>
				<label>'.ca_contact_label_name.'</label>
				<input type="text" name="name" class="input-text required" value="" />
			</p>
			<p>
				<label>'.ca_contact_label_email.'</label>
				<input type="text" name="email" class="input-text required" value="" />
			</p>
			<p>
				<label>'.ca_contact_label_website.'</label>
				<input type="text" name="website" class="input-text'.(ca_contact_input_website ? ' required' : null).'" value="" />
			</p>
			<p>
				<textarea name="message" cols="" rows="15" class="required"></textarea>
			</p>
			<input type="hidden" name="to" value="'.$sendto.'" />
			<input type="hidden" name="sj" value="'.$subject.'" />
			<input type="submit" class="button" value="'.ca_contact_go.'" />
		</fieldset>
	</form>';
	if (ca_contact_help || esc_attr($help) == 'show') {
		$form .= '<p>'.str_replace('%', '<a href="mailto:'.$encoded.'">'.$encoded.'</a>', ca_contact_help_text).'</p>';
	}
	return $form;
}

/*
	Carta Accordion Shortcode
*/
function scaccordion($atts, $content = null) {
	return '<div class="sc-accordion accordion">'.do_shortcode($content).'</div>';
}
function slide($atts, $image = null) {
	extract(shortcode_atts(array('type' => '', 'cap' => ''), $atts));
	$slide = '<div class="slide">';
	if (esc_attr($type) && esc_attr($cap)) {
		$slide .= '<div class="slide-content '.esc_attr($type).'"><p>'.do_shortcode($cap).'</p></div>';
	}
	$slide .= '<img src="'.timthumb.'?w=700&amp;h=308&amp;src='.do_shortcode($image).'" />';
	$slide .= '</div>';
	return $slide;
}

/*
	[raw] Shortcode to disable wordpress autoformatting
*/
function formatter($content) {
	$new_content = '';
	$pattern_full = '{(\[raw\].*?\[/raw\])}is';
	$pattern_contents = '{\[raw\](.*?)\[/raw\]}is';
	$pieces = preg_split($pattern_full, $content, -1, PREG_SPLIT_DELIM_CAPTURE);
	foreach ($pieces as $piece) {
		if (preg_match($pattern_contents, $piece, $matches)) {
			$new_content .= $matches[1];
		} else {
			$new_content .= wptexturize(wpautop($piece));
		}
	}
	return $new_content;
}
remove_filter('the_content', 'wpautop');
remove_filter('the_content', 'wptexturize');
add_filter('the_content', 'formatter', 99);

function projimage($atts, $content = null) {
	$pi = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full', true);
	return $pi[0];
}

/*
	All Shortcodes registering
*/
add_shortcode('col-s', 'cols');
add_shortcode('col-m', 'colm');
add_shortcode('col-xm', 'colxm');
add_shortcode('col-l', 'coll');
add_shortcode('col-xl', 'colxl');
add_shortcode('col-half', 'colhalf');
add_shortcode('col-50', 'colfifty');
add_shortcode('clear', 'clear');
add_shortcode('space', 'space');
add_shortcode('separator', 'separator');
add_shortcode('promo', 'promo');
add_shortcode('image', 'img');
add_shortcode('quote', 'quote');
add_shortcode('header', 'headr');
add_shortcode('zoom', 'zoom');
add_shortcode('fullzoom', 'fullzoom');
add_shortcode('window', 'window');
add_shortcode('media', 'media');
add_shortcode('notice', 'notice');
add_shortcode('success', 'success');
add_shortcode('error', 'error');
add_shortcode('youtube', 'youtube');
add_shortcode('vimeo', 'vimeo');
add_shortcode('swf', 'swf');
add_shortcode('chart', 'chart_shortcode');
add_shortcode('staticmap', 'gsmap');
add_shortcode('wb_contact-form', 'wbcontactform');
add_shortcode('accordion', 'scaccordion');
add_shortcode('slide', 'slide');
add_shortcode('content', 'slidecontent');
add_shortcode('project-image', 'projimage');

/*
	Editor Shortcode buttons
*/
function cartatmce() {
	$wrap = array(
		'col-s' => ' align=""',
		'col-m' => ' align=""',
		'col-xm' => ' align=""',
		'col-l' => ' align=""',
		'col-xl' => ' align=""',
		'col-half' => ' align=""',
		'col-50' => ' align=""',
		'promo' => null,
		'image' => ' align=""',
		'quote' => ' cite=""',
		'header' => null,
		'zoom' => ' href=""',
		'fullzoom' => ' href=""',
		'window' => ' href=""',
		'media' => ' href=""',
		'youtube' => null,
		'vimeo' => null,
		'swf' => null,
		'notice' => null,
		'success' => null,
		'raw' => null
	);
	$single = array(
		'clear' => null,
		'separator' => null,
		'space' => null,
		'contact form' => 'wb_contact-form',
	);
	$i = 0;
	echo '<script type="text/javascript">';
	foreach ($wrap as $button => $option) {
		$i++;
		echo "edButtons[edButtons.length] = new edButton('carta_shortcode_".$i."','$button','[$button$option]','[/$button]');";
	}
	foreach ($single as $button => $option) {
		$i++;
		echo "edButtons[edButtons.length] = new edButton('carta_shortcode_".$i."','$button','[".($option ? $option : $button)."]','');";
	}
	echo '</script>';
}
add_action('admin_head', 'cartatmce');
?>