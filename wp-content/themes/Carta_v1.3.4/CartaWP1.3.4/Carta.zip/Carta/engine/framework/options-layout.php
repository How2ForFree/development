<?php
/*
	Options Layout Printing
*/

$tab = 1;
foreach ($options as $i) { 
	switch ($i['::']) {

		case '::opentab' :
?>
		
	<div id='tabs-<?php echo $tab; ?>'>

<?php
		$tab++;
		break;
		case '::closetab' :
?>
				
	</div>

<?php
		break;
		case '::open':
?>
			
	<div class='stuffbox <?php if (isset($i['(white)'])) echo 'white'; ?>'>

<?php
		break;
		case '::close':
?>
			
	</div>
	</div>
				
<?php
		break;
		case ':title':
?>
			
	<h3><label><?php echo $i['(name)']; ?></label></h3>
	<div class='inside'>		
					
<?php
		break;
		case ':text':
?>
				
	<div class='value'>
		<?php if (isset($i['(name)'])) echo $i['(name)']; ?>
	</div>
	<div class='input'>
		<input <?php if (isset($i['(text:type)']) && $i['(text:type)'] == ':slug') echo 'class="sluginput"' ?> name='<?php echo $i['(ID)']; ?>' id='<?php echo $i['(ID)']; ?>' type='text' value='<?php echo (get_option($i['(ID)']) ? stripslashes(htmlspecialchars(get_option($i['(ID)']), ENT_QUOTES)) : (isset($i['(DEF)']) ? $i['(DEF)'] : '')); ?>' />
		<?php if (isset($i['(text:type)']) && $i['(text:type)'] == ':slug') : ?>
		<p><code class="slugcont"><?php echo get_option('home'); ?>/<span class="slugbuddy"></span>/myproject</code></p>
		<?php endif; ?>
		<?php if (isset($i['(desc)'])) : ?>
		<p><?php echo stripslashes(htmlspecialchars_decode($i['(desc)'])); ?></p>
		<?php endif; ?>
	</div>
	<div class='clear'></div>

<?php
		break;
		case ':plusminus':
?>
				
	<div class='value'>
		<?php if (isset($i['(name)'])) echo $i['(name)']; ?>
	</div>
	<div class='input'>
		<?php if (isset($i['(plusminus:all)'])) : ?>
		<input type='hidden' class='plusminusall' />
		<?php endif; ?>
		<a href='#' class='plusminus'>+</a> <a href='#' class='plusminus'>-</a> <input type='text' class='two pmbuddy' name='<?php echo $i['(ID)']; ?>' border='0' value='<?php echo (get_settings($i['(ID)']) ? stripslashes(htmlspecialchars(get_settings($i['(ID)']), ENT_QUOTES)) : $i['(DEF)']); ?>' readonly /> <?php if (isset($i['(desc)'])) echo $i['(desc)']; ?>
	</div>
	<div class='clear'></div>
				
<?php
		break;
		case ':picker':
?>
				
	<div class='value'><?php echo $i['(name)']; ?></div>
	<div class='input'>
		<input type='text' maxlength='6' name='<?php echo $i['(ID)']; ?>' value='<?php echo (get_settings($i['(ID)']) ? stripslashes(htmlspecialchars(get_settings($i['(ID)']), ENT_QUOTES)) : $i['(DEF)']); ?>' class='picker' />
		<div class='pickerbuddy sample'></div>
		<div class='clear'></div>
		<?php if (isset($i['(desc)'])) echo $i['(desc)']; ?>
	</div>
	<div class='clear'></div>

<?php
		break;
		case ':slider':
?>
				
	<div class='value'>
		<?php if (isset($i['(name)'])) echo $i['(name)']; ?>
	</div>
	<div class='input'>
		<?php if (isset($i['(slider:type)'])) : ?>
		<input type='hidden' class='slidertype' value='<?php echo $i['(slider:type)']; ?>' />
		<?php endif; ?>
		<input type='text' name='<?php echo $i['(ID)']; ?>' value='<?php echo (get_option($i['(ID)']) ? stripslashes(htmlspecialchars(get_option($i['(ID)']), ENT_QUOTES)) : $i['(DEF)']); ?>' class='sliderbuddy' />
		<?php if (isset($i['(slider:type)']) && $i['(slider:type)'] == 1) : ?>
		<div class='sample'></div>
		<?php endif; ?>
		<div class='slider'></div>
		<div class='clear'></div>
		<?php if (isset($i['(desc)'])) echo $i['(desc)']; ?>
	</div>
	<div class='clear'></div>
					
<?php
		break;
		case ':file':
?>
				
	<?php if (isset($i['(hidden)'])) echo "<div class='hidden'>"; ?>	
	<div class='value'>
		<?php if (isset($i['(name)'])) echo $i['(name)']; ?>
	</div>
	<div class='input'>
		<?php if (!get_option($i['(ID)'])) : ?>
		<input type='file' name='<?php echo $i['(ID)']; ?>' size='40' border='0' />
		<?php else : ?>
		<p><code><img width='15' height='15' class='file-preview' src='<?php if (substr(basename(get_option($i['(ID)'])), -3) != 'ico') echo timthumb.'?q=30&h=15&w=15&zc=0&src='; ?><?php echo get_option($i['(ID)']); ?>' alt='' /> <a target='_blank' class='file-image-preview' href='<?php echo get_option($i['(ID)']); ?>'> <?php echo basename(get_option($i['(ID)'])); ?></a></code></code> <a class="delete" href="<?php echo $_SERVER['REQUEST_URI']; ?>&snipe=<?php echo base64_encode($i['(ID)']); ?>">&#10006; <?php _e('Delete', 'carta'); ?></a></p>
		<?php endif; ?>
		<?php if (isset($i['(desc)'])) : ?>
			<p><?php echo $i['(desc)']; ?></p>
		<?php endif; ?>
	</div>
	<?php if (isset($i['(hidden)'])) echo '</div>'; ?>
				
<?php
		break;
		case ':textarea':
?>
				
	<?php if (isset($i['(hidden)'])) echo "<div class='hidden'>"; ?>
	<div class='value'>
		<?php echo $i['(name)']; ?>
	</div>
	<div class='input'>
		<textarea name='<?php echo $i['(ID)']; ?>' id='<?php echo $i['(ID)']; ?>' type='<?php echo $i['::']; ?>'><?php echo (get_option($i['(ID)']) ? stripslashes(htmlspecialchars(get_option($i['(ID)']), ENT_QUOTES)) : (isset($i['(DEF)']) ? $i['(DEF)'] : '')); ?></textarea>
		<p><?php echo stripslashes(htmlspecialchars_decode($i['(desc)'])); ?></p>
	</div>
	<?php if (isset($i['(hidden)'])) echo '</div>'; ?>
				
<?php
		break;
		case ':checkbox':
?>
				
	<div class='value'>
		<?php if (isset($i['(name)'])) echo $i['(name)']; ?>
	</div>
	<div class='input cb'>
		<label class='cb-enable <?php if (get_option($i['(ID)'])) echo 'selected'; ?>'><span><?php echo (isset($i['(checkbox:left)']) ? $i['(checkbox:left)'] : __('Yes', 'carta')); ?></span></label>
		<label class='cb-disable <?php if (!get_option($i['(ID)'])) echo 'selected'; ?>'><span><?php echo (isset($i['(checkbox:right)']) ? $i['(checkbox:right)'] : __('No', 'carta')); ?></span></label>
		
		<input class='hidden' type='checkbox' name='<?php echo $i['(ID)']; ?>' id='<?php echo $i['(ID)']; ?>' <?php if (!get_settings($i['(ID)']) && isset($i['(DEF)']) == true) { echo 'checked=\'checked\''; } elseif (get_settings($i['(ID)'])) { echo 'checked=\'checked\''; } ?> />
		<div class='clear'></div>
		<?php if (isset($i['(desc)'])) : ?>
		<p><?php echo stripslashes(htmlspecialchars_decode($i['(desc)'])); ?></p>
		<?php endif; ?>
	</div>
	<div class='clear'></div>
		
<?php
		break;
		case ':select':
?>
				
	<?php if (isset($i['(hidden)'])) echo "<div class='hidden'>"; ?>				
	<div class='value'>
		<?php if (isset($i['(name)'])) echo $i['(name)']; ?>
	</div>
	<div class='input'>
		<select name='<?php echo $i['(ID)']; ?>' id='<?php echo $i['(ID)']; ?>'><?php foreach ($i['(select:list)'] as $option) { ?>
		<option<?php if (get_option($i['(ID)']) == $option) { echo ' selected="selected"';}else if (isset($i['(DEF)']) && $i['(DEF)'] == $option && !get_option($i['(ID)'])) {echo ' selected="selected"';}
		?>><?php echo $option; ?></option><?php } ?></select>
		<p><?php if (isset($i['(desc)'])) echo stripslashes(htmlspecialchars_decode($i['(desc)'])); ?> <?php if (isset($i['(addendum)'])) echo $i['(addendum)']; ?></p>
	</div>
	<div class='clear'></div>
	<?php if (isset($i['(hidden)'])) echo '</div>'; ?>

<?php
		break;
	} 
}
?>