<?php
/*
	Widgets areas setup
*/
function carta_widgets() {
	register_sidebar(array(
		'name' => __('Sidebar Area', 'carta'),
		'id' => 'sidebar',
		'description' => __('Page View', 'carta'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<div class="header"><h3>',
		'after_title' => '</h3></div>',
	));
	register_sidebar(array(
		'name' => __('Footer Left Area', 'carta'),
		'id' => 'footer1',
		'description' => __('Left Footer Area (small)', 'carta'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2>',
		'after_title' => '</h2>',
	));
	register_sidebar(array(
		'name' => __('Footer Middle Area', 'carta'),
		'id' => 'footer2',
		'description' => __('Middle Footer Area (medium)', 'carta'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2>',
		'after_title' => '</h2>',
	));
	register_sidebar(array(
		'name' => __('Footer Right Area', 'carta'),
		'id' => 'footer3',
		'description' => __('Right Footer Area (big)', 'carta'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h2>',
		'after_title' => '</h2>',
	));
	register_sidebar(array(
		'name' => __('Article View Area', 'carta'),
		'id' => 'post',
		'description' => __('Small Area in the Article View page.', 'carta'),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '',
		'after_title' => '',
	));
}
add_action('widgets_init', 'carta_widgets');

/*
	All Widgets
*/
include_once(widgets.'flickr.php');
include_once(widgets.'tweets.php');
include_once(widgets.'note.php');
include_once(widgets.'popular.php');
include_once(widgets.'ad.php');
include_once(widgets.'adsense.php');
include_once(widgets.'video.php');
?>