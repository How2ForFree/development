<?php header('Content-type: text/css'); ?>
/*
	Custom Styles Generator
*/

#head h1#logo {
<?php if (isset($_GET['1']) && is_numeric($_GET['1'])) : ?>font-size: <?php echo $_GET['1']; ?>px !important;<?php endif; ?>
<?php if (isset($_GET['2']) && is_numeric($_GET['2'])) : ?>top: <?php echo $_GET['2']; ?>px !important;<?php endif; ?>
<?php if (isset($_GET['3']) && is_numeric($_GET['3'])) : ?>left: <?php echo $_GET['3']; ?>px !important;<?php endif; ?>
<?php if (isset($_GET['4']) && is_numeric($_GET['4'])) : ?>width: <?php echo $_GET['4']; ?>px !important;<?php endif; ?>
<?php if (isset($_GET['5']) && is_numeric($_GET['5'])) : ?>height: <?php echo $_GET['5']; ?>px !important;<?php endif; ?>
<?php if (isset($_GET['6']) && preg_match('/^(http|https|ftp):\/\/([A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?/i', $_GET['6'])) : ?>background: url(<?php echo $_GET['6']; ?>) no-repeat !important;<?php endif; ?>
}

#head h1#logo a {
<?php if (isset($_GET['4']) && is_numeric($_GET['4'])) : ?>width: <?php echo $_GET['4']; ?>px !important;<?php endif; ?>
<?php if (isset($_GET['5']) && is_numeric($_GET['5'])) : ?>height: <?php echo $_GET['5']; ?>px !important;<?php endif; ?>
<?php if (isset($_GET['7']) && is_numeric($_GET['7'])) : ?>color: #<?php echo $_GET['7']; ?> !important;<?php endif; ?>
}

<?php if (isset($_GET['8']) && is_numeric($_GET['8'])) : ?>#featured { height: <?php echo $_GET['8']; ?>px !important; }<?php endif; ?>