<?php
/*
*	Form System -> jquery.wbform.js
*	Stefano Giliberti <kompulsive@gmail.com>
*	winterbits.com
*/

/*
*	Parameters
*/

$tmpl_file = 'mail-tmpl.html';

$str = array(
	'name' => 'Please enter your name.',
	'email' => 'Please enter a valid email address.',
	'website' => 'Please enter your website.',
	'message' => 'Please enter a message.',
	'success' => 'Thank you! We have received your message.',
	'unexpected' => 'An error occured. Please, try again later.'
);

/*
*	Processing
*/
if (!$_POST) exit;
if (isset($_GET['wbform'])) define('wbform', true);

$output = file_get_contents($tmpl_file);

foreach ($str as $condition => $message) define('str_'.$condition, $message);

foreach ($_POST as $input_name => $input_value) {
	$$input_name = trim(addslashes(stripslashes(strip_tags($input_value))));
	$output = str_replace('%'.strtolower($input_name).'%', $input_value, $output);
}

/*
*	Carta Contact (carta-mail.php <-> jquery.wbform.js)
*/
if (!$name) $error[count($error)] = str_name;
if (!valid_address($email)) $error[count($error)] = str_email;
if (!$message) $error[count($error)] = str_message;
// if (!$website) $error[count($error)] = str_website;

$to = base64_decode($to);
$sj = base64_decode($sj);

$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From: ".$email."\r\n";

if (!$error) proceed($to, $sj, $headers, $output); else block($error);

function proceed($to, $subject, $headers, $letter) {
	$letter = str_replace("\n", "\r\n", $letter);
	if (mail($to, $subject, $letter, $headers)) echo (defined('wbform') ? null : str_success); else echo (defined('wbform') ? 2 : str_unexpected);
}
function block($var) {
	if (defined('wbform')) echo 1; else for ($i = 0; $i < count($var); $i++) echo $var[$i].'<br />';
	
}
function valid_address($var) {
	return preg_match('/^[^0-9][A-z0-9_]+([.][A-z0-9_]+)*[@][A-z0-9_]+([.][A-z0-9_]+)*[.][A-z]{2,4}$/', $var);
}
?>