<?php
/*
	Frontpage Slider Engine
*/
global $wpdb;
$table = $wpdb->prefix.'Carta_slides';
$list = $wpdb->get_results('SELECT * FROM '.$table.' ORDER by slide_order, id');
$rt = (ca_slider_resize_type ? 0 : 1);
?>

<!-- content slider -->
<div id="featured" <?php if (ca_slider == 'Carta Accordion') : ?>class="accordion"<?php endif; ?>>
<?php if (ca_slider == 'Nivo Slider') : ?><div id="nivo"><?php endif; ?>

<?php
foreach ($list as $slide) :
$link = ($slide->slide_link != 'http://' ? $slide->slide_link : null);

if ($link) {
	if (strpos($link, 'youtube.com') !== false) {
		$media = 'youtube';
	}
	else if (strpos($link, 'vimeo.com') !== false) {
		$media = 'vimeo';
	}
	else if (preg_match('#^http:\/\/(.*)\.(gif|png|jpg|swf)$#i', $link)) {
		$media = 'media';
	}
	else {
		$media = null;
	}
}
?>

<?php if (ca_slider == 'Carta Accordion') : ?>
	<!-- slide -->
	<div class="slide" id="slide_<?php echo $slide->id ?>">
		<?php if ($link) : ?><a href="<?php echo $slide->slide_link; ?>"<?php if ($media) : ?> class="<?php echo $media ?>"<?php endif; ?>>
		<?php if ($media) : ?><div class="play"></div><?php endif; ?>
		<?php endif; ?>
		<img src="<?php if (!ca_slider_resize) echo timthumb.'?h='.ca_slider_height.'&amp;w='.(ca_accordion_custom ? ca_accordion_fullwidth : 780).'&amp;q='.ca_slider_iq.'&amp;zc='.$rt.'&amp;src='; ?><?php echo $slide->slide_picture_url ?>" alt="" />
		<?php if ($link) : ?></a><?php endif; ?>
<?php if ($slide->slide_content && $slide->slide_content_type != 'none') : ?>
		<div class="slide-content <?php echo ($slide->slide_content_type == 'caption' ? 'note' : $slide->slide_content_type); ?>">
			<p><?php echo htmlspecialchars_decode($slide->slide_content); ?></p>
		</div>
<?php endif; ?>
	</div>
<?php endif; ?>
<?php if (ca_slider == 'Nivo Slider') : ?>
		<!-- slide -->
		<?php if ($link) : ?><a href="<?php echo $slide->slide_link; ?>"<?php if ($media) : ?> class="<?php echo $media ?>"<?php endif; ?>>
		<?php if ($media) : ?><div class="play"></div><?php endif; ?>
		<?php endif; ?>
		<img <?php if ($slide->slide_content && $slide->slide_content_type != 'none') echo 'title="#caption'.$slide->id.'"'; ?> src="<?php if (!ca_slider_resize) echo timthumb.'?h='.ca_slider_height.'&amp;w=940&amp;q='.ca_slider_iq.'&amp;zc='.$rt.'&amp;src='; ?><?php echo $slide->slide_picture_url; ?>" alt="" />
		<?php if ($link) : ?></a><?php endif; ?>
<?php endif; ?>

<?php endforeach; ?>

<?php if (ca_slider == 'Nivo Slider') : ?>
	</div>
		
<?php foreach ($list as $slide) : ?>
	
<?php if ($slide->slide_content && $slide->slide_content_type != 'none') : ?>
	<div id="caption<?php echo $slide->id ?>" class="nivo-html-caption">
		<small><?php echo htmlspecialchars_decode($slide->slide_content); ?></small>
	</div>
<?php endif; ?>
		
<?php endforeach; ?>
<?php endif; ?>

</div>
<!-- closed: featured -->

<!-- featured's bottom -->
<div id="featured-tail"></div>