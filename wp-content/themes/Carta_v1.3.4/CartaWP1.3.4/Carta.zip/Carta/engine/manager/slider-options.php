<?php
/*
	Slider Options
*/
global $wpdb;
$table = $wpdb->prefix.'Carta_slides';
$slides = (ca_alt_slides_manager ? get_posts('post_type=carta-slides') : $wpdb->get_results('SELECT id FROM '.$table));
$i = 0;
$slidesarray = array();
foreach ($slides as $slide) {
	$i++;
	$slidesarray[$i] = $i;
}

$slideroptions = array();

$preferences = array(
		array('::' => '::open', 'white' => true),
	
		array(
			'(name)' => __('Preferences', 'carta'),
			'::' => ':title'
		),
		array(
			'(name)' => __('Slider Height', 'carta'),
			'(ID)' => 'ca_slider_height',
			'(DEF)' => 308,
			'::' => ':slider',
			'(slider:type)' => 3
		),
		array(
			'(name)' => __('TimThumb', 'carta'),
			'(ID)' => 'ca_slider_resize',
			'(desc)' => __('TimThumb automatically resizes images that are too big for the Slider.', 'carta'),
			'::' => ':checkbox',
			'(checkbox:left)' => __('Off', 'carta'),
			'(checkbox:right)' => __('On', 'carta')
		),
		array(
			'(ID)' => 'ca_slider_iq',
			'(DEF)' => 75,
			'::' => ':slider',
			'(slider:type)' => 5,
			'(desc)' => __('Images Quality', 'carta')
		),
		array(
			'(ID)' => 'ca_slider_resize_type',
			'::' => ':checkbox',
			'(checkbox:left)' => __('Normal', 'carta'),
			'(checkbox:right)' => __('Crop', 'carta')
		),
		
		array('::' => '::close'),
);

$cartaaccordion = array(
	array('::' => '::open'),

	array(
		'(name)' => __('Carta Accordion', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Use Custom Settings', 'carta'),
		'(ID)' => 'ca_accordion_custom',
		'::' => ':checkbox'
	),
	array(
		'(name)' => __('Start Slide', 'carta'),
		'(ID)' => 'ca_accordion_first',
		'(desc)' => __('What slide to open on start', 'carta'),
		'::' => ':select',
		'(select:list)' => $slidesarray,
	),
	array(
		'(name)' => __('Full Width', 'carta'),
		'(ID)' => 'ca_accordion_fullwidth',
		'(desc)' => __('The open slide width', 'carta'),
		'(DEF)' => 750,
		'::' => ':slider',
		'(slider:type)' => 3
	),
	array(
		'(name)' => __('Drop shadow', 'carta'),
		'(ID)' => 'ca_accordion_dropshadow',
		'::' => ':checkbox',
		'(checkbox:left)' => __('On', 'carta'),
		'(checkbox:right)' => __('Off', 'carta')
	),
	array(
		'(name)' => __('Overlay Color', 'carta'),
		'(ID)' => 'ca_accordion_hovercolor',
		'(desc)' => __('Closed slides overlay color', 'carta'),
		'(DEF)' => 'ff4287',
		'::' => ':picker'
	),
	array(
		'(name)' => __('Overlay Opacity', 'carta'),
		'(ID)' => 'ca_accordion_hoveropacity',
		'(desc)' => __('Closed slides overlay opacity', 'carta'),
		'(DEF)' => '0.8',
		'::' => ':slider',
		'(slider:type)' => 1
	),
	array(
		'(name)' => __('Speed', 'carta'),
		'(ID)' => 'ca_accordion_speed',
		'(desc)' => __('Opening and closing animation speed', 'carta'),
		'(DEF)' => 1000,
		'::' => ':slider',
		'(slider:type)' => 2
	),
	array(
		'(name)' => __('Animation Easing', 'carta'),
		'(ID)' => 'ca_accordion_easing',
		'(desc)' => __('Advanced animation style', 'carta'),
		'::' => ':select',
		'(select:list)' => array(
			'easeInQuad',
			'easeOutQuad',
			'easeInOutQuad',
			'easeInCubic',
			'easeOutCubic',
			'easeInOutCubic',
			'easeInQuart',
			'easeOutQuart',
			'easeInOutQuart',
			'easeInQuint',
			'easeOutQuint',
			'easeInOutQuint',
			'easeInSine',
			'easeOutSine',
			'easeInOutSine',
			'easeInExpo',
			'easeOutExpo',
			'easeInOutExpo',
			'easeInCirc',
			'easeOutCirc',
			'easeInOutCirc',
			'easeInElastic',
			'easeOutElastic',
			'easeInOutElastic',
			'easeInBack',
			'easeOutBack',
			'easeInOutBack',
			'easeInBounce',
			'easeOutBounce',
			'easeInOutBounce',
		)
	),
	array('::' => '::close')
);

$nivoslider = array(
	array('::' => '::open'),

	array(
		'(name)' => __('Nivo Slider Settings', 'carta'),
		'::' => ':title'
	),
	array(
		'(name)' => __('Use Custom Settings', 'carta'),
		'(ID)' => 'ca_nivoslider_custom',
		'::' => ':checkbox'
	),
	array(
		'(name)' => __('Effect', 'carta'),
		'(ID)' => 'ca_nivoslider_effect',
		'::' => ':select',
		'(desc)' => __('The transition effect', 'carta'),
		'(select:list)' => array(
			'random',
			'sliceDown',
			'sliceDownLeft',
			'sliceUp',
			'sliceUpLeft',
			'sliceUpDown',
			'sliceUpDownLeft',
			'fold',
			'fade'
		)
	),
	array(
		'(name)' => __('Split in', 'carta'),
		'(ID)' => 'ca_nivoslider_slices',
		'::' => ':plusminus',
		'(desc)' => __('slices', 'carta'),
		'(DEF)' => 5
	),
	array(
		'(name)' => __('Animation Speed', 'carta'),
		'(ID)' => 'ca_nivoslider_speed',
		'(desc)' => __('Slide transition speed', 'carta'),
		'(DEF)' => 1000,
		'::' => ':slider',
		'(slider:type)' => 2
	),
	array(
		'(name)' => __('Delay Time', 'carta'),
		'(ID)' => 'ca_nivoslider_pause',
		'(desc)' => __('The pause time between slides in milliseconds (<code>1000</code> : 1 second)', 'carta'),
		'::' => 'text',
		'(DEF)' => '5000',
		'::' => ':slider',
		'(slider:type)' => 2
	),
	array(
		'(name)' => __('Start Slide', 'carta'),
		'(ID)' => 'ca_nivoslider_start',
		'(desc)' => __('What slide to show on start', 'carta'),
		'::' => ':select',
		'(select:list)' => $slidesarray,
	),
	array(
		'(name)' => __('Direction Controls', 'carta'),
		'(ID)' => 'ca_nivoslider_nav',
		'::' => ':checkbox',
		'(checkbox:left)' => __('On', 'carta'),
		'(checkbox:right)' => __('Off', 'carta')
	),
	array(
		'(name)' => __('Show Direction Arrows', 'carta'),
		'(ID)' => 'ca_nivoslider_navhide',
		'::' => ':checkbox',
		'(checkbox:left)' => __('Hover', 'carta'),
		'(checkbox:right)' => __('Always', 'carta')
	),
	array(
		'(name)' => __('Controls', 'carta'),
		'(ID)' => 'ca_nivoslider_controls',
		'(desc)' => __('Dots Controls', 'carta'),
		'::' => ':checkbox',
		'(checkbox:left)' => __('On', 'carta'),
		'(checkbox:right)' => __('Off', 'carta')
	),
	array(
		'(name)' => __('Keyboard Navigation', 'carta'),
		'(ID)' => 'ca_nivoslider_keyboard',
		'(desc)' => __('Use left &amp; right arrows', 'carta'),
		'::' => ':checkbox',
		'(checkbox:left)' => __('On', 'carta'),
		'(checkbox:right)' => __('Off', 'carta')
	),
	array(
		'(name)' => __('Pause on Hover', 'carta'),
		'(ID)' => 'ca_nivoslider_hover',
		'(desc)' => __('Stop animation while hovering', 'carta'),
		'::' => ':checkbox'
	),
	array(
		'(name)' => __('Manual Transition', 'carta'),
		'(ID)' => 'ca_nivoslider_manual',
		'(desc)' => __('Force manual transitions', 'carta'),
		'::' => ':checkbox'
	),
	array(
		'(name)' => __('Caption Opacity', 'carta'),
		'(ID)' => 'ca_nivoslider_opacity',
		'(desc)' => __('Slides caption opacity', 'carta'),
		'(DEF)' => '0.8',
		'::' => ':slider',
		'(slider:type)' => 1
	),
	
	array('::' => '::close')
);

if (ca_slider == 'Carta Accordion') {
	$slideroptions = $cartaaccordion;
}
else if (ca_slider == 'Nivo Slider') {
	$slideroptions = $nivoslider;
}
?>