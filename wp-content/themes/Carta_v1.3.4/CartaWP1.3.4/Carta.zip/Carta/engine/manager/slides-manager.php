<?php
/*
	Slides Manager
*/
global $wpdb, $preferences, $cartaaccordion, $nivoslider, $slideroptions;
$options = $slideroptions;
$table = $wpdb->prefix.'Carta_slides';

if (!ca_alt_slides_manager) if (!carta_sm_check($table, $wpdb)) carta_sm_create($table, $wpdb);
if (is_wb() && isset($_GET['regenerate'])) carta_sm_regenerate($table, $wpdb);

function carta_sm_check($table, $wpdb) {
    if (!$wpdb->query('SELECT id FROM '.$table)) {
    	return false;
    } else {
    	return true;
    }
}

function carta_sm_create($table, $wpdb) {
	$wpdb->query('
		CREATE TABLE '.$table.' (
	        id INT(9) NOT NULL AUTO_INCREMENT,
	        slide_content_type VARCHAR(255) NOT NULL,
	        slide_content VARCHAR(255) NOT NULL,
	        slide_picture_url VARCHAR(255) NOT NULL,
	        slide_link VARCHAR(255) NOT NULL,
	        slide_order INT(100) NOT NULL,
			UNIQUE KEY id (id)
		);
	');
}

function carta_sm_regenerate($table, $wpdb) {
	if (carta_sm_check($table, $wpdb)) {
		$wpdb->query('DROP TABLE '.$table);
		carta_sm_create($table, $wpdb);
	}
}

function carta_sm_fetch($table, $wpdb) {
	$slides = $wpdb->get_results('SELECT * FROM '.$table.' ORDER by slide_order, id');
	foreach ($slides as $slide) {
	?>
		
		<form method='post' enctype='multipart/form-data' action=''>
			<input type='hidden' name='slide_id' value='<?php echo $slide->id ?>' />
		
			<div class='stuffbox slide' id='slide_<?php echo $slide->id ?>'>
				<h3><label>Slide <?php echo $slide->id ?></label></h3>
				<div class='inside'>
					
					<?php $order = ($slide->slide_order ? $slide->slide_order : $slide->id); ?>
					<div class='order'><a href='#' class='plusminus'>+</a> <a href='#' class='plusminus'>-</a> <input type='text' class='two pmbuddy' name='slide_order' border='0' value='<?php echo $order ?>' readonly /></div>

					<div class='value'><?php _e('Content type', 'carta') ?></div>
					<div class='input'>
						<select name='slide_content_type'>
							<option value='none' <?php if ($slide->slide_content_type == 'none' || !$slide->slide_content) echo 'selected'; ?>><?php _e('No content', 'carta') ?></option>
<?php if (ca_slider == 'Carta Accordion') : ?>
							<option value='note' <?php if ($slide->slide_content_type == 'note' || $slide->slide_content_type == 'caption') echo 'selected'; ?>><?php _e('Note', 'carta') ?></option>
							<option value='postit' <?php if ($slide->slide_content_type == 'postit') echo 'selected'; ?>><?php _e('Post-it', 'carta') ?></option>
<?php endif; if (ca_slider == 'Nivo Slider') : ?>
							<option value='caption' <?php if ($slide->slide_content_type && $slide->slide_content_type != 'none') echo 'selected'; ?>><?php _e('Caption', 'carta') ?></option>
<?php endif; ?>
						</select>
						<p><textarea name='slide_content'><?php echo $slide->slide_content; ?></textarea></p>
					</div>
					<div class='clear'></div>
					
					<div class='value'><?php _e('Slide link', 'carta') ?></div>
					<div class='input'>
						<input name='slide_link' type='text' value='<?php echo $slide->slide_link ?>' />
					</div>
					<div class='clear'></div>
					
					<div class='value'><?php _e('Slide picture', 'carta') ?></div>
					<div class='input'>
						<input type='file' name='slide_pic' size='40' border='0' />
						<?php if ($slide->slide_picture_url) : ?>
						<p><code><img width='80' height='12' class='slide-preview' src='<?php echo timthumb.'?q=50&h=12&w=80&zc=1&src='; ?><?php echo $slide->slide_picture_url ?>' alt='' /> <a target='_blank' class='file-image-preview' href='<?php echo $slide->slide_picture_url ?>'><?php echo basename($slide->slide_picture_url); ?></a></code></p>
						<?php endif; ?>
					</div>
					<div class='clear'></div>
					
					<div class='delete'><?php _e('Delete', 'carta') ?> <input type='checkbox' name='delete' value='false' /></div>
					<input name='update' type='submit' class='button update' value='<?php _e('Update', 'carta'); ?>' />
					<div class='load'><img src='<?php echo includes.'images/load.gif'; ?>' /></div>
				</div>
			</div>
			
			<input type='hidden' name='action' value='update' />
		</form>
		
	<?php
	}
}

if (is_wb() && isset($_REQUEST['action'])) {
	switch ($_REQUEST['action']) {
		case 'add':
			$value = stripslashes(htmlspecialchars($_POST['slide_content']));
			$file = $_FILES['slide_pic'];
			$type = $_POST['slide_content_type'];
			$link = (trim($_POST['slide_link']) ? $_POST['slide_link'] : 'http://');
			
			if (isset($file) && substr($file['type'], 0, 5) == 'image') {
				$wupload = wp_handle_upload($file, array('test_form' => false));
				$wurl = $wupload['url'];
			} else {
				$wurl = null;
			}
			
			$wpdb->insert(
				$table, 
				array(
					'slide_content' => $value,
					'slide_content_type' => $type,
					'slide_link' => $link,
					'slide_picture_url' => $wurl
				)
			);
		
		break;
		case 'update':
			$id = $_POST['slide_id'];
			$value = stripslashes(htmlspecialchars($_POST['slide_content']));
			$file = $_FILES['slide_pic'];
			$type = $_POST['slide_content_type'];
			$link = (trim($_POST['slide_link']) ? $_POST['slide_link'] : 'http://');
			$order = $_POST['slide_order'];
			
			if (isset($_POST['delete'])) {
				$wpdb->query($wpdb->prepare('DELETE FROM '.$table.' WHERE id='.$id));
				$wpdb->query($wpdb->prepare('ALTER TABLE '.$table.' AUTO_INCREMENT=1'));
			} else {
				
				if (isset($file) && substr($file['type'], 0, 5) == 'image') {
					$wupload = wp_handle_upload($file, array('test_form' => false));
					$wurl = $wupload['url'];
					$wpdb->update($table, array('slide_picture_url' => $wurl), array('id' => $id));
				}
						
				$wpdb->update(
					$table,
					array(
						'slide_content' => $value,
						'slide_content_type' => $type,
						'slide_link' => $link,
						'slide_order' => $order
					),
					array(
						'id' => $id
					)
				);
				
			}
		
		break;
		case 'set':
			foreach ($options as $i) {
				update_option(@$i['(ID)'], @$_REQUEST[$i['(ID)']]);
			}
	
		break;
		case 'reset':
			foreach ($options as $i) {
				delete_option(@$i['(ID)']);
			}
			
		break;
	}
}
?>

<div class='wrap options-wrap' id='poststuff'>
	<div id='tabs'>
	
		<ul id='tab-items'>
<?php if (!ca_alt_slides_manager) : ?>
			<li><a href='#tabs-manager'><?php _e('Manage', 'carta') ?></a></li>
<?php endif; ?>
			<li><a href='#tabs-options'><?php echo ca_slider ?></a></li>
			<li><a href='#tabs-reset'><?php _e('Reset', 'carta') ?></a></li>

<?php if (!ca_alt_slides_manager) : ?>
			<li id='save'>
				<input name='save' type='submit' class='button new-slide' value='<?php _e('Add New Slide', 'carta') ?>' />
			</li>
<?php endif; ?>
		</ul>
		
<?php
if (isset($_REQUEST['action'])) {
	switch ($_REQUEST['action']) {
		case 'add':
			echo "<div class='options-message pop updated'><p><strong>".__('Slide added!', 'carta').'</strong></p></div>';
		
		break;
		case 'update':
			echo "<div class='options-message pop updated'><p><strong>Slide ".$_POST['slide_id'];
			echo (isset($_POST['delete']) ? ' '.__('deleted', 'carta').'' : ' '.__('updated!', 'carta').'');
			echo '</strong></p></div>';
		
		break;
		case 'set':
			echo "<div class='options-message pop updated'><p><strong>".__('Options updated!', 'carta').'</strong></p></div>';
			
		break;
		case 'reset':
			echo "<META HTTP-EQUIV='refresh' CONTENT='0'>";
			
		break;
	}
}
?>		

<?php if (!ca_alt_slides_manager) : ?>	
		<div id='tabs-manager' class='slide-manager'>
		
			<form method='post' action='' enctype='multipart/form-data' id='new-slide-form'>
				<div class='stuffbox white'>
					<h3><label><?php _e('New Slide', 'carta') ?></label></h3>
					<div class='inside'>
	
						<div class='value'><?php _e('Content type', 'carta') ?></div>
						<div class='input'>
							<select name='slide_content_type'>
								<option value='none'><?php _e('No content', 'carta') ?></option>
<?php if (ca_slider == 'Carta Accordion') : ?>
								<option value='note'><?php _e('Note (bottom)', 'carta') ?></option>
								<option value='postit'><?php _e('Post-it (top-right box)', 'carta') ?></option>
<?php endif; if (ca_slider == 'Nivo Slider') : ?>
							<option value='caption'><?php _e('Caption', 'carta') ?></option>
<?php endif; ?>
							</select>
							<p><textarea name='slide_content'></textarea></p>
						</div>
						<div class='clear'></div>
						
						<div class='value'><?php _e('Slide link', 'carta') ?></div>
						<div class='input'>
							<input name='slide_link' type='text' value='http://' />
						</div>
						<div class='clear'></div>
						
						<div class='value'><?php _e('Slide picture', 'carta') ?></div>
						<div class='input'>
							<input type='file' name='slide_pic' size='40' border='0' />
						</div>
						<div class='clear'></div>
						
						<input name='add' type='submit' class='button-primary' value='<?php _e('Add Slide', 'carta') ?>' />
						<div class='load'><img src='<?php echo includes.'images/load.gif'; ?>' /></div>
						<input type='hidden' name='action' value='add' />
					</div>
				</div>
			</form>

<?php carta_sm_fetch($table, $wpdb); ?>
			
		</div>
<?php endif; ?>

		<div id='tabs-options'>
			
			<form method='post' action='' enctype='multipart/form-data'>
			
<?php include_once(dir.'framework/options-layout.php'); ?>
				
				<input name='set' type='submit' class='button-primary' value='<?php _e('Save Changes', 'carta') ?>' />
				<input type='hidden' name='action' value='set' />
			</form>
			
		</div>
		
		<div id='tabs-reset'>
			<div class='stuffbox white'>
				<h3><label><?php _e('Reset Settings', 'carta') ?></label></h3>
				<div class='inside'>
					<form method='post'>
						<p class='submit'>
							<input name='reset' type='submit' value='Reset' />
							<input type='hidden' name='action' value='reset' />
							<code><?php _e('Warning!', 'carta') ?></code> <?php _e('This operation is irreversible.', 'carta') ?> <?php _e('(Slides will not be deleted)', 'carta') ?>
							<p><em><?php _e('or', 'carta') ?></em> <a href="<?php echo $_SERVER['REQUEST_URI']; ?>&regenerate"><?php _e('Regenerate Tables', 'carta') ?></a> <?php _e('(Slides will be deleted)', 'carta') ?></p>
						</p>
					</form>
				</div>
			</div>
		</div>
		
</div>
</div>