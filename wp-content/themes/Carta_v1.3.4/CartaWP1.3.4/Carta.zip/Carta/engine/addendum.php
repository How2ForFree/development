<?php
/*
	WP 3 custom menu
*/
function carta_menu() {
	register_nav_menus(array('primary' => __('Head Menu', 'carta')));
}
class carta_menu extends Walker_Nav_Menu {
	function start_el($output, $item, $depth, $args) {
		global $wp_query;
		$class_names = $value = '';
		$classes = empty($item->classes) ? array() : (array) $item->classes;
		$class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item));
		$class_names = '';
		$output .= '<li id="li-'.$item->ID.'"'.$value.$class_names.'>';
		$attributes = !empty($item->target) ? ' target="'.esc_attr($item->target).'"' : '';
		$attributes .= !empty($item->xfn) ? ' rel="'.esc_attr($item->xfn).'"' : '';
		$attributes .= !empty($item->url) ? ' href="'.esc_attr($item->url).'"' : '';
		$item_output = '';
		if (isset($args->before)) $item_output .= $args->before;
		$item_output .= '<a'.$attributes.'>';
		if ($depth < 1) {
			$item_output .= '<strong>';
			if (isset($args->link_before)) $item_output .= $args->link_before;
			if (isset($item->title)) $item_output .= apply_filters('the_title', $item->title, $item->ID);
			if (isset($args->link_after)) $item_output .= $args->link_after;
			$item_output .= '</strong>';
			if (isset($item->attr_title)) {
				$item_output .= '<span>';
				$item_output .= $item->attr_title;
				$item_output .= '</span>';
			}
		} else {
			if (isset($args->link_before)) $item_output .= $args->link_before;
			$item_output .= apply_filters('the_title', $item->title, $item->ID);
			if (isset($args->link_after)) $item_output .= $args->link_after;
		}
		$item_output .= '</a>';
		if (isset($args->after)) $item_output .= $args->after;
		$output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
	}
}
add_action('init', 'carta_menu');

/*
	Projects custom post types
*/
if (!ca_projects_disable) {
	register_post_type('project', array(
		'label' => (trim(ca_projects_label) ? ca_projects_label : __('Projects', 'carta')),
		'labels' => array('add_new_item' => __('New Project', 'carta')),
		'public' => true,
		'show_ui' => true,
		'menu_icon' => includes.'ui/projects_ui.png',
		'capability_type' => 'post',
		'rewrite' => array('slug' => ca_projects_rewrite),
		'menu_position' => 5,
		'hierarchical' => false,
		'supports' => array('title', 'editor', 'excerpt', 'thumbnail', 'custom-fields')
	));
	if (!ca_projects_filtering) register_taxonomy('kind', 'project', array('hierarchical' => true, 'label' => __('Types', 'carta')));
}

/*
	Gallery custom post types
*/
if (!ca_gallery_disable) {
	register_post_type('gallery', array(
		'label' => (trim(ca_gallery_label) ? ca_gallery_label : __('Gallery', 'carta')),
		'labels' => array('add_new' => __('Add New Box', 'carta'), 'add_new_item' => __('New Gallery Box', 'carta')),
		'public' => true,
		'show_ui' => true,
		'menu_icon' => includes.'ui/gallery_ui.png',
		'exclude_from_search' => true,
		'capability_type' => 'post',
		'menu_position' => 5,
		'hierarchical' => false,
		'supports' => array('title', 'excerpt', 'thumbnail', 'custom-fields')
	));
	if (!ca_gallery_filtering) register_taxonomy('types', 'gallery', array('hierarchical' => true, 'label' => __('Types', 'carta')));
}

/*
	Simplified Slides Manager
*/
if (ca_alt_slides_manager) {
	register_post_type('carta-slides', array(
		'label' => __('Slides', 'carta'),
		'labels' => array('add_new' => __('Add New Slide', 'carta'), 'add_new_item' => __('New Slide', 'carta')),
		'public' => true,
		'show_ui' => true,
		'menu_icon' => includes.'ui/smanager_ui.png',
		'capability_type' => 'post',
		'menu_position' => 5,
		'hierarchical' => false,
		'supports' => array('title', 'excerpt', 'thumbnail', 'custom-fields')
	));
}

/*
	Support for post thumbnails (for Projects and Gallery)
*/
add_theme_support('post-thumbnails');

/*
	Custom WP login logo
*/
function loginlogo() {
    echo '<style type="text/css">h1 a { background-image:url('.ca_file_extra_login.') !important }</style>';
}
add_action('login_head', 'loginlogo');

/*
	Custom Gravatar image
*/
function gravatar($avatar_defaults) {
    $avatar_defaults[ca_file_extra_gravatar] = get_bloginfo('name').' Gravatar';
    return $avatar_defaults;
}
add_filter('avatar_defaults', 'gravatar');

/*
	Custom next/prev posts link
*/
function nextlink() {
	return 'class="right"';
}
function prevlink() {
	return 'class="left"';
}
add_filter('previous_posts_link_attributes', 'prevlink');
add_filter('next_posts_link_attributes', 'nextlink');
?>