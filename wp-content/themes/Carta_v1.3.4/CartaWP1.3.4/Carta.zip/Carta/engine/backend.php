<?php
/*
	Options scripts & stylesheets
*/
function carta_backend_includes() {
	wp_deregister_script('jquery-ui-core');
	wp_register_style('options-style', includes.'options-style.css');
	wp_enqueue_style('options-style');
	wp_register_script('jui-custom', includes.'jquery-ui-1.8.8.custom.min.js', array('jquery'));
	wp_enqueue_script('jui-custom');
	wp_register_script('jcookie', includes.'jquery.cookie.js', array('jquery'));
	wp_enqueue_script('jcookie');
	wp_register_script('jcolorpicker', includes.'colorpicker.js', array('jquery'));
	wp_enqueue_script('jcolorpicker');
	wp_register_script('options-scripts', includes.'options-scripts.js', array('jquery'));
	wp_enqueue_script('options-scripts');
}
if (is_wb()) add_action('admin_enqueue_scripts', 'carta_backend_includes');

/*
	Carta options page
*/
function carta_admin() {
	add_menu_page(ca_opn, ca_opn, 'edit_themes', 'carta-panel', 'carta_panel', timthumb.'?h=16&amp;w=16&amp;src='.ca_file_opn_ico);
}

include_once(dir.'carta/carta-options.php');

function carta_panel() {
	include_once(dir.'carta/carta-panel.php');
}

add_action('admin_menu', 'carta_admin');
wb_fetch_options($options);

/*
	Carta Slides Manager
*/
function carta_manager() {
	add_menu_page(ca_opn.' '.(ca_alt_slides_manager ? __('Slider Options', 'carta') : __('Slides Manager', 'carta')), __(ca_alt_slides_manager ? __('Slider Options', 'carta') : __('Slides Manager', 'carta')), 'edit_themes', 'slides-manager', 'carta_slides_manager', (ca_alt_slides_manager ? includes.'ui/soptions_ui.png' : includes.'ui/smanager_ui.png'));
}

include_once(dir.'manager/slider-options.php');

function carta_slides_manager() {
	include_once(dir.'manager/slides-manager.php');
}

if (ca_slider != 'None') add_action('admin_menu', 'carta_manager');

$slideroptions = array_merge($preferences, $slideroptions);
wb_fetch_options($slideroptions);

/*
	Refining Theme Options
*/
$td = explode('_', substr(ca_theme, 0, -4));
define('ca_theme_rd', $td[0]);
define('ca_projects_rewrite', str_replace(' ', '-', preg_replace('/[^a-zA-Z0-9\s]/', '', ca_projects_slug)));

/*
	Utility functions
*/
function wb_fetch_options($array) {
	foreach ($array as $i) {
	    if (isset($i['(ID)'])) {
	    	if (get_option($i['(ID)'])) {
	    		define($i['(ID)'], get_option($i['(ID)']));
	    	} else {
	    		define($i['(ID)'], (isset($i['(DEF)']) ? $i['(DEF)'] : false));
	    	}
	    }
	}
}

function check_ini($ini) {
	if (!ini_get($ini)) {
	    ini_set($ini, 1);
	    if (!ini_get($ini)) return false;
	} else {
		return true;
	}
}

function is_wb() {
	if (isset($_GET['page']) && $_GET['page'] == 'carta-panel' || isset($_GET['page']) && $_GET['page'] == 'slides-manager') return true;
}

function carta_update($action) {
	if (check_ini('allow_url_fopen')) {
		$helper = 'http://carta.winterbits.com/__helper/version.txt';
		$ver = file_get_contents($helper, null, null, 0, 5);
	}
	switch ($action) {
		case 1:
			if (cartaver < $ver) return true;
		break;
		case 2:
			$list = '<h2>Carta <b>'.$ver.'</b> '.__('Available', 'carta').'</h2>';
			$list .= '<small>'.__('Changelog', 'carta').'</small>';
			$list .= '<code>'.file_get_contents($helper, null, null, 5).'</code>';
			$list .= '<hr />';
			$list .= '<p><a href="http://themeforest.net/item/carta-all-in-one-premium-wordpress/142621">'.__('Download page','carta').'</a></p>';
			return $list;
		break;
	}
}

/*
	Custom Functions to get Youtube & Vimeo Video IDs
*/
function wb_get_video_id($raw, $victim) {
	$id = $raw;
	switch ($victim) {
		case 'youtube.com':
			$length = 11;
			$starts = strpos($id, '?v=');
			if ($starts === FALSE) $starts = strpos($id, '&v=');
			$starts +=3;
			$id = substr($id, $starts, $length);
			return $id;
		break;
		case 'vimeo.com':
			$length = 8;
			$starts = strpos($id, 'vimeo.com/');
			$starts +=10;
			$id = substr($id, $starts, $length);
			return $id;
		break;
	}
}
function wb_get_video_thumb($id, $victim) {
	switch ($victim) {
		case 'youtube.com':
			return 'http://img.youtube.com/vi/'.$id.'/0.jpg';
		break;
		case 'vimeo.com':
			if (check_ini('allow_url_fopen')) :
				$xml = unserialize(file_get_contents("http://vimeo.com/api/v2/video/$id.php"));
				$pic = @$xml[0]['thumbnail_large'];
				return $pic;
			endif;
		break;
	}
}
?>