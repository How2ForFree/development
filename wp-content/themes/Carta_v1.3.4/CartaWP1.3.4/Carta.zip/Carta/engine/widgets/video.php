<?php
/*
	Carta Widget: Video Embed
	Author: Stefano Giliberti, winterbits.com
*/

add_action('widgets_init', 'ca_video_widget');

function ca_video_widget() {
	register_widget('ca_video_widget');
}

class ca_video_widget extends WP_Widget {
	
	function ca_video_widget() {
	
		$widget = array(
			'classname' => 'ca_video_widget',
			'description' => __('Embed any video in any Widget Area.', 'carta')
		);
		
		$setup = array(
			'width' => 340
		);
		
		$this->WP_Widget('ca_video_widget', __('Carta: Video Embed', 'carta'), $widget, $setup);
	}
	
	function form($data) {

		/* Defaults */
		$defaults = array(
			'title' => 'Video',
			'size' => '380x214'
		);
		
		$data = wp_parse_args((array) $data, $defaults); ?>

		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $data['title']; ?>" />
		</p>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('source'); ?>"><?php _e('Website', 'carta') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('source'); ?>" name="<?php echo $this->get_field_name('source'); ?>">
				<option <?php if ($data['source'] == "Youtube") echo 'selected="selected"'; ?>>Youtube</option>
				<option <?php if ($data['source'] == "Vimeo") echo 'selected="selected"'; ?>>Vimeo</option>
			</select>
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('url'); ?>"><?php _e('Video Url', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('url'); ?>" name="<?php echo $this->get_field_name('url'); ?>" value="<?php echo $data['url']; ?>" />
		</p>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('size'); ?>"><?php _e('Video size', 'carta') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('size'); ?>" name="<?php echo $this->get_field_name('size'); ?>">
				<optgroup label="Left Footer Area and Sidebar Area">
					<option <?php if ($data['size'] == "220x124") echo 'selected="selected"'; ?>>220x124</option>
				</optgroup>
				<optgroup label="Middle Footer Area">
					<option <?php if ($data['size'] == "300x169") echo 'selected="selected"'; ?>>300x169</option>
				</optgroup>
				<optgroup label="Right Footer Area">
					<option <?php if ($data['size'] == "380x214") echo 'selected="selected"'; ?>>380x214</option>
				</optgroup>
			</select>
		</p>
				
	<?php
	}
	
	function update($new_data, $old_data) {
		$data = $old_data;

		$data['title'] = strip_tags($new_data['title']);
		$data['source'] = $new_data['source'];
		$data['url'] = $new_data['url'];
		$data['size'] = $new_data['size'];
		
		return $data;
	}
	
	function widget($args, $data) {
		extract($args);
		echo $before_widget;

		if ($data['title']) echo $before_title.apply_filters('widget_title', $data['title']).$after_title;
		
		$size = explode("x", $data['size']);
		
		if ($data['source'] == 'Youtube') {
			$id = wb_get_video_id($data['url'], 'youtube.com');
			$size[1] = $size[1] + 25;
			$embed = '
			<object type="application/x-shockwave-flash" style="width:'.$size[0].'px; height:'.$size[1].'px;" data="http://www.youtube.com/v/'.$id.'&amp;hl=en_US&amp;fs=1&amp;">
				<param name="movie" value="http://www.youtube.com/v/'.$id.'&amp;fs=1&amp;" />
			</object>';
		} else {
			$id = wb_get_video_id($data['url'], 'vimeo.com');
			$embed = '<iframe src="http://player.vimeo.com/video/'.$id.'?title=0&amp;portrait=0" width="'.$size[0].'" height="'.$size[1].'" frameborder="0"></iframe>';
		}
		
		echo $embed;
				
		echo $after_widget;
	}
}
?>