<?php
/*
	Carta Widget: Note
	Author: Stefano Giliberti, winterbits.com
*/

add_action('widgets_init', 'ca_note_widget');

function ca_note_widget() {
	register_widget('ca_note_widget');
}

class ca_note_widget extends WP_Widget {
	
	function ca_note_widget() {
	
		$widget = array(
			'classname' => 'ca_note_widget',
			'description' => __('Originally the "Get in touch" note.', 'carta')
		);
		
		$setup = array(
			'width' => 340
		);

		$this->WP_Widget('ca_note_widget', __('Carta: Note', 'carta'), $widget, $setup);
	}
	
	function form($data) {

		/* Defaults */
		$defaults = array(
			'message' => '',
			'linktext' => 'Get in touch',
			'link' => 'http://'
		);
		
		$data = wp_parse_args((array) $data, $defaults); ?>
		
		<p>This widget fits properly in the <code>Footer Right Area</code>.</p>
		
		<!-- textarea -->
		<p>
			<label for="<?php echo $this->get_field_id('count'); ?>"><?php _e('Message', 'carta') ?></label>
			<textarea style="12px" rows="5" class="widefat" id="<?php echo $this->get_field_id('message'); ?>" name="<?php echo $this->get_field_name('message'); ?>"><?php echo $data['message']; ?></textarea>
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('linktext'); ?>"><?php _e('Link Text', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('linktext'); ?>" name="<?php echo $this->get_field_name('linktext'); ?>" value="<?php echo $data['linktext']; ?>" />
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('link'); ?>"><?php _e('Url', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('link'); ?>" name="<?php echo $this->get_field_name('link'); ?>" value="<?php echo $data['link']; ?>" />
		</p>
		
	<?php
	}
	
	function update($new_data, $old_data) {
		$data = $old_data;

		$data['message'] = strip_tags($new_data['message']);
		$data['linktext'] = $new_data['linktext'];
		$data['link'] = $new_data['link'];

		return $data;
	}
	
	function widget($args, $data) {
		extract($args);
		echo $before_widget;

		 ?>
		
			<div>
				<p><em><?php echo $data['message'] ?></em></p>
				<?php if ($data['linktext']) : ?>
				<a class="goto" href="<?php echo $data['link'] ?>"><?php echo $data['linktext'] ?></a>
				<?php endif; ?>
			</div>
		
		<?php

		echo $after_widget;
	}
}
?>