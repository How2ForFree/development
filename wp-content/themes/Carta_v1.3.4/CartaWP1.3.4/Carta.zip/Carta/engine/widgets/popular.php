<?php
/*
	Carta Widget: Popular Posts
	Author: Stefano Giliberti, winterbits.com
*/

add_action('widgets_init', 'ca_popular_widget');

function ca_popular_widget() {
	register_widget('ca_popular_widget');
}

class ca_popular_widget extends WP_Widget {
	
	function ca_popular_widget() {
	
		$widget = array(
			'classname' => 'ca_popular_widget',
			'description' => __('The most commented posts.', 'carta')
		);

		$this->WP_Widget('ca_popular_widget', __('Carta: Popular Posts', 'carta'), $widget);
	}
	
	function form($data) {

		/* Defaults */
		$defaults = array(
			'title' => 'Popular Stuff',
			'posts' => 6
		);
		
		$data = wp_parse_args((array) $data, $defaults); ?>

		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $data['title']; ?>" />
		</p>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('posts'); ?>"><?php _e('How many posts?', 'carta') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('posts'); ?>" name="<?php echo $this->get_field_name('posts'); ?>">
				<option <?php if ($data['posts'] == 3) echo 'selected="selected"'; ?>>3</option>
				<option <?php if ($data['posts'] == 6) echo 'selected="selected"'; ?>>6</option>
				<option <?php if ($data['posts'] == 9) echo 'selected="selected"'; ?>>9</option>
				<option <?php if ($data['posts'] == 12) echo 'selected="selected"'; ?>>12</option>
				<option <?php if ($data['posts'] == 15) echo 'selected="selected"'; ?>>15</option>
			</select>
		</p>
		
	<?php
	}
	
	function update($new_data, $old_data) {
		$data = $old_data;

		$data['title'] = strip_tags($new_data['title']);
		$data['posts'] = $new_data['posts'];

		return $data;
	}
	
	function widget($args, $data) {
		extract($args);
		echo $before_widget;
		
		$limit = $data['posts'];
		if ($data['title']) echo $before_title.apply_filters('widget_title', $data['title']).$after_title;
		
		echo '<ul>';
		
		global $wpdb;
		$posts = $wpdb->get_results('SELECT comment_count, ID, post_title FROM '.$wpdb->posts.' ORDER BY comment_count DESC LIMIT 0 , '.$limit);
		foreach ($posts as $post) {
			if ($post->comment_count != 0) {
				setup_postdata($post);
				$title = $post->post_title;
				echo '<li><a href="'.get_permalink($post->ID).'" title="'.$title .'">'.$title.'</a></li>';
			}
		}
		
		echo '</ul>';

		echo $after_widget;
	}
}
?>