<?php
/*
	Carta Widget: Flickr Photostream
	Author: Stefano Giliberti, winterbits.com
*/

add_action('widgets_init', 'ca_flickr_widget');

function ca_flickr_widget() {
	register_widget('ca_flickr_widget');
}

class ca_flickr_widget extends WP_Widget {
	
	function ca_flickr_widget() {
	
		$widget = array(
			'classname' => 'ca_flickr_widget',
			'description' => __('Your Flickr photos.', 'carta')
		);

		$this->WP_Widget('ca_flickr_widget', __('Carta: Flickr Photostream', 'carta'), $widget);
	}
	
	function form($data) {

		/* Defaults */
		$defaults = array(
			'title' => 'Flickr',
			'id' => ca_social_flickr,
			'count' => 6,
			'size' => 's',
			'display' => 'random',
			'source' => 'user'
		);
		
		$data = wp_parse_args((array) $data, $defaults); ?>

		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $data['title']; ?>" />
		</p>

		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('id'); ?>"><?php _e('Flickr <code>ID</code>', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('id'); ?>" name="<?php echo $this->get_field_name('id'); ?>" value="<?php echo $data['id']; ?>" />
		</p>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('count'); ?>"><?php _e('How many photos?', 'carta') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>">
				<option <?php if ($data['count'] == 1) echo 'selected="selected"'; ?>>1</option>
				<option <?php if ($data['count'] == 2) echo 'selected="selected"'; ?>>2</option>
				<option <?php if ($data['count'] == 3) echo 'selected="selected"'; ?>>3</option>
				<option <?php if ($data['count'] == 4) echo 'selected="selected"'; ?>>4</option>
				<option <?php if ($data['count'] == 5) echo 'selected="selected"'; ?>>5</option>
				<option <?php if ($data['count'] == 6) echo 'selected="selected"'; ?>>6</option>
				<option <?php if ($data['count'] == 7) echo 'selected="selected"'; ?>>7</option>
				<option <?php if ($data['count'] == 8) echo 'selected="selected"'; ?>>8</option>
				<option <?php if ($data['count'] == 9) echo 'selected="selected"'; ?>>9</option>
				<option <?php if ($data['count'] == 10) echo 'selected="selected"'; ?>>10</option>
			</select>
		</p>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('size'); ?>"><?php _e('Photos Size', 'carta') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('size'); ?>" name="<?php echo $this->get_field_name('size'); ?>">
				<option <?php if ($data['size'] == 's') echo 'selected="selected"'; ?>>s</option>
				<option <?php if ($data['size'] == 't') echo 'selected="selected"'; ?>>t</option>
				<option <?php if ($data['size'] == 'm') echo 'selected="selected"'; ?>>m</option>
			</select>
		</p>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('display'); ?>"><?php _e('Photo order', 'carta') ?></label>
			<select id="<?php echo $this->get_field_id('display'); ?>" name="<?php echo $this->get_field_name('display'); ?>" class="widefat">
				<option <?php if ($data['display'] == 'random') echo 'selected="selected"'; ?>>random</option>
				<option <?php if ($data['display'] == 'latest') echo 'selected="selected"'; ?>>latest</option>
			</select>
		</p>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('source'); ?>"><?php _e('Select from', 'carta') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('source'); ?>" name="<?php echo $this->get_field_name('source'); ?>">
				<option <?php if ($data['source'] == 'user') echo 'selected="selected"'; ?>>user</option>
				<option <?php if ($data['source'] == 'group') echo 'selected="selected"'; ?>>group</option>
			</select>
		</p>
		
	<?php
	}
	
	function update($new_data, $old_data) {
		$data = $old_data;

		$data['title'] = strip_tags($new_data['title']);
		$data['id'] = $new_data['id'];
		$data['count'] = $new_data['count'];
		$data['size'] = $new_data['size'];
		$data['display'] = $new_data['display'];
		$data['source'] = $new_data['source'];

		return $data;
	}
	
	function widget($args, $data) {
		extract($args);
		echo $before_widget;

		if ($data['title']) echo $before_title.apply_filters('widget_title', $data['title']).$after_title;

		 ?>
			
		<div id="flickr_badge_wrapper" class="clearfix">
			<script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=<?php echo $data['count'] ?>&amp;display=<?php echo $data['display'] ?>&amp;size=<?php echo $data['size'] ?>&amp;layout=x&amp;source=<?php echo $data['source'] ?>&amp;<?php echo $data['source'] ?>=<?php echo $data['id'] ?>"></script>
		</div>
		
		<?php

		echo $after_widget;
	}
}
?>