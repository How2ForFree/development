<?php
/*
	Carta Widget: Static Advertisements
	Author: Stefano Giliberti, winterbits.com
*/

add_action('widgets_init', 'ca_ad_widget');

function ca_ad_widget() {
	register_widget('ca_ad_widget');
}

class ca_ad_widget extends WP_Widget {
	
	function ca_ad_widget() {
	
		$widget = array(
			'classname' => 'ca_ad_widget',
			'description' => __('A widget for static advertisements.', 'carta')
		);
		
		$setup = array(
			'width' => 400
		);
		
		$this->WP_Widget('ca_ad_widget', __('Carta: Advertisements', 'carta'), $widget, $setup);
	}
	
	function form($data) {
		
		$data = wp_parse_args((array) $data); ?>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('size'); ?>"><?php _e('Select a size', 'carta') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('size'); ?>" name="<?php echo $this->get_field_name('size'); ?>">
				<option <?php if ($data['size'] == '120x240') echo 'selected="selected"'; ?>>120x240</option>
				<option <?php if ($data['size'] == '125x125') echo 'selected="selected"'; ?>>125x125</option>
				<option <?php if ($data['size'] == '200x125') echo 'selected="selected"'; ?>>200x125</option>
				<option <?php if ($data['size'] == '250x200') echo 'selected="selected"'; ?>>250x200</option>
				<option <?php if ($data['size'] == '260x260') echo 'selected="selected"'; ?>>260x260</option>
			</select>
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('adimg'); ?>"><?php _e('Ad Image url', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('adimg'); ?>" name="<?php echo $this->get_field_name('adimg'); ?>" value="<?php echo $data['adimg']; ?>" />
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('ad'); ?>"><?php _e('Ad Link', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('ad'); ?>" name="<?php echo $this->get_field_name('ad'); ?>" value="<?php echo $data['ad']; ?>" />
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('adtitle'); ?>"><?php _e('Ad Title <em>(Optional)</em>', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('adtitle'); ?>" name="<?php echo $this->get_field_name('adtitle'); ?>" value="<?php echo $data['adtitle']; ?>" />
		</p>

	<?php
	}
	
	function update($new_data, $old_data) {
		$data = $old_data;

		$data['size'] = $new_data['size'];
		$data['adimg'] = $new_data['adimg'];
		$data['ad'] = $new_data['ad'];
		$data['adtitle'] = $new_data['adtitle'];
		
		return $data;
	}
	
	function widget($args, $data) {
		extract($args);
		echo $before_widget;
		
		$ad = $data['ad'];
		$title = $data['adtitle'];
				
		 ?>
		
		<div class="ad s<?php echo $data['size'] ?>">
			
			<a href="<?php echo $data['ad'] ?>">
				<img src="<?php echo $data['adimg'] ?>" alt="<?php if ($title) echo $title ?>" />
			</a>
			<a href="<?php echo $data['ad'] ?>"><?php if ($title) echo $title ?></a>
			
		</div>
		
		<?php

		echo $after_widget;
	}
}
?>