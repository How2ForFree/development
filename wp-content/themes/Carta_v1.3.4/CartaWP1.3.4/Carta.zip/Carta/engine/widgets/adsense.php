<?php
/*
	Carta Widget: Google Adsense
	Author: Stefano Giliberti, winterbits.com
*/

add_action('widgets_init', 'ca_gadsense_widget');

function ca_gadsense_widget() {
	register_widget('ca_gadsense_widget');
}

class ca_gadsense_widget extends WP_Widget {
	
	function ca_gadsense_widget() {
	
		$widget = array(
			'classname' => 'ca_gadsense_widget',
			'description' => __('Google Adsense Advertising.', 'carta')
		);
		
		$setup = array(
			'width' => 400
		);
		
		$this->WP_Widget('ca_gadsense_widget', __('Carta: Google Adsense', 'carta'), $widget, $setup);
	}
	
	function form($data) {
		
		/* Defaults */
		$defaults = array(
			'pubid' => 'pub-YOURID',
			'size' => '200x200'
		);
		
		$data = wp_parse_args((array) $data, $defaults); ?>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('pubid'); ?>"><?php _e('Publisher <code>ID</code>', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('pubid'); ?>" name="<?php echo $this->get_field_name('pubid'); ?>" value="<?php echo $data['pubid']; ?>" />
		</p>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('size'); ?>"><?php _e('Ad size', 'carta') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('size'); ?>" name="<?php echo $this->get_field_name('size'); ?>">
				<optgroup label="Horizontal">
					<option <?php if ($data['size'] == '234x60') echo 'selected="selected"'; ?>>234x60</option>
				</optgroup>
				<optgroup label="Vertical">
					<option <?php if ($data['size'] == '120x600') echo 'selected="selected"'; ?>>120x600</option>
					<option <?php if ($data['size'] == '160x600') echo 'selected="selected"'; ?>>120x600</option>
					<option <?php if ($data['size'] == '120x240') echo 'selected="selected"'; ?>>120x240</option>
				</optgroup>
				<optgroup label="Square">
					<option <?php if ($data['size'] == '336x280') echo 'selected="selected"'; ?>>336x280</option>
					<option <?php if ($data['size'] == '300x250') echo 'selected="selected"'; ?>>300x250</option>
					<option <?php if ($data['size'] == '250x250') echo 'selected="selected"'; ?>>250x250</option>
					<option <?php if ($data['size'] == '200x200') echo 'selected="selected"'; ?>>200x200</option>
					<option <?php if ($data['size'] == '180x150') echo 'selected="selected"'; ?>>180x150</option>
					<option <?php if ($data['size'] == '125x125') echo 'selected="selected"'; ?>>125x125</option>
				</optgroup>
			</select>
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('border'); ?>"><?php _e('Border color (<code>FFFFFF</code> : white)', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('border'); ?>" name="<?php echo $this->get_field_name('border'); ?>" value="<?php echo $data['border']; ?>" />
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('bg'); ?>"><?php _e('Background color', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('bg'); ?>" name="<?php echo $this->get_field_name('bg'); ?>" value="<?php echo $data['bg']; ?>" />
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('link'); ?>"><?php _e('Links color', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('link'); ?>" name="<?php echo $this->get_field_name('link'); ?>" value="<?php echo $data['link']; ?>" />
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('text'); ?>"><?php _e('Text color', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('text'); ?>" name="<?php echo $this->get_field_name('text'); ?>" value="<?php echo $data['text']; ?>" />
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('url'); ?>"><?php _e('Urls color', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('url'); ?>" name="<?php echo $this->get_field_name('url'); ?>" value="<?php echo $data['url']; ?>" />
		</p>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('corners'); ?>"><?php _e('Corners Style', 'carta') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('corners'); ?>" name="<?php echo $this->get_field_name('corners'); ?>">
				<option <?php if ($data['corners'] == "Squared") echo 'selected="selected"'; ?>>Squared</option>
				<option <?php if ($data['corners'] == "Rounded") echo 'selected="selected"'; ?>>Rounded</option>
				<option <?php if ($data['corners'] == "Very rounded") echo 'selected="selected"'; ?>>Very rounded</option>
			</select>
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('alt'); ?>"><?php _e('Alternative Ad Url (Non Google)', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('alt'); ?>" name="<?php echo $this->get_field_name('alt'); ?>" value="<?php echo $data['alt']; ?>" />
		</p>
		
		<p>Colors must be entered in Hexadecimal code. <a target="_blank" href="http://www.w3schools.com/Html/html_colors.asp">Help</a></p>
		
	<?php
	}
	
	function update($new_data, $old_data) {
		$data = $old_data;

		$data['pubid'] = $new_data['pubid'];
		$data['size'] = $new_data['size'];
		$data['border'] = $new_data['border'];
		$data['bg'] = $new_data['bg'];
		$data['link'] = $new_data['link'];
		$data['text'] = $new_data['text'];
		$data['url'] = $new_data['url'];
		$data['corners'] = $new_data['corners'];
		$data['alt'] = $new_data['alt'];
		
		return $data;
	}
	
	function widget($args, $data) {
		extract($args);
		echo $before_widget;
		
		$pubid = $data['pubid'];
		$size = $data['size'];
		$dimensions = explode("x", $size);
		$border = $data['border'];
		$bg = $data['bg'];
		$link = $data['link'];
		$text =	$data['text'];
		$url = $data['url'];
		$corners = $data['corners'];	
		$alt = $data['alt'];

		?>
				
		<script type="text/javascript">
		<!--
		google_ad_client = '<?php echo $pubid ?>';
		<?php if ($alt) echo 'google_alternate_ad_url = "'.$alt.'";'; ?>
		google_ad_width = <?php echo $dimensions[0] ?>;
		google_ad_height = <?php echo $dimensions[1] ?>;
		google_ad_format = "<?php echo $size ?>_as";
		<?php 
			if ($border) echo 'google_color_border = "'.$border.'";';
			if ($bg) echo 'google_color_bg = "'.$bg.'";';
			if ($link) echo 'google_color_link = "'.$link.'";';
			if ($text) echo 'google_color_text = "'.$text.'";';
			if ($url) echo 'google_color_url = "'.$url.'";';
			switch ($data['corners']) {
				case "Squared": echo 'google_ui_features = "rc:0";'; break;
				case "Rounded": echo 'google_ui_features = "rc:6";'; break;
				case "Very rounded": echo 'google_ui_features = "rc:10";'; break;
			}
		?>
		//-->
		</script>
		<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
		
		<?php

		echo $after_widget;
	}
}
?>