<?php
/*
	Carta Widget: Tweets Stream
	Author: Stefano Giliberti, winterbits.com
*/

add_action('widgets_init', 'ca_tweets_widget');

function ca_tweets_widget() {
	register_widget('ca_tweets_widget');
}

class ca_tweets_widget extends WP_Widget {
	
	function ca_tweets_widget() {
	
		$widget = array(
			'classname' => 'ca_tweets_widget',
			'description' => __('Your tweets.', 'carta')
		);

		$this->WP_Widget('ca_tweets_widget', __('Carta: Tweets Stream', 'carta'), $widget);
	}
	
	function form($data) {

		/* Defaults */
		$defaults = array(
			'title' => 'Twitter',
			'username' => ca_social_twitter,
			'count' => 6
		);
		
		$data = wp_parse_args((array) $data, $defaults); ?>

		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $data['title']; ?>" />
		</p>
		
		<!-- text input -->
		<p>
			<label for="<?php echo $this->get_field_id('username'); ?>"><?php _e('Username', 'carta') ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id('username'); ?>" name="<?php echo $this->get_field_name('username'); ?>" value="<?php echo $data['username']; ?>" />
		</p>
		
		<!-- select -->
		<p>
			<label for="<?php echo $this->get_field_id('count'); ?>"><?php _e('How many tweets?', 'carta') ?></label>
			<select class="widefat" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>">
				<option <?php if ($data['count'] == 3) echo 'selected="selected"'; ?>>3</option>
				<option <?php if ($data['count'] == 6) echo 'selected="selected"'; ?>>6</option>
				<option <?php if ($data['count'] == 9) echo 'selected="selected"'; ?>>9</option>
				<option <?php if ($data['count'] == 12) echo 'selected="selected"'; ?>>12</option>
				<option <?php if ($data['count'] == 15) echo 'selected="selected"'; ?>>15</option>
			</select>
		</p>
		
	<?php
	}
	
	function update($new_data, $old_data) {
		$data = $old_data;

		$data['title'] = strip_tags($new_data['title']);
		$data['username'] = $new_data['username'];
		$data['count'] = $new_data['count'];

		return $data;
	}
	
	function widget($args, $data) {
		extract($args);
		echo $before_widget;

		if ($data['title']) echo $before_title.apply_filters('widget_title', $data['title']).$after_title;

		 ?>
		
		<ul id="twitter_update_list"></ul>
		<script type="text/javascript" src="http://twitter.com/javascripts/blogger.js"></script>
		<script type="text/javascript" src="http://twitter.com/statuses/user_timeline/<?php echo $data['username'] ?>.json?callback=twitterCallback2&count=<?php echo $data['count'] ?>">
		</script>
		
		<?php

		echo $after_widget;
	}
}
?>