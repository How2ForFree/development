/*
	Carta Options Panel Javascript
*/
jQuery.noConflict()
jQuery(document).ready(function(){
	
    if (jQuery.cookie) {
        jQuery('#tabs').tabs({ fx: { opacity: 'toggle', duration: 150 }, cookie: { expires: 1, name: 'CartaTabs' } })
    } else {
        jQuery('#tabs').tabs({ fx: { opacity: 'toggle', duration: 150 } })
    }
    
    jQuery('.blink, #new-slide-form, .slide .update').hide();
    jQuery('.stuffbox h3, #tab-items, .plusminus').disableSelection();
    
    jQuery('.file-image-preview')
	    .hover(function(e){
	        jQuery("<div class='file-image-popup'><img src='" + this.href + "' /></div>")
	        	.appendTo('body')
	        	.css('top', (e.pageY + 10) + 'px')
	        	.css('left', (e.pageX + 10) + 'px')
	        	.css('padding', '5px')
	        	.fadeIn('fast');
	        	
	    }, function(){
	        jQuery('.file-image-popup')
	        .remove()
	        
	    })
	    .mousemove(function(e){
	        jQuery('.file-image-popup')
	        	.css('top', (e.pageY + 10) + 'px')
	        	.css('left', (e.pageX + 10) + 'px');
	    });
    
    jQuery('ul#tab-items .update').click(function(){ window.location = window.location.href + '&updates'; })
    
    jQuery('#tab-items').hover(function(){
        if (jQuery(this).find('.update').length) jQuery(this).find('.update').animate({ right: '98px'})
        jQuery(this).find('.button.blink').show();
    }, function () {
        jQuery(this).find('.button.blink').stop(true, true).delay(1500).fadeOut(250, function(){
            if (jQuery('ul#tab-items .update').length) jQuery('ul#tab-items .update').animate({ right: 0 })
        });
    })
    
    jQuery('.stuffbox h3').click(function(){ jQuery(this).parent().find('.inside').slideToggle(250) })
    jQuery('.options-message.pop').delay(1500).animate({ top: '7%', opacity: 'hide' })
    jQuery('.options-message').click(function(){ jQuery(this).hide() });
    jQuery('.stuffbox.slide').change(function(){ jQuery(this).find('.update').slideDown(200) });
    jQuery('.plusminus').click(function(){ jQuery(this).parent().parent().find('.update').slideDown(200) });
    jQuery('.shownext').click(function(){ jQuery(this).parent().parent().parent().find('.hidden:not(input[type="checkbox"])').slideToggle(200); return false; });
    jQuery('.slide-manager .stuffbox input[type="submit"]').click(function(){ jQuery(this).parent().find('.load').show() })
    jQuery('select, input, textarea').change(function(){
    	jQuery('ul#tab-items .blink').effect('pulsate', { mode: 'show', times: 2 })
    });
    
    jQuery('.cb-enable').click(function(){
        jQuery(this).addClass('selected').parent().find('.cb-disable').removeClass('selected').parent().find('input[type="checkbox"].hidden').attr('checked', true);
    })
    jQuery('.cb-disable').click(function(){
        jQuery(this).addClass('selected').parent().find('.cb-enable').removeClass('selected').parent().find('input[type="checkbox"].hidden').attr('checked', false);
    })
    
    jQuery('.slugbuddy').each(function(){
    	var s = jQuery(this).parent().parent().parent().find('.sluginput').val().replace(/[^a-zA-Z 0-9]+/g, '').replace(/\s+/g, '-');
    	jQuery(this).text(s);
    })
    jQuery('.sluginput')
    	.each(function(){
    		jQuery(this)
    			.keyup(function(){
    				var s = jQuery(this).val().replace(/[^a-zA-Z 0-9]+/g, '').replace(/\s+/g, '-');
    				if (s != '') jQuery(this).parent().find('.slugbuddy').text(s);
    			})
    			.focusout(function(){
    				jQuery(this).parent().find('.slugbuddy').effect("highlight", {}, 3000)
    			})
    	})
    
    if (jQuery('.options-wrap .updates-print').length) {
        jQuery('ul#tab-items .update').hide();
        jQuery('.stuffbox .inside').slideUp();
        jQuery('.options-wrap .updates-print').click(function(){
            jQuery(this).slideUp();
            jQuery('.stuffbox .inside').slideDown();
        })
    }
    
    jQuery('.new-slide').click(function () {
        if (jQuery('#tabs').tabs('option', 'selected') == 0) {
            if (!jQuery('#new-slide-form').is(':visible')) {
                jQuery(this).addClass('toggle');
                jQuery('.slide:not(#new-slide-form) .inside').slideUp();
                jQuery('#new-slide-form').slideDown();
            } else {
                jQuery(this).removeClass('toggle');
                jQuery('#new-slide-form').slideUp();
                jQuery('.slide:not(#new-slide-form) .inside').slideDown();
            }
        } else {
            jQuery('#tabs').tabs('select', 0);
        }
        return false;
    });
    
	jQuery('select[name="slide_content_type"]')
		.each(function(){
	        if (jQuery(this).val() == 'note' || jQuery(this).val() == 'caption') {
	            jQuery(this).next('p').find('[name="slide_content"]').addClass('note');
	        } else if (jQuery(this).val() == 'none') {
	            jQuery(this).next('p').find('[name="slide_content"]').hide();
	        } else {
	            jQuery(this).next('p').find('[name="slide_content"]').removeClass('note');
	        }
	    })
	    .change(function () {
	        if (jQuery(this).val() == 'note' || jQuery(this).val() == 'caption') {
	            jQuery(this).next('p').find('[name="slide_content"]').addClass('note').slideDown(150);
	        } else if (jQuery(this).val() == 'none') {
	            jQuery(this).next('p').find('[name="slide_content"]').slideUp(150);
	        } else {
	            jQuery(this).next('p').find('[name="slide_content"]').removeClass('note').slideDown(150);
	        }
	    });
    
    jQuery('.plusminus').click(function () {
    	var t = jQuery(this),
        	x = t.parent().find('.pmbuddy'),
        	c = x.val(),
       		i = t.parent().find('.plusminusall').length;
        if (t.text() == '+' && c != 99) {
        	if (i && isNaN(c)) {
        		x.effect('highlight', { color: 'white' }).val(1);
        	} else {
            	c++;
            	x.effect('highlight', { color: 'white' }).val(c);
            }
        }
        else if (t.text() == '-') {
        	if (i && c == 1) {
        		x.effect('highlight', { color: 'lightgreen' }).val('*');
        	}
        	else if (!isNaN(c) && c != 0) {
            	c--;
            	x.val(c);
            }
        }
        return false;
    });
		
    jQuery('.slider').each(function () {
    	var t = jQuery(this),
    		p = t.parent(),
        	i = p.find('.slidertype').val(),
        	x = p.find('.sliderbuddy'),
        	s = p.find('.sample');
        if (i == 1) {
            var min = 0,
                max = 1,
                step = 0.1
        } else if (i == 2) {
            var min = 0,
                max = 9000,
                step = 250
        } else if (i == 3) {
            var min = 0,
                max = 940
        } else if (i == 4) {
            var min = 0,
                max = 10000
        } else if (i == 5) {
            var min = 5,
                max = 100,
                step = 5
        }
        t.slider({
            value: x.val(),
            min: min,
            max: max,
            step: step,
            animate: true,
            slide: function (event, ui) {
                x.val(ui.value);
                if (i == 1) s.css("opacity", ui.value);
            }
        });
    })
    
    jQuery('.picker').each(function () {
        var	t = jQuery(this),
        	i = t.val(),
        	x = t.parent().find('.pickerbuddy');
        x.css('backgroundColor', '#' + i)
        t.ColorPicker({
            onShow: function (colpkr) {
                jQuery(colpkr).fadeIn(250);
                return false;
            },
            onSubmit: function (hsb, hex, rgb, el) {
                jQuery(el).val(hex);
                jQuery(el).ColorPickerHide();
            },
            onBeforeShow: function () {
                jQuery(this).ColorPickerSetColor(this.value);
            },
            onChange: function (hsb, hex, rgb) {
            	t.val(hex);
                x.css('backgroundColor', '#' + hex);
            },
        }).bind('keyup', function () {
            t.ColorPickerSetColor(this.value);
        });
    })
    
})