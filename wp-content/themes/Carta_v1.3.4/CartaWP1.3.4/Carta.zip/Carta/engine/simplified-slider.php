<?php
/*
	Simplified Frontpage Slider Engine
*/

$rt = (ca_slider_resize_type ? 0 : 1);
query_posts('post_type=carta-slides&order=ASC');
?>

<!-- content slider -->
<div id="featured" <?php if (ca_slider == 'Carta Accordion') : ?>class="accordion"<?php endif; ?>>
<?php if (ca_slider == 'Nivo Slider') : ?><div id="nivo"><?php endif; ?>

<?php
if (have_posts()) : while (have_posts()) : the_post();
$pic = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large', true);
$link = get_post_meta($post->ID, 'Link', true);

if ($link) {
	if (strpos($link, 'youtube.com') !== false) {
		$media = 'youtube';
	}
	else if (strpos($link, 'vimeo.com') !== false) {
		$media = 'vimeo';
	}
	else if (preg_match('#^http:\/\/(.*)\.(gif|png|jpg|swf)$#i', $link)) {
		$media = 'media';
	}
	else {
		$media = null;
	}
}
?>

<?php if (ca_slider == 'Carta Accordion') : ?>
	<!-- slide -->
	<div class="slide" id="slide_<?php the_ID(); ?>">
		<?php if ($link) : ?><a href="<?php echo $link; ?>"<?php if ($media) : ?> class="<?php echo $media ?>"<?php endif; ?>>
		<?php if ($media) : ?><div class="play"></div><?php endif; ?>
		<?php endif; ?>
		<img src="<?php if (!ca_slider_resize) echo timthumb.'?h='.ca_slider_height.'&amp;w='.(ca_accordion_custom ? ca_accordion_fullwidth : 780).'&amp;q='.ca_slider_iq.'&amp;zc='.$rt.'&amp;src='; ?><?php echo $pic[0] ?>" alt="" />
		<?php if ($link) : ?></a><?php endif; ?>
<?php if (trim(get_the_excerpt())) : ?>
		<div class="slide-content note">
			<p><?php remove_filter('the_excerpt', 'wpautop'); the_excerpt(); ?></p>
		</div>
<?php endif; ?>
	</div>
<?php endif; ?>
<?php if (ca_slider == 'Nivo Slider') : ?>
		<!-- slide -->
		<?php if ($link) : ?><a href="<?php echo $link; ?>"<?php if ($media) : ?> class="<?php echo $media ?>"<?php endif; ?>>
		<?php if ($media) : ?><div class="play"></div><?php endif; ?>
		<?php endif; ?>
		<img class="slide" <?php if (trim(get_the_excerpt())) echo 'title="#caption'.get_the_ID().'"'; ?> src="<?php if (!ca_slider_resize) echo timthumb.'?h='.ca_slider_height.'&amp;w=940&amp;q='.ca_slider_iq.'&amp;zc='.$rt.'&amp;src='; ?><?php echo $pic[0] ?>" alt="" />
		<?php if ($link) : ?></a><?php endif; ?>
<?php endif; ?>

<?php endwhile; endif; ?>

<?php if (ca_slider == 'Nivo Slider') : ?>
	</div>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<?php if (trim(get_the_excerpt())) : ?>
	<div id="caption<?php echo the_ID(); ?>" class="nivo-html-caption">
		<small><?php remove_filter('the_excerpt', 'wpautop'); the_excerpt(); ?></small>
	</div>
<?php endif; ?>

<?php endwhile; endif; ?>
<?php endif; ?>

</div>
<!-- closed: featured -->

<!-- featured's bottom -->
<div id="featured-tail"></div>