<?php
/*
	Template name: Gallery
*/
get_header();

$pag = (get_query_var('paged') ? get_query_var('paged') : 1);
$types = get_terms('types');
$qp = (ca_gallery_bpp == '*' ? '-1' : ca_gallery_bpp);
$lay = substr(ca_gallery_layout, 0, 1);
$rt = (ca_gallery_resize_type ? 0 : 1);
$ord = strtolower(ca_gallery_orderby);
query_posts('post_type=gallery&posts_per_page='.$qp.'&orderby='.$ord.'&paged='.$pag);

switch ($lay) {
	case 1:
		$class = 'f';
		$size = array(840, 504);
	break;
	case 2:
		$class = 'l';
		$size = array(460, 276);
	break;
	case 3:
		$size = array(300, 180);
	break;
	case 4:
		$class = 's';
		$size = array(220, 160);
	break;
}
?>

<?php if (!ca_gallery_filtering) : ?>
	<script type="text/javascript">
	jQuery(document).ready(function(){ 
		filtering(".gallery", <?php echo $lay ?>);
	})
	</script>
<?php endif; ?>

<?php if (ca_gallery_intro) : ?>
	<span class="promo"><?php echo stripslashes(ca_gallery_intro); ?></span>
<?php endif; ?>

<?php if (!ca_gallery_filtering) : ?>
	<!-- gallery toolbar -->
	<div id="toolbar" class="filter">
		<ul>
<?php if (ca_gallery_filtering_show) : ?>
			<li><?php echo ca_gallery_filtering_show ?></li>
<?php endif; ?>
<?php if (ca_gallery_filtering_reset) : ?>
			<li class="all"><b><?php echo ca_gallery_filtering_reset ?></b></li>
<?php endif; ?>
<?php
foreach ($types as $type) : ?>
			<li class="<?php echo $type->slug ?>"><b><?php echo $type->name ?></b></li>
<?php endforeach; ?>
		</ul>
	</div>
<?php endif; ?>

	<!-- gallery container -->
	<div class="gallery<?php if (isset($class)) echo ' '.$class; ?>">

<?php
$i = 0;
if (have_posts()) : while (have_posts()) : the_post();
$i++;
$pic = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large', true);
$types = get_the_terms($post->ID, 'types');
$media = get_post_meta($post->ID, 'Media', true);
$link = get_post_meta($post->ID, 'Link', true);
$rel = get_post_meta($post->ID, 'Gallery', true);
$zoom = strtolower(get_post_meta($post->ID, 'Lightbox', true));
$thumbnail = get_post_meta($post->ID, 'Thumbnail', true);
$gal = ($rel ? $rel : null);
$display = ($thumbnail ? $thumbnail : $pic[0]);
$slug = null;
if (isset($types) && !empty($types)) foreach ($types as $type) $slug .= $type->slug.' ';

if ($media) {
	if (strpos($media, 'youtube.com') !== false) {
		$lightbox = 'youtube';
		$href = $media;
		if (!ca_gallery_video) {
			$id = wb_get_video_id($media, 'youtube.com');
			$display = wb_get_video_thumb($id, 'youtube.com');
		}
	}
	else if (strpos($media, 'vimeo.com') !== false) {
		$lightbox = 'vimeo';
		$href = $media;
		if (!ca_gallery_video) {
			$id = wb_get_video_id($media, 'vimeo.com');
			$display = wb_get_video_thumb($id, 'vimeo.com');
		}
	}
	else {
		$lightbox = 'media';
		$href = $media;
	}
}
else if ($link) {
	$href = $link;
}
else {
	$lightbox = ($zoom ? $zoom : ca_gallery_lightbox);
	$href = $pic[0];
}
?>

		<!-- gallery entry -->
		<div id="box-<?php the_ID(); ?>" class="entry<?php if ($i == $lay && $lay > 1) { echo ' odd'; $i = 0; } ?> <?php echo $slug; ?>">
			<a href="<?php echo $href; ?>"<?php if (isset($lightbox)) : ?> target="_blank" <?php endif; ?><?php if (isset($gal)) echo 'rel="'.$gal.'"'; elseif (ca_gallery_group) echo 'rel="agroup"'; ?> class="<?php if (isset($lightbox)) echo $lightbox; ?>"><img src="<?php if (!ca_gallery_resize) echo timthumb.'?q=100&amp;w='.$size[0].'&amp;h='.$size[1].'&amp;zc='.$rt.'&amp;src='; ?><?php echo $display; ?>" alt="" /></a>
			<span><?php echo get_the_excerpt(); ?></span>
<?php if (!ca_gallery_title && get_the_title()) : ?>
			<div class="title">
				<h4><?php if (ca_gallery_titletype && !ca_gallery_filtering) if (!empty($types)) foreach ($types as $type) echo $type->name; else the_title(); else the_title(); ?></h4>
			</div>
<?php endif; ?>
		</div>
		
<?php endwhile; else: ?>
		
		<p><?php _e('No Gallery entries found.', 'carta'); ?></p>
		
<?php endif; ?>
		
	</div>
	
<?php if ($qp != '-1') : ?>
	<div class="pag">
		<?php next_posts_link('<strong>'.__('More', 'carta').'</strong>');?>
		<?php previous_posts_link('<strong>'.__('Recent', 'carta').'</strong>');?>
	</div>
<?php endif; ?>
		
<?php wp_reset_query(); get_footer(); ?>