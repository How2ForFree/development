<?php
/*
	Carta
	All the theme main functions, be careful editing this file!
*/

define('cartaver', '1.3.4');
define('templatedir', get_bloginfo('template_url'));
define('enginedir', '/engine/');
define('dir', TEMPLATEPATH.enginedir);
define('includes', templatedir.enginedir.'includes/');
define('widgets', dir.'widgets/');
define('timthumb', includes.'timthumb.php');

/*
	Including and activating jQuery Plugins & Seo
*/
if (!is_admin()) include_once(dir.'carta-head.php');

/*
	Localization support
*/
load_theme_textdomain('carta', TEMPLATEPATH.'/lang');
$lang = TEMPLATEPATH.'/lang/'.get_locale().'.php';
if (is_readable($lang)) require_once($lang);

/*
	All the back-end management
*/
include_once(dir.'backend.php');

/*
	Widgets
*/
include_once(dir.'widgets.php');

/*
	Shortcodes & related
*/
include_once(dir.'editor.php');

/*
	Custom Menu, Widgets, Custom Post Types, Extras
*/
include_once(dir.'addendum.php');
?>