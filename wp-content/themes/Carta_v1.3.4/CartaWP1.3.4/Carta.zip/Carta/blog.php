<?php
/*
	Template name: Blog
*/
get_header();

global $more;
$more = 0;
$cat = get_query_var('cat');
$y = get_query_var('year');
$m = get_query_var('monthnum');
$pag = (get_query_var('paged')) ? get_query_var('paged') : 1;
$qp = (ca_blog_ppp == '*' ? '-1' : ca_blog_ppp);
$ord = str_replace(' ', '_', strtolower(ca_blog_orderby));
$exc = (ca_blog_exclude_list ? wordwrap(ca_blog_exclude_list, 2, '-', true) : (get_cat_id(ca_blog_exclude) ? get_cat_id(ca_blog_exclude) : null));

switch (ca_blog_view) {
	case 'Classic':
		$class = 'col-xl right';
	break;
	case 'Plain':
		$class = 'full';
	break;
	case 'Sidebar':
		$class = 'col-xl';
	break;
	case 'Sidebar (Left)':
		$class = 'col-xl right';
	break;
}

if (!ca_blog_toolbar_disable) include_once('toolbar.php');
query_posts('cat='.$cat.'-'.$exc.'&year='.$y.'&monthnum='.$m.'&posts_per_page='.$qp.'&orderby='.$ord.'&paged='.$pag);
?>
	
<?php if (ca_blog_view == 'Sidebar' || ca_blog_view == 'Sidebar (Left)') : ?>
		<div id="sidebar" class="col-s<?php if (ca_blog_view == 'Sidebar (Left)') : ?> left<?php endif; ?>">
			<?php get_sidebar(); ?>
		</div>
<?php endif; ?>
		
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
		<!-- post -->
		<div class="post type <?php if (ca_blog_view == 'Sidebar' || ca_blog_view == 'Sidebar (Left)') echo $class; ?>" id="post-<?php the_ID(); ?>">
		
<?php if (ca_blog_view == 'Classic') : ?>
			<div class="col-s left">
				<span class="meta"><?php if (!ca_blog_author) : ?><a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author() ?></a><?php if (!ca_blog_author && !ca_blog_date) : ?>, <?php endif; ?><?php endif; ?><?php if (!ca_blog_date) : ?><?php the_time('F j, Y') ?><?php endif; ?></span>
			</div>
<?php endif; ?>
		
			<div class="<?php echo $class; ?>">
			
					<h1<?php if (!ca_blog_cufon_titles) : ?> class="classic"<?php endif; ?>><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h1>
					
					<?php if (has_excerpt()) : the_excerpt(); else : the_content(__('Read more..', 'carta')); endif; ?>
					
					<div class="separator"></div>
					<div class="info">
<?php if (ca_blog_view != "Classic") : ?>
						<span><?php the_author() ?></span>
						<span><?php the_time('F j, Y') ?></span>
<?php endif; ?>
<?php if (!ca_blog_category) : ?>
						<span><?php _e('Filed in', 'carta'); ?> <?php the_category(', '); ?></span>
<?php endif; ?>
<?php if (!ca_blog_comments) : ?>
						<span><a href="<?php comments_link() ?>"><?php comments_number(__('No Responses', 'carta'), __('1 Response', 'carta'), "% ".__('Responses', 'carta')); ?></a></span>
<?php endif; ?>
					</div>
			</div>
		
		</div>
		
<?php endwhile; else: ?>

	<h3><?php _e('Sorry, no posts matched your criteria.', 'carta'); ?></h3>

<?php endif; ?>
	
	<div class="clear"></div>

<?php if ($qp != '-1') : ?>
	<!-- pagination controls -->
	<div class="pagination">
		<?php next_posts_link(__('Older posts', 'carta'));?>
		<?php previous_posts_link(__('Recent posts', 'carta'));?>
	</div>
<?php endif; ?>

<?php wp_reset_query(); get_footer(); ?>