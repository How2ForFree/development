<?php
/*
	Template name: Left Sidebar
*/
get_header();
?>
	
	<!-- side column -->
	<div id="sidebar" class="col-s left">
		
		<?php get_sidebar(); ?>
		
	<!-- closing: side column (left) -->
	</div>
	
	<!-- main column -->
	<div class="col-xl right type">
					
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						
				<?php the_content(); ?>
							
		<?php endwhile; endif; ?>
		
	<!-- closing: main column (right) -->
	</div>

<?php get_footer(); ?>