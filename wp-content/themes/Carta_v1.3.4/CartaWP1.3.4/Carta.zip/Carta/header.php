<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset'); ?>" />
	
	<title><?php wp_title('-', true, 'right'); bloginfo('name'); ?><?php if (get_bloginfo('description') && (is_home() || is_front_page())) echo ' - '.get_bloginfo('description'); ?></title>
	
	<!-- main stylesheet -->
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="all" />
	<!-- theme stylesheet: colors, images etc. -->
	<link rel="stylesheet" href="<?php echo templatedir ?>/themes/<?php echo ca_theme ?>" type="text/css" media="all" />
<?php if (ca_header_custom_css) : ?>
	<!-- custom styles -->
	<link rel="stylesheet" href="<?php echo templatedir.enginedir ?>cs.php?1=<?php echo ca_logo_text_size; ?>&2=<?php echo ca_logo_top; ?>&3=<?php echo ca_logo_left; ?>&4=<?php echo ca_logo_width; ?>&5=<?php echo ca_logo_height; ?><?php if (ca_file_logo) echo '&6='.ca_file_logo; ?>&7=<?php echo ca_logo_text_color; ?><?php if (ca_slider_height != 308) echo '&8='.ca_slider_height; ?>" type="text/css" media="all" />
<?php elseif (ca_file_logo): ?>
	<!-- custom styles -->
	<link rel="stylesheet" href="<?php echo templatedir.enginedir ?>cs.php?6=<?php echo ca_file_logo; ?>" type="text/css" media="all" />
<?php elseif (ca_slider_height != 308) : ?>
	<!-- custom styles -->
	<link rel="stylesheet" href="<?php echo templatedir.enginedir ?>cs.php?8=<?php echo ca_slider_height; ?>" type="text/css" media="all" />
<?php endif ; ?>

	<link rel="shortcut icon" href="<?php echo (ca_file_favicon ? ca_file_favicon : templatedir.'/themes/'.ca_theme_rd.'/favicon.ico'); ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<!--[if IE]><link rel="stylesheet" href="<?php echo templatedir ?>/css/ie.css" type="text/css" media="screen" /><![endif]-->	
	
	<?php wp_head(); ?>

<?php if (ca_analytics_position) echo stripslashes(ca_analytics); ?>
</head>

<body>
<!-- main container -->
<div class="container">	
			
	<div id="head">
		<h1 id="logo"<?php if (ca_plain_logo) echo ' class="type"'; ?>>
			<a href="<?php bloginfo('url'); ?>"><?php echo strip_tags(ca_plain_logo_text); ?></a>
		</h1>
		
		<?php wp_nav_menu(array('container' => '', 'menu_class' => '', 'menu_id' => 'menu', 'walker' => new carta_menu())); ?>
				
	<!-- closing: head -->
	</div>