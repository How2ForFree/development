<?php
/*
	Template name: Projects
*/
get_header();

$pag = (get_query_var('paged') ? get_query_var('paged') : 1);
$types = get_terms('kind');
$qp = (ca_projects_ppp == '*' ? '-1' : ca_projects_ppp);
$lay = substr(ca_projects_layout, 0, 1);
$rt = (ca_projects_resize_type ? 0 : 1);
$ord = strtolower(ca_projects_orderby);
query_posts('post_type=project&posts_per_page='.$qp.'&orderby='.$ord.'&paged='.$pag);

switch ($lay) {
	case 1:
		$class = 'f';
		$size = array(840, 504);
	break;
	case 2:
		$size = array(460, 276);
	break;
	case 3:
		$class = 'l';
		$size = array(300, 180);
	break;
	case 4:
		$class = 's';
		$size = array(220, 180);
	break;
}
?>

<?php if (!ca_projects_filtering) : ?>
	<script type="text/javascript">
	jQuery(document).ready(function(){ 
		filtering(".projects", <?php echo $lay ?>);
	})
	</script>
<?php endif; ?>

<?php if (ca_projects_intro) : ?>
	<span class="promo"><?php echo stripcslashes(ca_projects_intro) ?></span>
<?php endif; ?>

<?php if (!ca_projects_filtering) : ?>
	<!-- gallery toolbar -->
	<div id="toolbar" class="filter">
		<ul>
<?php if (ca_projects_filtering_show) : ?>
			<li><?php echo ca_projects_filtering_show ?></li>
<?php endif; ?>
<?php if (ca_projects_filtering_reset) : ?>
			<li class="all"><b><?php echo ca_projects_filtering_reset ?></b></li>
<?php endif; ?>
<?php
foreach ($types as $type) : ?>
			<li class="<?php echo $type->slug ?>"><b><?php echo $type->name ?></b></li>
<?php endforeach; ?>
		</ul>
	</div>
<?php endif; ?>
	
	<!-- projects container -->
	<div class="projects<?php if (isset($class)) echo " $class"; ?>">

<?php
$i = 0;
if (have_posts()) : while (have_posts()) : the_post();
$i++;
$pic = wp_get_attachment_image_src(get_post_thumbnail_id(), 'full', true);
$types = get_the_terms($post->ID, 'kind');
$link = get_post_meta($post->ID, 'Link', true);
$zoom = strtolower(get_post_meta($post->ID, 'Lightbox', true));
$thumbnail = get_post_meta($post->ID, 'Thumbnail', true);
$href = ($zoom ? $pic[0] : ($link ? $link : get_permalink()));
$display = ($thumbnail ? $thumbnail : $pic[0]);
$slug = null;
if (isset($types) && !empty($types)) foreach ($types as $type) $slug .= $type->slug.' ';
?>

		<!-- project entry -->
		<div id="project-<?php the_ID(); ?>" class="entry<?php if ($i == $lay && $lay > 1) { echo ' odd'; $i = 0; } ?> <?php echo $slug; ?>">
			<div class="pic">
	<?php if (!ca_projects_popup && ca_projects_popup_text) : ?>
				<div class="details"><?php echo str_replace("%", get_the_title(), ca_projects_popup_text); ?></div>
	<?php endif; ?>
				<a href="<?php echo $href; ?>"<?php if ($zoom) echo ' class="'.$zoom.'"' ?>><img src="<?php if (!ca_projects_resize) echo timthumb.'?q=100&amp;w='.$size[0].'&amp;h='.$size[1].'&amp;zc='.$rt.'&amp;src='; ?><?php echo $display; ?>" alt="" /></a>
			</div>
	<?php if (!ca_projects_title) : ?>
			<div class="title">
				<h3><?php if (ca_projects_titletype && !ca_projects_filtering) if (!empty($types)) foreach ($types as $type) echo $type->name; else echo (get_the_title() ? get_the_title() : __('Untitled', 'carta')); else echo (get_the_title() ? get_the_title() : __('Untitled', 'carta')); ?></h3>
			</div>
	<?php endif; ?>
	<?php if (!ca_projects_excerpt) : ?>
			<div class="desc">
				<?php echo the_excerpt(); ?>
			</div>
	<?php endif; ?>
		</div>

<?php endwhile; else: ?>
		
		<p><?php _e('No Projects found.', 'carta'); ?></p>
		
<?php endif; ?>
						
	</div>
	
<?php if ($qp != '-1') : ?>
	<div class="pag">
		<?php next_posts_link('<strong>'.__('More', 'carta').'</strong>');?>
		<?php previous_posts_link('<strong>'.__('Recent', 'carta').'</strong>');?>
	</div>
<?php endif; ?>

<?php wp_reset_query(); get_footer(); ?>