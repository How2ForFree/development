<?php
global $wp_query;

if (ca_gallery_page && !ca_gallery_disable && is_page(ca_gallery_page))
{
	include_once(TEMPLATEPATH.'/gallery.php');
} 
	else if (ca_projects_page && !ca_projects_disable && is_page(ca_projects_page))
{
	include_once(TEMPLATEPATH.'/projects.php');
}
	else if (ca_blog_page && is_page(ca_blog_page))
{
	include_once(TEMPLATEPATH.'/blog.php');
}
	else if (ca_frontpage && is_page(ca_frontpage))
{
	include_once(TEMPLATEPATH.'/index.php');
}
	else if (get_post_type($wp_query->post->ID) == 'project')
{
	include_once(TEMPLATEPATH.'/project.php');
}
	else
{
?>
<?php get_header(); ?>

	<!-- main column -->
	<div class="col-xl type">
		
<?php if (have_posts()) while (have_posts()) : the_post(); the_content(); endwhile; ?>
		
	<!-- closing: main column (left) -->
	</div>
	
	<!-- side column -->
	<div id="sidebar" class="col-s">
		
<?php get_sidebar(); ?>
		
	<!-- closing: side column (right) -->
	</div>

<?php get_footer(); ?>

<?php } ?>