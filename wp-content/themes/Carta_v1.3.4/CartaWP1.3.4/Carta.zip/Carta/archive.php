<?php
/*
	Redirects to Blog.php that handles all the work
*/
include_once('blog.php')
?>