<?php 
if (get_post_type() == 'project') :
	include_once(TEMPLATEPATH.'/page.php');
else :

$exclude = null;

get_header();

switch (ca_post_view) {
	case 'Classic':
		$class = 'col-xl right';
	break;
	case 'Plain':
		$class = 'full';
	break;
	case 'Sidebar':
		$class = 'col-xl';
	break;
	case 'Sidebar (Left)':
		$class = 'col-xl right';
	break;
}
?>

<?php if (!ca_blog_toolbar_disable) include_once('toolbar.php'); ?>

<?php if (ca_post_view == 'Sidebar' || ca_post_view == 'Sidebar (Left)') : ?>
		<div id="sidebar" class="col-s<?php if (ca_post_view == 'Sidebar (Left)') : ?> left<?php endif; ?>">
			<?php get_sidebar(); ?>
		</div>
<?php endif; ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

	<!-- post -->
	<div class="post type" id="post-<?php the_ID(); ?>">
		
<?php if (ca_post_view == 'Classic') : ?>
		<div class="col-s left">
			<span class="meta"><?php the_time('F j, Y') ?></span>
			<span class="meta"><a href="#comments"><?php comments_number(__('No Responses', 'carta'), __('1 Response', 'carta'), '% '.__('Responses', 'carta')); ?></a></span>
			
			<div class="post-widgets">
				<?php
					/* Widgets Area */
					if (is_active_sidebar('post')) dynamic_sidebar('post');
				?>
			</div>
		</div>
<?php endif; ?>

		<div class="<?php echo $class; ?>">
			<h1 <?php if (!ca_blog_cufon_titles) : ?>class="classic"<?php endif; ?>><?php the_title(); ?></h1>
			<?php the_content(); ?>
			
			<?php wp_link_pages(array('before' => '<p>'.__('Pages:', 'carta'), 'after' => '</p>')); ?>
			
			<div class="separator"></div>
			
			<div class="info">
				
<?php if (!ca_blog_share_twitter) : ?>
				<span class="right">
					<a href="http://twitter.com/share" class="twitter-share-button"
					data-url="<?php the_permalink(); ?>"
					data-text="<?php the_title_attribute(); ?>"
					data-count="horizontal"
					data-via="<?php echo ca_social_twitter ?>"
					data-related="<?php echo ca_social_twitter ?>">Tweet</a>
					<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
				</span>
<?php endif; ?>

<?php if (!ca_blog_share_fb) : ?>
				<span class="right">
					<iframe src="http://www.facebook.com/plugins/like.php?href=<?php echo urlencode(get_permalink($post->ID)); ?>&amp;layout=button_count&amp;show_faces=false&amp;width=90&amp;action=<?php echo ca_blog_share_fbtype ?>&amp;colorscheme=light" scrolling="no" frameborder="0" allowTransparency="true" style="border:none; width:110px; height: 30px; overflow:hidden;"></iframe>
				</span>
<?php endif; ?>

				<span class="left">
					<?php if (ca_post_view != 'Classic') : ?>
					<a href="#comments"><?php comments_number(__('No Responses', 'carta'), __('1 Response', 'carta'), '% '.__('Responses', 'carta')); ?></a> &mdash;
					<?php _e('Written on', 'carta'); ?> <?php the_time('F j, Y') ?> &mdash;
					<?php endif; ?>
					<?php _e('Filed in', 'carta'); ?> <?php the_category(', '); ?>
					<?php $tags_list = get_the_tag_list('', ', '); if ($tags_list) echo '&mdash; '.$tags_list; ?>
				</span>
				
			</div>
		</div>
		
	</div>

<?php if (!ca_blog_bio && get_the_author_meta('description')) : ?>
		
	<div id="author-bio" class="col-half left">
	
		<div class="align-left">
			<?php echo get_avatar(get_the_author_meta('user_email'), apply_filters('', 80)); ?>
		</div>
		
		<div>
			<h3><?php _e('About the author', 'carta'); ?></h3>
			<p><?php the_author_meta('description'); ?></p>
			<p><small><a href="<?php echo get_author_posts_url(get_the_author_meta('ID') ); ?>">
			<?php
				printf(__('View all posts by %s', 'carta'), get_the_author() );
				echo ' <span class="meta-nav">&rarr;</span>';
			?>
			</a></small></p>
		</div>
	
	</div>

<?php endif; ?>

<?php if (!ca_blog_related) : ?>
<div id="related-posts" class="col-half left">
<?php
$tags = wp_get_post_tags($post->ID);
$qrp = (ca_blog_related_posts == '*' ? '-1' : ca_blog_related_posts);
if ($tags) {
	$tids = array();
	foreach($tags as $individual_tag) $tids[] = $individual_tag->term_id;
	$q = new wp_query(array(
		'tag__in' => $tids,
		'post__not_in' => array($post->ID),
		'showposts' => $qrp,
		'caller_get_posts' => 1,
		'orderby' => 'comment_count'
		)
	);
	if ($q->have_posts()) {
		echo '<h3>'.__('Related Posts', 'carta').'</h3><ul>';
		while ($q->have_posts()) {
			$q->the_post();
		?>
			<li><a href="<?php the_permalink() ?>"><?php the_title(); ?></a>
			<small><?php comments_number(__('No Responses', 'carta'), __('1 Response', 'carta'), '% '.__('Responses', 'carta')); ?>, <?php the_time('F j, Y'); ?></small></li>
		<?php
		}
		echo '</ul>';
	}
	wp_reset_query();
}
?>
</div>
<?php endif; ?>
<div class="clear"></div>

<?php comments_template(); ?>
	
<?php endwhile; else: ?>

	<p><?php _e('Sorry, no posts matched your criteria.', 'carta'); ?></p>

<?php endif; ?>
	
	<div class="clear"></div>
	
	<!-- pagination controls -->
	<div class="pagination">
		<?php next_posts_link(__('Recent entries', 'carta')); ?>
		<?php previous_posts_link(__('See older posts', 'carta')); ?>
	</div>
	
<?php get_footer(); ?>

<?php endif; ?>