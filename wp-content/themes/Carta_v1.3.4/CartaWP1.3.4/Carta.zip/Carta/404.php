<?php
/*
	The template for displaying 404 pages (Not Found)
*/
get_header();
?>

	<!-- main column -->
	<div class="col-xl type">
					
		<h1><?php _e('Not Found', 'carta'); ?></h1>
		<p>
			<?php _e('Apologies, but the page you requested could not be found. Perhaps a healthy search will help.', 'carta'); ?>
			<?php get_search_form(); ?>
		</p>
				
	<!-- closing: main column (left) -->
	</div>
	
	<!-- side column -->
	<div id="sidebar" class="col-s">
		
		<?php get_sidebar(); ?>
		
	<!-- closing: side column (right) -->
	</div>
	
<?php get_footer(); ?>