<!-- closing: main container -->
</div>

<!-- footer -->
<div id="footer">
	<div class="container">
		
		<div class="col-s left">
<?php
/* Widgets Area */
if (is_active_sidebar('footer1')) dynamic_sidebar('footer1');
?>
		</div>
		
		<div class="col-m">
<?php
/* Widgets Area */
if (is_active_sidebar('footer2')) dynamic_sidebar('footer2');
?>
		</div>
		
		<div class="col-xm">
<?php
/* Widgets Area */
if (is_active_sidebar('footer3')) dynamic_sidebar('footer3');
?>
		</div>
		
	</div>
	
	<!-- footer bar -->
	<div id="the-end">
		<ul>
<?php if (ca_social_twitter && !ca_hide_twitter) : ?>
			<li><a href="http://www.twitter.com/<?php echo ca_social_twitter ?>" class="socialp"><img src="<?php echo (ca_file_twitter_icon ? ca_file_twitter_icon : templatedir.'/themes/'.ca_theme_rd.'/twitter-ico.png'); ?>" alt="" /></a></li>
<?php endif; if (ca_social_facebook && !ca_hide_facebook) : ?>
			<li><a href="<?php echo ca_social_facebook ?>" class="socialp"><img src="<?php echo (ca_file_facebook_icon ? ca_file_facebook_icon : templatedir.'/themes/'.ca_theme_rd.'/facebook-ico.png'); ?>" alt="" /></a></li>
<?php endif; if (ca_social_flickr && !ca_hide_flickr) : ?>
			<li><a href="http://www.flickr.com/people/<?php echo ca_social_flickr ?>" class="socialp"><img src="<?php echo (ca_file_flickr_icon ? ca_file_flickr_icon : templatedir.'/themes/'.ca_theme_rd.'/flickr-ico.png'); ?>" alt="" /></a></li>
<?php endif; ?>
		</ul>
		
		<span><?php echo stripslashes(ca_copyright) ?></span>
	</div>
	
<!-- closing: footer -->
</div>

<?php wp_footer(); ?>
<?php if (!ca_analytics_position) echo stripslashes(ca_analytics); ?>
</body>

</html>