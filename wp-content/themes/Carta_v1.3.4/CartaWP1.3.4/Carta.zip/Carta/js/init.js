/* 
	Carta - Javascript initialization
	Handwritten by Stefano Giliberti <kompulsive@gmail.com>
	<winterbits.com>
*/

jQuery.noConflict()
jQuery(document).ready(function($){
	
	$(window).load(function() {
	
		/* Shortcode Accordion */
		$(".sc-accordion").wbaccordion({
			fullwidth: 550
		})
		
	})
	
	/* CSS fixes for old browsers */
	$("ul#menu > li:last-child").css({
		"border": "none",
		"padding-right": 0
	})
	
	$("input[type='submit']").addClass("button");
	
	/* Search bar style toggle */
	$("#toolbar #search-form .input-text").focus(function(){
		$(this).addClass("focus")
	}).blur(function(){
		if ($(this).val().length < 1) $(this).removeClass("focus")
	})
	
	/* Input's labels system */
	$(".focus-label").each(function(){
		var field = $(this),
			label = field.attr("title"),
			original = {
				"color": field.css("color"),
				"font-style": field.css("font-style")
			},
			labelstyle = {
				"color": "#868686",
				"font-style": "italic"
			}
			
		field
			.val(label)
			.css(labelstyle)
			.addClass("labeled")
			.focus(function(){
				if (field.hasClass("labeled"))
					field
						.val("")
						.removeClass("labeled")
						.css(original)
			})
			.blur(function(){
				if (!field.val().length)
					field
						.val(label)
						.addClass("labeled")
						.css(labelstyle)
			})
	})
	
	/* Calling Gallery & Projects scripts */
	showcase()
	
	/* Slides Play Overlay */
	var height = $("#featured").height(),
		play = ".play";
	
	$(play).css("height", height)
	
	$("#featured a:has(" + play + ")")
		.hoverIntent(function(){
			$(this).find(play).fadeIn();
		},
		function(){
			$(this).find(play).fadeOut(150);
		})
	
	/* Detecting Internet explorer 6 */
	var ie6 = (navigator.userAgent.indexOf("MSIE 6") >= 0) ? true : false
	
	/* Messages closing */
	if (!ie6) {
		$(".message:not(.sticky)").prepend('<a class="close" href="#">Close</a>');
		$(".message .close").click(function(){
			$(this).parent(".message").delay(100).slideUp(250)
			return false
		})
	}
	
	/* Internet explorer 6 transparency */
	if (ie6) DD_belatedPNG.fix('*')
	
	/* 
		Superfish dropdown menu
		http://users.tpg.com.au/j_birch/plugins/superfish/
	*/ 
	$("ul#menu, #toolbar ul").superfish({
		delay: 500,
		autoArrows: false,
		speed: 150,
		animation: { opacity: 'show', height: 'show' }
	})
	
	/*
		Fancybox lightbox
		http://fancybox.net/
	*/
	$("a.zoom").fancybox({
		'titleShow': false,
		'transitionIn': 'elastic',
		'transitionOut': 'elastic',
		'easingIn': ($.easing.def) ? "easeOutBack" : "swing",
		'easingOut': ($.easing.def) ? "easeOutBack" : "swing",
		'overlayShow': false
	})
	$("a.fullzoom").fancybox({
		'titleShow': false,
		'transitionOut': 'elastic',
		'width': '90%',
		'height': '95%',
		'overlayShow': true,
		'overlayColor': '#000',
		'overlayOpacity': 0.7,
		'centerOnScroll': true
	})
	$("a.youtube").click(function() {
		$.fancybox({
				'padding' : 0,
				'titleShow': false,
				'autoScale' : false,
				'transitionIn' : 'none',
				'transitionOut'	: 'fade',
				'overlayShow': true,
				'overlayColor': '#000',
				'overlayOpacity': 0.7,
				'centerOnScroll': true,
				'width' : 700,
				'height' : 426,
				'href' : this.href.replace(new RegExp("watch\\?v=", "i"), 'v/'),
				'type' : 'swf',
				'swf' : {
				   	'wmode' : 'transparent',
					'allowfullscreen' : 'true'
				}
			})
		return false;
	})
	$("a.vimeo").click(function() {
		$.fancybox({
				'padding' : 0,
				'titleShow': false,
				'autoScale' : false,
				'transitionIn' : 'none',
				'transitionOut'	: 'fade',
				'overlayShow': true,
				'overlayColor': '#000',
				'overlayOpacity': 0.7,
				'centerOnScroll': true,
				'width' : 700,
				'height' : 394,
				'href' : this.href.replace(new RegExp("([0-9])","i"),'moogaloop.swf?clip_id=$1'),
				'type' : 'swf'
			})
		return false;
	})
	$("a.media").fancybox({
		'titleShow': false,
		'transitionOut': 'fade',
		'overlayShow': true,
		'overlayColor': '#000',
		'overlayOpacity': 0.7,
		'centerOnScroll': true
	})
	
	/*
		Gallery & Projects scripts
	*/
	function showcase() {
		
		$(".gallery .entry").hover(function(){
			
			$(this)
				.find("img")
				.animate({ 
					marginTop: "-" + $(this).find("span").height()
				}, { 
					queue: false, 
					easing: ($.easing.def) ? "easeOutExpo" : "swing"
				})
			$(this)
				.find(".title")
				.stop(true, true)
				.animate({ 
					bottom: "-35px"
				}, { 
					easing: ($.easing.def) ? "easeOutExpo" : "swing"
				})
				
		}, function(){
				
			$(this)
				.find("img")
				.animate({
					marginTop: "0"
				}, { 
					queue: false, 
					easing: ($.easing.def) ? "easeOutBounce" : "swing"
			})
			$(this)
				.find(".title")
				.animate({
					bottom: "10px"
				}, 150)
				
		})
		
		$(".projects .entry .pic").hoverIntent(function(){
		
			$(this)
				.find(".details")
				.animate({ 
					height: "show"
				}, { 
					queue: false, 
					easing: ($.easing.def) ? "easeOutBounce" : "swing"
				})
				
		}, function(){
				
			$(this)
				.find(".details")
				.stop(true, true)
				.animate({
					height: "hide"
				}, { 
					easing: ($.easing.def) ? "easeOutExpo" : "swing"
				})
				
		})
	
	}
	
})

function filtering(container, columns) {
	
	var see = window.location.hash.substr(1);
	if (see && jQuery(container + " ." + see).length) {
		filter(see)
	}
	
	var all = "all",
		li = jQuery(".filter li:has(b)");
	
	li.click(function(){

		var c = jQuery(this).attr("class");
		if (!jQuery(this).hasClass("a")) {
			filter(c)
			jQuery(this).addClass("a").siblings().removeClass("a")
			if (c != all) {
				jQuery(this).filter(".a").css("opacity", 1).siblings(":has(b)").css("opacity", .5)
			} else {
				li.css("opacity", 1)
			}
		}
		
		return false;
	})
	.hover(
	function(){
		jQuery(this).css("opacity", 1).siblings(":has(b)").css("opacity", .5)
	},
	function(){
		if (!li.filter(".a").length) {
			li.css("opacity", 1)
		} else {
			if (!li.filter(".a").hasClass(all)) {
				li.filter(".a").css("opacity", 1).siblings(":has(b)").css("opacity", .5)
			} else {
				li.css("opacity", 1);
			}
		}
	})
	
	function filter(x) {
		jQuery(container)
			.css("height", jQuery(container).height())
			.children(".entry")
			.stop(true, true)
			.hide()
			.removeClass("odd")
			.removeClass("i")
			.each(function(i){
				if (jQuery(this).hasClass(x)) {
					
					jQuery(this).addClass("i")
					reodd()
					jQuery(this).delay(i*50).fadeIn(550)
					
				} else if (x == all) {
					
					jQuery(this).addClass("i")
					reodd()
					jQuery(this).delay(i*50).fadeIn(200)
					
				}
			})
	}
	
	function reodd() {
		if (columns > 1) {
			jQuery(container + " .i").each(function(i){
				var z = (i + 1) % columns;
				if (z === 0) {
					jQuery(this).addClass("odd");
				}
			})
		}
	}
	
}