/**
* hoverIntent r5 // 2007.03.27 // jQuery 1.1.2+
* <http://cherne.net/brian/resources/jquery.hoverIntent.html>
* 
* @param  f  onMouseOver function || An object with configuration options
* @param  g  onMouseOut function  || Nothing (use configuration options object)
* @author    Brian Cherne <brian@cherne.net>
*/
(function($){$.fn.hoverIntent=function(f,g){var cfg={sensitivity:7,interval:100,timeout:0};cfg=$.extend(cfg,g?{over:f,out:g}:f);var cX,cY,pX,pY;var track=function(ev){cX=ev.pageX;cY=ev.pageY;};var compare=function(ev,ob){ob.hoverIntent_t=clearTimeout(ob.hoverIntent_t);if((Math.abs(pX-cX)+Math.abs(pY-cY))<cfg.sensitivity){$(ob).unbind("mousemove",track);ob.hoverIntent_s=1;return cfg.over.apply(ob,[ev]);}else{pX=cX;pY=cY;ob.hoverIntent_t=setTimeout(function(){compare(ev,ob);},cfg.interval);}};var delay=function(ev,ob){ob.hoverIntent_t=clearTimeout(ob.hoverIntent_t);ob.hoverIntent_s=0;return cfg.out.apply(ob,[ev]);};var handleHover=function(e){var p=(e.type=="mouseover"?e.fromElement:e.toElement)||e.relatedTarget;while(p&&p!=this){try{p=p.parentNode;}catch(e){p=this;}}if(p==this){return false;}var ev=jQuery.extend({},e);var ob=this;if(ob.hoverIntent_t){ob.hoverIntent_t=clearTimeout(ob.hoverIntent_t);}if(e.type=="mouseover"){pX=ev.pageX;pY=ev.pageY;$(ob).bind("mousemove",track);if(ob.hoverIntent_s!=1){ob.hoverIntent_t=setTimeout(function(){compare(ev,ob);},cfg.interval);}}else{$(ob).unbind("mousemove",track);if(ob.hoverIntent_s==1){ob.hoverIntent_t=setTimeout(function(){delay(ev,ob);},cfg.timeout);}}};return this.mouseover(handleHover).mouseout(handleHover);};})(jQuery);
/*
*	wbaccordion.js - Carta Accordion 1.2
*	Stefano Giliberti <kompulsive@gmail.com>
*	winterbits.com
*/
(function($){$.fn.wbaccordion=function(options){var defaults={slide:".slide",content:".slide-content",first:1,fullwidth:730,dropshadow:true,hoveropacity:0.5,hovercolor:"#FFF",speed:700,easing:"easeOutExpo"};var options=$.extend(defaults,options);return this.each(function(){var slider=$(this),slides=slider.find(options.slide)
slides.css("width",options.fullwidth)
var count=slides.length,minwidth=(slider.width()-options.fullwidth)/(count-1),tabindex=options.first-1,last=slider.find(options.slide+":eq("+tabindex+")"),easing=($.easing.def)?options.easing:"linear",slideimages=slides.children("img").hide(),height=slides.parent().height()
open(slider.find(options.slide+":eq("+tabindex+")"))
slider.find(options.slide+":not(:eq("+tabindex+"))").css("width",minwidth)
slideimages.each(function(i){$(this).delay(i*200).fadeIn()})
$('<div class="overlay"></span>').prependTo(slides).css("position","absolute").css("width",$(this).width()).css("height",height).css("z-index","50").css("background",options.hovercolor).hide()
slides.find(options.content).hide()
if(options.dropshadow){slider.find(options.slide+":not(:last-child)").prepend('<div class="drop-shadow"></span>')
slider.find(".drop-shadow").css("height",height)}
slides.hoverIntent(function(){if(!$(this).hasClass("open")){close(last)
open(this)
last=this;}},function(){});slides.hover(function(){$(this).siblings(options.slide).find(".overlay").show().css("opacity",options.hoveropacity)},function(){$(this).siblings(options.slide).find(".overlay").hide()})
function open(tab){$(tab).addClass("open").animate({width:options.fullwidth},{queue:false,duration:options.speed,"easing":easing})
if($(tab).find(options.content).length)
$(tab).find(options.content).delay(options.speed/2).slideDown(100)}
function close(tab){if($(tab).find(options.content).length){$(tab).find(options.content).stop(true,true).hide()}
$(tab).removeClass("open").animate({width:minwidth},{queue:false,duration:options.speed,"easing":easing})}})}})(jQuery);
/*
*	wbform.js - jQuery Form Processor
*	Stefano Giliberti <kompulsive@gmail.com>
*	winterbits.com
*/
(function($){$.fn.wbform=function(op){var base={select:"input:not(:submit), textarea, select",required:"required",email:true,website:false,asterisks:true,disable:true,get:"wbform",str:{general:"Please, fill out all required fields properly.",email:"Please, enter a valid email address.",website:"Please, enter a valid website url.",success:"Thank you! We have received your message.",unexpected:"An error occured. Please, try again later."},names:{email:"email",website:"website"},build:{info:"message",success:"success",notice:"notice",red:"red",highlight:"highlight",html:"p"},action:null};var op=$.extend(base,op);return this.each(function(){var form=$(this),target=form.attr("action")+"?"+op.get,hit=form.find(":submit"),inputs=form.find(op.select);if(op.asterisks)form.find("."+op.required).parent().find("label").append(' <span class="'+op.build.red+'">*</span>');form.submit(function(){var values=inputs.serializeArray(),error;$("."+op.build.highlight).removeClass(op.build.highlight)
$.each(values,function(i,input){if(form.find('[name="'+input.name+'"]').hasClass(op.required)){if(!$.trim(input.value)){spot(input.name,op.str.general)}
else if(op.email&&input.name==op.names.email){if(!validate(input.value,"email"))spot(input.name,op.str.email);}
else if(op.website&&input.name==op.names.website){if(!validate(input.value,"website"))spot(input.name,op.str.website);}}})
if(!error)$.post(target,values,function(i){process(i)})
function spot(name,message){error=true;form.find("[name='"+name+"']").addClass(op.build.highlight).focus();if(!form.find("."+op.build.info).length){$('<'+op.build.html+'>'+message+'</'+op.build.html+'>').addClass(op.build.info).addClass(op.build.notice).hide().appendTo(form).slideDown()}
else{form.find("."+op.build.info).text(message);}}
function validate(str,mode){switch(mode){case"email":var ptrn=new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i)
break;case"website":var ptrn=new RegExp(/(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/)
break;}
return ptrn.test(str);}
function process(data){if(op.disable)endi("disabled");if(op.action)base["action"]();$("."+op.build.info).remove()
$("."+op.build.highlight).removeClass(op.build.highlight)
switch(data){default:$('<'+op.build.html+'></'+op.build.html+'>').text(op.str.success).addClass(op.build.info).addClass(op.build.success).appendTo(form).hide().fadeIn()
break;case"1":endi(null);$('<'+op.build.html+'></'+op.build.html+'>').text(op.str.general).addClass(op.build.info).addClass(op.build.notice).appendTo(form).hide().fadeIn()
break;case"2":endi(null);$('<'+op.build.html+'></'+op.build.html+'>').text(op.str.unexpected).addClass(op.build.info).addClass(op.build.notice).appendTo(form).hide().fadeIn()
break;}}
function endi(mode){form.find(op.select).attr("disabled",mode);hit.attr("disabled",mode);}
return false;})})}})(jQuery);