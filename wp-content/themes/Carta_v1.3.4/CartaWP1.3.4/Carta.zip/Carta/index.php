<?php get_header(); ?>

<?php if (ca_slider != 'None') include_once(dir.(ca_alt_slides_manager ? 'simplified-slider.php' : 'slider.php')); ?>

<?php
if (ca_frontpage && ca_frontpage != __('Choose a page', 'carta') && ca_frontpage == ca_gallery_page)
{
	include_once(TEMPLATEPATH.'/gallery.php');
}
	else if (ca_frontpage && ca_frontpage != __('Choose a page', 'carta') && ca_frontpage == ca_projects_page)
{
	include_once(TEMPLATEPATH.'/projects.php');
}
	else if (ca_frontpage && ca_frontpage != __('Choose a page', 'carta') && ca_frontpage == ca_blog_page)
{
	include_once(TEMPLATEPATH.'/blog.php');
}
	else
{
?>

	<!-- home's content -->
	<div id="home" class="type">
		
		<?php
		if (ca_frontpage) {
			query_posts('pagename='.ca_frontpage);
			while (have_posts()) : the_post(); the_content(); endwhile;
			wp_reset_query();
		}
		?>
		
	<!-- closing: content -->
	</div>

<?php } ?>

<?php get_footer(); ?>