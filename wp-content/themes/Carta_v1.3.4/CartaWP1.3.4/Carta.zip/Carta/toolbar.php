<?php
/*
	The Blog Toolbar
*/

$cura = (get_query_var('author_name') ? get_userdatabylogin(get_query_var('author_name')) : get_userdata(get_query_var('author')));
?>

<!-- toolbar -->
<div id="toolbar">
	
	<ul>
	
<?php if (!is_archive()) : ?>
<?php if (!ca_blog_toolbar_archives) : ?>
		<li>
			<?php echo __('See the', 'carta').' <strong>'.__('Archives', 'carta').'</strong>'; ?>
			<ul>
				<?php wp_get_archives(); ?>
			</ul>
		</li>
<?php endif; ?>
<?php if (!ca_blog_toolbar_cats) : ?>
		<li>
			<?php echo __('Filter by', 'carta').' <strong>'.__('Category', 'carta').'</strong>'; ?>
			<ul>
				<?php wp_list_categories('exclude='.$exc.'&title_li='); ?>
			</ul>
		</li>
<?php endif; ?>
<?php if (ca_blog_toolbar_tags) : ?>
		<li>
			<?php echo __('Filter by', 'carta').' <strong>'.__('Tags', 'carta').'</strong>'; ?>
			<ul>
				<?php
				$tags = get_tags();
				if ($tags) {
					foreach ($tags as $tag) {
						echo '<li><a href="'.get_tag_link($tag->term_id).'" title="'.sprintf(__('View all posts regarding %s', 'carta'), $tag->name).'" '.'>'.$tag->name.'</a></li>';
					}
				}
				?>
			</ul>
		</li>
<?php endif; ?>
<?php endif; ?>

<?php if (is_category()) : ?>
		<li>
			<?php _e('Posts filed in', 'carta') ?> <strong><?php single_cat_title(); ?></strong>
			<ul>
				<?php wp_list_categories('exclude='.$exc.'&title_li='); ?>
			</ul>
		</li>
<?php endif; if (is_tag()) : ?>
		<li>
			<?php _e('Posts regarding', 'carta') ?> <strong><?php single_tag_title(); ?></strong>
			<ul>
				<?php if (get_the_tag_list()) echo get_the_tag_list('<li>','</li><li>','</li>'); ?>
			</ul>
		</li>
<?php endif; if (is_day()) : ?>
		<li>
			<?php _e('Archive of', 'carta') ?> <strong><?php the_time('F jS, Y'); ?></strong>
			<ul>
				<?php wp_get_archives(); ?>
			</ul>
		</li>
<?php endif; if (is_month()) : ?>
		<li>
			<?php _e('Archive of', 'carta') ?> <strong><?php the_time('F, Y'); ?></strong>
			<ul>
				<?php wp_get_archives(); ?>
			</ul>
		</li>
<?php endif; if (is_year()) : ?>
		<li>
			<?php _e('Archive of', 'carta') ?> <strong><?php the_time('Y'); ?></strong>
			<ul>
				<?php wp_get_archives(); ?>
			</ul>
		</li>
<?php endif; if (is_author()) : ?>
		<li>
			<?php _e('Articles written by', 'carta') ?> <b><?php echo $cura->display_name; ?></b>
		</li>
<?php endif; ?>

	</ul>
	
<?php if (!ca_blog_toolbar_search) : ?>
	<form role="search" method="get" id="search-form" action="<?php echo get_option('home'); ?>">
		<input type="text" class="input-text" value="<?php the_search_query(); ?>" name="s" id="s" />
	</form>
<?php endif; ?>
	
	<!-- subscribe button -->
	<a id="subscribe" href="<?php echo get_bloginfo('rss_url') ?>"></a>

<!-- closing: toolbar -->
</div>