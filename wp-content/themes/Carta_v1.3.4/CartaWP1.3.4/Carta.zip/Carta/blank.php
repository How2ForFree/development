<?php
/*
	Template name: Blank Page (No Sidebar)
*/
get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
	<div class="type">
	
		<?php the_content(); ?>
		
	</div>
	
<?php endwhile; endif; ?>
<?php get_footer(); ?>