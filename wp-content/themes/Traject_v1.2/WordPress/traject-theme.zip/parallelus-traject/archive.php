<?php get_header(); 


	// Get options for page
	//-----------------------------------------------------------
	
	// setup title and description
	$catTitle = single_cat_title(NULL, false);
	if (is_string(category_description())) {
		$catDesc = str_replace('</p>','',str_replace('<p>','',category_description()));
	}
	if (is_category()) { 
		if (!$catDesc) $catDesc = 'Browsing posts in '.$catTitle;
	} elseif( is_tag() ) {
		$catTitle = single_tag_title(NULL, false);
		$catDesc = 'Posts tagged as "'.$catTitle.'"';
	} elseif (is_day()) {
		$catTitle = get_the_time(get_option('date_format'));
		$catDesc = 'Posts published on '.$catTitle;
	} elseif (is_month()) {
		$catTitle = get_the_time('F Y');
		$catDesc = 'Posts published in '.$catTitle;
	} elseif (is_year()) {
		$catTitle = get_the_time('Y');
		$catDesc = 'Posts published in '.$catTitle;
	} elseif (is_author()) {
		$currentAuthor = $wp_query->get_queried_object();
		$catTitle = $currentAuthor->display_name?$currentAuthor->display_name:$currentAuthor->nickname;
		$catDesc = 'Posts published by '.$catTitle;
	} elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { 
		$catTitle = 'Archives';
	} 
	
	// title
	$pageTitle = $catTitle;
	
	// breadcrumbs
	$hideBreadcrumbs = get_post_meta($post->ID, 'breadcrumbOff', true);

	// sub-title
	$subTitle = get_post_meta($post->ID, 'subTitle', true);
	if ( $subTitle == '' ) {
		$subTitle = $catDesc; // default category/post sub-title
	}
	
	// page icon
	$pageIcon = get_post_meta($post->ID, 'pageIcon', true);
	if ( $pageIcon == 'custom' ) {
		$pageIcon = '<img src="'. get_post_meta($post->ID, 'pageIcon_custom', true) .'" width="128" height="128" alt="Post" />';	// Custom
	} elseif ( $pageIcon == '' ) {
		$pageIcon = '<img src="'. $themePath .'images/icons/post.png" width="128" height="128" alt="Post" />';	// Default
	} else {
		$pageIcon = '<img src="'. $pageIcon .'" width="128" height="128" alt="Post" />';	// Selected Icon
	}
		
	?>

		<div id="PageOverlay">
			<div id="PageOverlayContent">
				<div class="contentArea">
					<h1 class="pageTitle"><?php echo $pageTitle; ?></h1>
					<div class="pageIcon"><?php echo $pageIcon;?></div>
				</div>
			</div>
		</div> <!-- END id="PageOveraly" -->

		<div id="Showcase">
			<div id="ShowcaseContent">
				<div class="contentArea">
					<h2 class="pageTagLine"><?php echo $subTitle; ?></h2>
				</div>
			</div>
		</div> <!-- END id="Showcase" -->	
	
		<div id="MainPage">
			<div id="MainPageContent">
				<div class="contentArea">
					
					<div class="two_third">

						<div class="breadcrumbs" <?php  if ($hideBreadcrumbs) { echo 'style="background: none;"'; } ?>>
							<?php  if (!$hideBreadcrumbs) { show_breadcrumbs(); } ?>
						</div>

						<?php 
						if ( have_posts() ) : 
							while ( have_posts() ) : the_post();
							
								// get the post image
								$thisImg = showImage(593, 199, get_the_title(), 'blog');
					
								?>
								<div class="blogPost">
								
									<div class="blogPostInfo">
										<span class="postComments"><?php comments_popup_link('Comments', '1 comment', '% comments'); ?></span>
										<?php
										// post date
										if (get_theme_var('postsShowDate') !== '' ) {
											echo '<span class="postDate">'. get_the_time('M') .' '. get_the_time('j') .', '. get_the_time('Y') .'</span>';
										 	echo '&nbsp; | &nbsp;';
										} 
										// Author name
										if (get_theme_var('postsShowAuthor') !== '' ) { ?>
											<span class="postAuthor">Posted by <?php the_author_posts_link(); ?> in </span>
											<?php 
										} ?>
										<span class="postCategories"><?php the_category(', ') ?></span>
									</div>
									<?php
									if ( $thisImg['showImage'] ) { ?>
										<a href="<?php echo get_permalink() ?>" class="imgLarge iconDoc">
											<?php echo $thisImg['full']; ?>
											<span class="imgFrame"></span>
										</a>
									<?php } ?>
									
									<h2 onclick="document.location.href='<?php echo get_permalink(); ?>'" style="cursor:pointer;" class="postTitle"><?php the_title(); ?></h2>
					
									<p><?php echo str_replace(' [...]', '...', get_the_excerpt()); ?></p>
									<p><button type="button" onclick="document.location.href='<?php echo get_permalink() ?>'" class="btn">Read more</button></p>
									
								</div>
									
								<?php
							endwhile; 
						endif; // End while have_posts() ?>
						
						<!-- End of Content -->
						<div class="clear"></div>
					
						<?php get_pagination(); ?>
	
						<!-- Extras -->
						<div class="postFooter">
							<?php edit_post_link('Edit','<p class="postEdit">','</p>'); ?>
						</div>
	
						<!-- End of Content -->
						<div class="clear"></div>
	
					</div> <!-- end  <div class="two-thirds"> -->
										
<?php get_sidebar(); ?>

<?php get_footer(); ?>
