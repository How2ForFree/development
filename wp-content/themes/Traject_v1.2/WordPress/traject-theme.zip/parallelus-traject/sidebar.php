<?php global $leftSidebar; ?>
<div class="one_third <?php if (!$leftSidebar) { echo 'last'; }?>">
					
	<div class="sidebar">
		<div class="sidebarBox-1">
			<div class="sidebarBox-2">

				<?php generated_dynamic_sidebars(1); ?>

			</div>
		</div>
	</div> <!-- END class="sidebar" -->
	
</div>