<?php

// Check content type for home page
$HomeContentType = theme_var('homeContentSource','return');

// Output based on content type 
switch ($HomeContentType) {

	case 'categories':
		include(TEMPLATEPATH."/home-categories.php");
		break;
	
	case 'page':
		include(TEMPLATEPATH."/home-page.php");
		break;
		
	case 'post':
		include(TEMPLATEPATH."/home-post.php");
		break;

	default:
		include(TEMPLATEPATH."/home-categories.php");

}

?>