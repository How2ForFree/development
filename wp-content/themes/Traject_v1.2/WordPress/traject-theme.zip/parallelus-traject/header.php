<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php global $cssPath, $themePath; ?>
<head>
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>"  />
	<meta  http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
	<meta name="author" content="Parallelus" />

	<title><?php
	if (is_home()) { bloginfo('name'); echo " - "; bloginfo('description'); }
	elseif (is_category() || is_tag()) { single_cat_title(); }
	elseif (is_single() || is_page()) { single_post_title(); }
	elseif (is_search()) { _e('Search Results:', THEMENAME); echo " ".wp_specialchars($s); }
	else { echo trim(wp_title(' ',false)); }
	if (!is_home()) { theme_var('appendToPageTitle'); }
	?></title>
	
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

	<!-- Favorites icon -->
	<link rel="shortcut icon" href="<?php if (get_theme_var('favicon')) : theme_var('favicon'); else: echo 'http://para.llel.us/favicon.ico'; endif; ?>" />
	
	<!-- Style sheets -->
	<link rel="stylesheet" type="text/css" href="<?php echo $cssPath; ?>css/reset.min.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo $cssPath; ?>css/menu.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo $cssPath; ?>css/fancybox.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo $cssPath; ?>style-default.css" />

    <?php
	// Skin CSS include (selected in theme options)
	if (get_theme_var('skinName')) { 
		if (get_theme_var('skinName') == 'custom' && get_theme_var('custom_skin')) {
			$skinCSS = get_theme_var('custom_skin') .'.css';
		} else {
			$skinCSS = 'style-skin-'. get_theme_var('skinName') .'.css';
		}
		echo '<!-- Skin Style Sheet -->';
		echo '<link rel="stylesheet" href="'. $cssPath . $skinCSS .'" type="text/css" id="SkinCSS" />';
	}
	
	// Check if breadcrumbs are disabled globally
	if (get_theme_var('showBreadcrumbs', 1) == false) {
		echo '<style type="text/css"> .breadcrumbs { background: none; } </style>';
	}
	
	// Includes the jQuery framework
	if( !is_admin()){
		wp_deregister_script('jquery');
		wp_register_script('jquery', ($themePath ."js/jquery-1.4.2.min.js"), false, '1.4.2');
		wp_enqueue_script('jquery');
	}

	// calls hook to WordPress head functions
	wp_head(); 
	?>

	<!-- jQuery framework and utilities -->
	<script type="text/javascript">
		$j = jQuery.noConflict();
		var themePath = '<?php echo $themePath; ?>'; // for js functions 
		var blogPath = '<?php bloginfo('url'); ?>'; // for js functions 
	</script>
	<script type="text/javascript" src="<?php echo $themePath; ?>js/jquery.easing.1.3.min.js"></script>
	<script type="text/javascript" src="<?php echo $themePath; ?>js/hoverIntent.min.js"></script>
	<!-- Drop down menus -->
	<script type="text/javascript" src="<?php echo $themePath; ?>js/menu.js"></script>
	<?php
	// Font Replacement
	if (get_theme_var('fontReplacement', 1) != false) : ?>
		<!-- Font replacement (cufon) -->
		<script type="text/javascript" src="<?php echo $themePath; ?>js/cufon-yui.js"></script>
		<script type="text/javascript" src="<?php echo $themePath; ?>js/Vegur.Light.font.js"></script>
		<script type="text/javascript" src="<?php echo $themePath; ?>js/Vegur.font.js"></script>
		<script type="text/javascript">
			Cufon.replace('h1, h2, h3, h4, h5, h6, #fancybox-title-main', { fontFamily: 'Vegur' });
			Cufon.replace('.pageTitle, #Showcase h1, #Showcase h2, #Showcase h3, #Showcase h4, #Showcase h5, #Showcase h6', { fontFamily: 'Vegur Light' });
			function modalStart() {
				Cufon.replace('#fancybox-title-main', { fontFamily: 'Vegur' });
			}
		</script>
	<?php else: ?>
		<script type="text/javascript">
			function modalStart() {
				return false;
			}
		</script>
	<?php endif; ?>

	<!-- Input labels -->
	<script type="text/javascript" src="<?php echo $themePath; ?>js/jquery.overlabel.min.js"></script>
	<!-- Inline popups/modal windows -->
	<script type="text/javascript" src="<?php echo $themePath; ?>js/jquery.fancybox-1.3.1.pack.js"></script>
	<!-- Slide shows -->

<?php
// setup slide show
if (get_theme_var('slideShowDisabled') != true && is_home()) {

	// slide change speed
	if (get_theme_var('slideShowTimeout')) {
		$ss_timeout = get_theme_var('slideShowTimeout');
	} else {
		$ss_timeout = '0';
	}

	echo '<!-- Slide show -->';

	if (get_theme_var('slideShowType') == 'nivo') {

		// output the javascript for the Galler View slide show ?>

		<!-- Nivo -->
		<link rel="stylesheet" type="text/css" href="<?php echo $cssPath ?>css/nivo-slider.css" />
		<script type="text/javascript" src="<?php echo $themePath ?>js/jquery.nivo.slider.pack.js"></script>
		<script type="text/javascript">
			$j(document).ready(function($) {
				if($('#Slides').length>0){$('#Slides')
					.nivoSlider({
						effect:'random',
						slices:19,
						animSpeed:800,
						pauseTime:<?php echo $ss_timeout . '000'; ?>,
						directionNav:true,
						directionNavHide:true,
						controlNav:false,
						pauseOnHover:false,
						manualAdvance:false,
						beforeChange:function(){},
						afterChange:function(){}})
				}
			});
		</script>
		<?php

	} elseif (get_theme_var('slideShowType') == 'galleryView') {

		// output the javascript for the Galler View slide show ?>

		<!-- Gallery View Slide Show -->
		<script type="text/javascript" src="<?php echo $themePath ?>js/galleryview/jquery.timers-1.1.2.js"></script>
		<script type="text/javascript" src="<?php echo $themePath ?>js/galleryview/jquery.galleryview-2.0-pack.js"></script>
		<script type="text/javascript">
			// initialize slideshow (Gallery View)
			jQuery(document).ready(function() {
				if ($j('#GalleryView').length > 0) {
					$j('#GalleryView').galleryView({
						show_panels: true,
						show_filmstrip: true,
						panel_width: 978,
						panel_height: 390,
						frame_width: 87,
						frame_height: 45,
						frame_gap: 8,
						pointer_size: 16,
						pause_on_hover: true,
						filmstrip_position: 'bottom',
						overlay_position: 'bottom',
						nav_theme: 'dark',
						transition_speed: 800,
						transition_interval: <?php echo $ss_timeout . '000'; ?>
					});
				}
			});
		</script>
		<link rel="stylesheet" type="text/css" href="<?php echo $cssPath ?>css/galleryview.min.css" />
		<?php

	} else {

		// output the javascript for the Cycle Plug-in (Default) 		

		echo '<!-- Cycle Slide Show -->';
		if (!$jQueryCycle) {
			echo '<script type="text/javascript" src="'.$themePath.'js/jquery.cycle.all.min.js"></script>';
			$jQueryCycle = true; // plug-in included (prevents 2nd include by dynamic skin changer)
		}
		?>

		<script type="text/javascript">
			// initialize slideshow (Cycle)
			jQuery(document).ready(function() {
				if ($j('#Slides').length > 0) {
					$j('#Slides').cycle({ 
						fx: <?php
							// slide transitions
							$the_slides = $GLOBALS['_SS_ItemLevels'];
							$the_transitions =  $GLOBALS['_SS_ItemValues'];
							if (is_array($the_slides)) {
								$slide_count = 0;
								echo "'";
								foreach($the_slides as $value) {
									$id = $value['id'];
									if ($slide_count>0) { echo ','; }
									echo $the_transitions['ss-'. $id .'-slideTransition'];
									$slide_count++;
								}
								echo "',";
							} else {
								echo "'scrollHorz',";
							}
							?>
						speed: 750,
						timeout:  <?php echo $ss_timeout . '000'; ?>, 
						randomizeEffects: false, 
						easing: 'easeOutCubic',
						next:   '.slideNext', 
						prev:   '.slidePrev',
						pager:  '#SlidePager',
						cleartypeNoBg: true,
						before: function() {
							// reset the overlay for the next slide
							$j('#SlideShow-Middle').css('cursor','default').unbind('click'); },
						after: function() {
							// get the link and apply it to the overlay
							var theLink = $j(this).children('a:first');
							var linkURL = (theLink) ? theLink.attr('href') : false;
							if (linkURL) {
								$j('#SlideShow-Middle').css('cursor','pointer').click( function() {
									document.location.href = linkURL;
								});
							}
						}
					});
				}
			});
		</script>

		<?php

	} // end if/else ( slideShowType == 'galleryView' ) 



} // end if ( slideShowActive ) ?>


	<!-- IE only includes (PNG Fix and other things for sucky browsers -->
	
	<!--[if lt IE 7]>
		<link rel="stylesheet" type="text/css" href="<?php echo $cssPath ?>css/ie-6.css">
		<script type="text/javascript" src="<?php echo $themePath; ?>js/pngFix.min.js"></script>
		<script type="text/javascript"> 
			$j(document).ready(function(){ 
				$j(document.body).supersleight();
			}); 
		</script> 
	<![endif]-->
	<!--[if IE]><link rel="stylesheet" type="text/css" href="<?php echo $cssPath ?>css/ie-all-versions.css"><![endif]-->

	<!-- Functions to initialize after page load -->
	<script type="text/javascript" src="<?php echo $themePath; ?>js/onLoad.js"></script>

	<?php 
	// Page Layout Style
	if (get_theme_var('layoutWide')) {
		$bodyClass = ' class="alternate"';
	}
	
	?>
</head>
<body<?php echo $bodyClass ?>>

<div id="Wrapper">

	<div id="Top">
		<div id="TopContainer">
			
			<!-- Search -->
			<div id="SearchWrapper">
				<div id="Search">
					<form action="<?php bloginfo('home'); ?>" id="SearchForm" method="get">
						<p style="margin:0;"><input type="text" name="s" id="SearchInput" value="" /></p>
						<p style="margin:0;"><input type="submit" id="SearchSubmit" class="noStyle" value="" /></p>
				</form>
				</div>
			</div>
			
			<!-- Main Menu: MegaMenu -->
			<div id="MainMenu">
				<ul id="MegaMenu">
				
					<li class="<?php if (is_home()) : echo 'current'; endif; ?>"><a href="<?php bloginfo('url'); ?>">Home</a></li>
					<?php printMegaMenu(); ?>
					
				</ul>
			</div> <!-- END id="MainMenu" -->
			
		</div>
	</div> <!-- END id="Top" -->
	
	
	
	
	<?php
	// Set Logo Variables
	
	// Logo alignment
	if (get_theme_var('logoAlignment') == "left") {
		$logoAlign = 'style="text-align: left;"';
	}elseif (get_theme_var('logoAlignment') == "right") {
		$logoAlign = 'style="text-align: right;"';
	}
	// Logo overlap
	$logoPosition = '';
	if (get_theme_var('logoOverlap', 1) == false) {
		$logoPosition = 'style="margin-bottom: 0;"';	
	}
	
	// Home page / Default Large Logo
	if (get_theme_var('logoImage')) {
		$themeLogo = '<a href="'. get_bloginfo('url') .'" id="Logo"><img src="'. get_theme_var('logoImage') .'" alt="'. get_bloginfo('name') .'" '. $logoPosition .' /></a>';
	}else {
		$themeLogo = '<a href="'. get_bloginfo('url') .'" id="Logo"><img src="'. $themePath .'images/spacer.gif" class="skinLogo" alt="'. get_bloginfo('name') .'" '. $logoPosition .' /></a>';
	}

	
	// add home page header elements
	if (is_home()) {
	
		?>
		<!-- Logo -->
		<div id="LogoHeader" <?php echo $logoAlign; ?>>
			<?php echo $themeLogo; ?>
		</div>

		
		<?php
	
		if (get_theme_var('slideShowDisabled') != true) {
		
			if (get_theme_var('slideShowType') == 'nivo') {  ?>

				<!-- Slide show: Nivo -->
				<div id="SlideShow">
					<div id="SlideShow-Images">
						<div id="NivoSS">
							<div id="Slides">
								<?php printSlideShowItems(); ?>
							</div>
						</div>
					</div>
					<div id="SlideShow-Top"></div>
					<div id="SlideShow-Middle"></div>
					<div id="SlideShow-Bottom"></div>
				</div> <!-- END id="SlideShow" -->
	
			<?php
			} elseif (get_theme_var('slideShowType') == 'galleryView') { ?>
		
				<!-- Slide show: jQuery GalleryView -->
				<div id="SlideShow-GalleryView">
					<ul id="GalleryView">
						<?php printSlideShowItems(); ?>
					</ul>
				</div>
		
				<?php
			} else {  ?>	
	
				<!-- Slide show: jQuery Cycle (default) -->
				<?php $height = get_theme_var('slideShowHeight');?>
				<div id="SlideShow">
					<div id="SlideShow-Images" style="height:<?php echo $height; ?>px;">
						<div id="CyclePlugin">
							<div id="Slides">
							<?php printSlideShowItems(); ?>
							</div>
						</div>
					</div>
					<?php if(get_theme_var('slideShowControl') !== "off"){
							
							if(get_theme_var('slideShowControl') == "show_always"){
							echo '<div id="SlideShow-Controls-Show">'; 
							}
						else{echo '<div id="SlideShow-Controls">';}
							 
							 ?>
							 
							<div id="SlideNextPrev">
							<a href="#" class="slideNext"></a>
							<a href="#" class="slidePrev"></a>
						</div>
						<div id="SlidePager"></div>
					</div>
						<?php } ?>
					<div id="SlideShow-Top"></div>
					<div id="SlideShow-Middle" style="height:<?php echo $height-21; ?>px;"></div>
					<div id="SlideShow-Bottom"></div>
				</div> <!-- END id="SlideShow" -->
			
				<?php
		
			} // end if/else ( slideShowType == 'galleryView' ) 
		
			if (get_theme_var('slideShowType') == 'galleryView') {
				echo '<div id="SlideShow-Shadow" class="galleryViewShadow"></div>';
			} else {
				echo '<div id="SlideShow-Shadow"></div>';
			}
		
		} // end if ( theme_var('slideShowDisabled', 'return') != true && is_home() ) 
		?>
		
		
	<?php 
	
	if (get_theme_var('featuredContentActive') !== '') { 
		
		?>
		
		<!-- Carousel (for featured content) -->
		<script type="text/javascript" src="<?php echo $themePath; ?>js/jquery.jcarousel.min.js"></script>
		<script type="text/javascript">
		function mycarousel_initCallback(carousel) {		
			jQuery('#FeaturedNext').bind('click', function() { carousel.next(); return false; });
			jQuery('#FeaturedPrev').bind('click', function() { carousel.prev(); return false; });
		};
		// Load product carousel...
		jQuery(document).ready(function() {
			jQuery("#FeaturedContent").jcarousel({
				scroll: <?php theme_var('featuredContentScrollCount',3); ?>,
				visible: <?php theme_var('featuredContentCount',5); ?>,
				initCallback: mycarousel_initCallback,
				buttonNextHTML: null,
				buttonPrevHTML: null
			});
		});
		</script>

		<div id="PageTop"></div>
		<div id="PageWrapper">
			
			<div id="PageOverlay">
				<div id="PageOverlayContent">
						
						<div class="contentArea" style="position:relative; width:974px;">

							<div id="FeaturedContent">
								<div class="featuredItems">

									<ul>

									<?php
									// Retrieve variables for Featured Content
									//................................................................
									$_Levels = get_theme_var('Featured-ItemLevels');
									$Featured_Levels = $_Levels['SortList'];
									$Featured_Values = get_theme_var('Featured-ItemValues');
									
									// Print 
									
										if (is_array($Featured_Levels) && is_array($Featured_Values)) {
										
											$options = $Featured_Values;

											if (count($Featured_Levels) > 0) {
										
												foreach ($Featured_Levels as $key => $value) {
										
													// get variables setup
													$id = $value['id'];
													$itemTitle = $options['Featured-'. $id .'-title'];
													$titleTag = ($itemTitle !== '') ? '<h3 class="featuredTitle">'. $itemTitle .'</h3>' : '';
													$itemDesc = $options['Featured-'. $id .'-description'];
													if ($itemDesc !== '') { 
														$descTag = '<p>'. $itemDesc .'</p>';	// if we have a description
													} elseif ($titleTag == '') {
														$descTag = '&nbsp;';	// no description and no title, add blank line (creates proper bottom spacing :)
													}
													$itemLinkType = $options['Featured-'. $id .'-linkType'];
													$imgAlt = ($itemTitle !== '') ? $itemTitle : 'Featured';
													
													// get link path
													switch ($options['Featured-'. $id .'-linkType']) {
														case 'page':
															$itemURL = get_page_link($options['Featured-'. $id .'-linkPage']);
															break;
														case 'category':
															$itemURL = get_category_link($options['Featured-'. $id .'-linkCategory']);
															break;
														case 'url':
															$itemURL = $options['Featured-'. $id .'-linkURL'];
															break;
														default:
															$itemURL = "#";
															break;
													} // end switch linkType
													
													// image variables
													$itemImgFrame = '';
													$itemImgWidth = '';
													$itemImgClass = '';
													$itemImg = $options['Featured-'. $id .'-image'];
													
													// use small containers (forces image size)
													if (get_theme_var('featuredContentImageContainers') !== '') {
														$itemImgFrame = '<span class="imgFrame"></span>';
														$itemImgSize = 'width="160" height="108"';
														$itemImgClass .= ' imgSmall noIcon';
													}
													// image resizing
													if (get_theme_var('featuredContentImageResize','1') != false) {
														$imgW = floor( ( 936 - (26 * get_theme_var('featuredContentCount',5)) ) / get_theme_var('featuredContentCount',5) ); // = ( total width - ( margin * #_of_items) ) / #_of_items
														$itemImg = $themePath .'includes/timthumb.php?src='. $itemImg .'&amp;w='. $imgW .'&amp;zc=1';
													}
													
													?>
													<li>
														<?php if ($itemURL != '#') {
															echo '<a href="'. $itemURL .'" class="'. $itemImgClass .'">';
														} ?>
															<img src="<?php echo $itemImg; ?>" <?php echo $itemImgSize; ?> alt="<?php echo $imgAlt; ?>" />
															<?php echo $itemImgFrame; ?>
														<?php if ($itemURL != '#') {
															echo '</a>';
														} ?>
														<?php echo $titleTag . $descTag; ?>
													</li>
										
													<?php
													
												} // END - for each
											}
										} // END - if is array
									
									?>
									
									</ul>

								</div>
								<div class="featuredScroll">
									<a href="#" id="FeaturedNext">Next</a>
									<a href="#" id="FeaturedPrev">Previous</a>
								</div>
								
							</div> <!-- END id="FeaturedContent" -->
							<div class="clear"></div>					
						
						</div>
	
				</div> <!-- END id="PageOverlayContent" -->
			</div> <!-- END id="PageOveraly" -->
			<?php 
		} else {
			
			echo '<div id="PageWrapper">';
			
		} // end if get_theme_var('featuredContentActive') !== ''
			?>



		  <?php 
		  // setup the showcase
		  if (get_theme_var('showcaseColumns') !== '' && get_theme_var('showcaseColumns') !== 'off') {
		  	
			// get default settings
			parse_str(get_theme_var('showcaseColumns', 'showcase_left=true&showcase_right=true'), $showcaseAreas);
			$showcaseColumns = count($showcaseAreas);
			$showcaseClass1 = "two_third";
			
			// update 1st column class
			if ($showcaseColumns == 3) {
				$showcaseClass1 = "one_third";
			} elseif ($showcaseColumns == 1) {
				$showcaseClass1 = "";
			}
			?>
			
			<!-- Showcase Content -->
			<div id="Showcase">
				<div id="ShowcaseContent">
					<div class="contentArea">
						<div class="<?php echo $showcaseClass1 ?> showcase-area-left">
						  <?php 
							if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Home - Showcase Left')) : 
							echo '<h2 class="noMargin">Left Showcase</h2><p>Populate this area from the "Appearance &raquo; Widgets" section of your admin.</p>';
							endif; 
						  ?>
						</div>
						
						<?php 
						// Middle showcase column
						if ($showcaseColumns == 3) echo '<div class="one_third  showcase-area-middle">';
						if ( $showcaseColumns == 3 && (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Home - Showcase Middle')) ) : 
							echo '<h2 class="noMargin">Middle Showcase</h2><p>Populate this area from the "Appearance &raquo; Widgets" section of your admin.</p>';
						endif; 
						if ($showcaseColumns == 3) echo '</div>';
						?>
						
						<?php 
						// Middle showcase column
						if ($showcaseColumns >= 2) echo '<div class="one_third last  showcase-area-right">';
						if ( $showcaseColumns >= 2 && (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Home - Showcase Right')) ) : 
							echo '<h2 class="noMargin">Right Showcase</h2><p>Populate this area from the "Appearance &raquo; Widgets" section of your admin.</p>'; 
						endif; 
						if ($showcaseColumns >= 2) echo '</div>';
						?>

						<div class="clear"></div>
					</div> <!-- END class="contentArea" -->
				</div> <!-- END id="ShowcaseContent" -->
			</div> <!-- END id="Showcase" -->
			<?php
		  } // end if (showcaseColumns !== '') ?>


			<div id="MainPage">
				<div id="MainPageContent">
					<div class="contentArea">
		<?php
		
	} else { // else if is_home() - slide show and other home page only elements.

		// Logo (for sub-pages)
		if (get_theme_var('smallLogoImage')) {
			// if small logo provided, use it on the sub-pages
			$themeLogo = '<a href="'. get_bloginfo('url') .'" id="Logo" class="logoMedium"><img src="'. get_theme_var('smallLogoImage') .'" alt="'. get_bloginfo('name') .'" '. $logoPosition .' /></a>';
		}elseif (get_theme_var('logoImage') == "") {
			// No small logo, so if no large logo exists, set the skin default small logo (otherwise we can use the one already set for the large home page logo)
			$themeLogo = '<a href="'. get_bloginfo('url') .'" id="Logo" class="logoMedium"><img src="'. $themePath .'images/spacer.gif" class="skinLogo" alt="'. get_bloginfo('name') .'" '. $logoPosition .' /></a>';
		}
		?>

				<!-- Logo -->
				<div id="LogoHeader" class="subPageLogo" <?php echo $logoAlign; ?>>
					<?php echo $themeLogo; ?>
				</div>
		
				<div id="PageTop"></div>
				<div id="PageWrapper">
		
		<?php
	} // end if is_home() - slide show and other home page only elements.
	?>