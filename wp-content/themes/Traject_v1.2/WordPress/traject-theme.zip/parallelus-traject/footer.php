					<!-- End of Content -->
					<div class="clear"></div>
					
				</div> <!-- END class="contentArea" -->
			</div> <!-- END id="MainPageContent" -->
		</div> <!-- END id="MainPage" -->
		
		
	</div> <!-- END id="PageWrapper" -->


	<div id="FooterWrapper">
		<div id="Footer">
			<div id="FooterContent">
				
				<div class="contentArea">
	
					<?php 
					// setup the showcase
					if (get_theme_var('footerColumns') !== '') {
					
						// get default settings
						parse_str(get_theme_var('footerColumns', 'footer_left=true&footer_right=true'), $footerAreas);
						$footerColumns = count($footerAreas);
						$footerClass1 = "two_third";
						
						// update 1st column class
						if ($footerColumns == 3) {
							$footerClass1 = "one_third";
							$footerClass3 = "one_third";
						} elseif ($footerColumns == 1) {
							$footerClass1 = "";
						} elseif ($footerColumns == 2) {
							$footerClass1 = "half_page";
							$footerClass3 = "half_page";
						}
						?>
					
						<div class="<?php echo $footerClass1 ?> footer-area-left">
						  <?php 
							if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer - Left')) : 
							echo '<p><strong>Footer</strong> - Populate from "Appearance &raquo; Widgets"</p>';
							endif; 
						  ?>
						</div>
						
						<?php 
						// Middle showcase column
						if ($footerColumns == 3) echo '<div class="one_third  footer-area-middle">';
						if ( $footerColumns == 3 && (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer - Middle')) ) : 
							echo '<p><strong>Middle Footer</strong></p>';
						endif; 
						if ($footerColumns == 3) echo '</div>';
						?>
						
						<?php 
						// Middle showcase column
						if ($footerColumns >= 2) echo '<div class="'. $footerClass3 .' last  footer-area-right">';
						if ( $footerColumns >= 2 && (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer - Right')) ) : 
							echo '<p><strong>Right Footer</strong></p>'; 
						endif; 
						if ($footerColumns >= 2) echo '</div>';
					
					} // end if (footerColumns !== '') 
					
					?>
					
					<div class="clear"></div>
					
				</div> <!-- END class="contentArea" -->
				
			</div> <!-- END id="FooterContent" -->
		</div> <!-- END id="Footer" -->
	</div> <!-- END id="FooterWrapper" -->
	
</div> <!-- END id="Wrapper" -->

<?php
// Font Replacement
if (get_theme_var('fontReplacement', 1) != false) : ?>
	<!-- Activate Font Replacement (cufon) -->
	<script type="text/javascript"> Cufon.now(); </script>
	<?php 
endif; ?>

<?php echo stripslashes(get_theme_var('googleAnalytics')); ?>

<?php wp_footer(); ?>
</body>
</html>