<?php

$options = array (
	
	array(	"name" => "featured",
			"format" => "help"),

	array(	"name" => "&nbsp;",
			"format" => "title"),
			
	array(	"format" => "start",
			"title" => "Featured Content Options"),
			
		array(	"name" => "Show Featured Content",
				"desc" => "Include featured content section on the home page.",
				"id" => $shortname."featuredContentActive",
				"label" => "Enable",
				"default" => "1",
				"format" => "checkbox"),
		//Use image containers		
		array(	"name" => "Use Image Containers",
				"desc" => "Specify if the images should have the theme default containers which display a border and shadow. Images will be forded to the size \"160 * 108\" if activated.",
				"id" => $shortname."featuredContentImageContainers",
				"label" => "Enable",
				"default" => "1",
				"format" => "checkbox"),
		array(	"name" => "Resize Images",
				"desc" => "Specify if the images should be automatically resized using Timthumb.",
				"id" => $shortname."featuredContentImageResize",
				"label" => "Enable",
				"default" => "1",
				"format" => "checkbox"),
		//Items per page		
		array(	"name" => "Items per page",
				"desc" => "Select the number of posts to show in the Featured Content section. If \"Use Image Containers\" is selected above, this should be set to 5.",
				"id" => $shortname."featuredContentCount",
				"default" => "5",
				"options"=>array('1'=>'1','2'=>'2','3'=>'3','4'=>'4','5'=>'5 (default)','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10'),
				"format" => "select"),
		//Scroll per click
		array(	"name" => "Scroll per click",
				"desc" => "Select the number of posts to scroll on click in the Featured Content section.",
				"id" => $shortname."featuredContentScrollCount",
				"default" => "3",
				"options"=>array('1'=>'1','2'=>'2','3'=>'3','4'=>'4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10','11'=>'11','12'=>'12','13'=>'13','14'=>'14','15'=>'15'),
				"format" => "select"),

	array(	"format" => "end")
	
);

?>