<?php
#==================================================================
#
#	Sidebars and metaboxes for the theme
#
#==================================================================


#-----------------------------------------------------------------
# Sidebars (widget areas)
#-----------------------------------------------------------------


// Pre-configured sidebars
//................................................................

function theme_widgets_load() {
	register_sidebar( array(
		'name' =>  'Default Sidebar',
		'description' => 'The default widget area',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widgetTitle">',
		'after_title' => '</h3>',
	) );

	register_sidebar( array(
		'name' => 'Homepage Sidebar',
		'description' => 'Homepage sidebar area',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<h3 class="widgetTitle">',
		'after_title' => '</h3>',
	) );
	
	// Create Showcase Widget Areas	
	//................................................................
	if (get_theme_var('showcaseColumns') !== '' && get_theme_var('showcaseColumns') !== 'off') {
		parse_str(get_theme_var('showcaseColumns', 'showcase_left=true&showcase_right=true'), $widgetArea);
		
		if ($widgetArea['showcase_left'] == true) {
			register_sidebar(array(
				'name'=> 'Home - Showcase Left',
				'id' => 'showcase_left',
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<h1 class="title">',
				'after_title' => '</h1>'
			));
		}
		if ($widgetArea['showcase_middle'] == true) {
			register_sidebar(array(
				'name'=> 'Home - Showcase Middle',
				'id' => 'showcase_middle',
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<h1 class="title">',
				'after_title' => '</h1>'
			));	
		}
		if ($widgetArea['showcase_right'] == true) {
			register_sidebar(array(
				'name'=> 'Home - Showcase Right',
				'id' => 'showcase_right',
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<h1 class="title">',
				'after_title' => '</h1>'
			));	
		}
	} // end showcase widget area
	
	// Create Footer Widget Areas	
	//................................................................
	if (get_theme_var('footerColumns') !== '') {
		parse_str(get_theme_var('footerColumns', 'footer_left=true&footer_right=true'), $widgetArea);
		
		if ($widgetArea['footer_left'] == true) {
			register_sidebar(array(
				'name'=> 'Footer - Left',
				'id' => 'footer_left',
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<strong class="footerTitle">',
				'after_title' => '</strong>'
			));
		}
		if ($widgetArea['footer_middle'] == true) {
			register_sidebar(array(
				'name'=> 'Footer - Middle',
				'id' => 'footer_middle',
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<strong class="footerTitle">',
				'after_title' => '</strong>'
			));	
		}
		if ($widgetArea['footer_right'] == true) {
			register_sidebar(array(
				'name'=> 'Footer - Right',
				'id' => 'footer_right',
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<strong class="footerTitle">',
				'after_title' => '</strong>'
			));	
		}
	}	


}

// Register pre-configured sidebars using widgets_init
//................................................................

add_action( 'widgets_init', 'theme_widgets_load' );


// Dynamic sidebar generation
//................................................................

include_once('sidebar-generator.php');


#-----------------------------------------------------------------
# META BOXES
#-----------------------------------------------------------------

include_once('metaboxes.php');

?>