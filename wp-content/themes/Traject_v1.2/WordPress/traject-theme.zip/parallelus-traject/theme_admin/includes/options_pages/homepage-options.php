<?php

$options = array (

	array(	"name" => "homepage",
			"format" => "help"),

	array(	"name" => "Home Page",
			"format" => "title"),
			
	array(	"format" => "start",
			"title" => "Showcase"),
			
		array(	"name" => "Showcase Columns",
				"desc" => "Select the number of widget columns to use for the home page showcase area. This is the area that appears directly below the slide show and before the page content or side bar. To add content to this area add widget from the \"Appearance &raquo; Widgets\" section.",
				"id" => $shortname."showcaseColumns",
				"default" => "showcase_left=true&showcase_right=true",
				"options" => array(
					'off' => 'Hide Showcase Area', 
					'showcase_left=true' => '1 Column (full page)', 
					'showcase_left=true&showcase_right=true' => '2 Column (default)', 
					'showcase_left=true&showcase_middle=true&showcase_right=true' =>'3 Column'),
				"format" => "select"),
						
	array(	"format" => "end"),

	//Featured content
	array(	"format" => "start",
			"title" => "Featured Content"),
			
		array(	"name" => "Show Featured Content",
				"desc" => "Include featured content section on the home page.<br />Configure the featured content area from the <a href='admin.php?page=featured-options'>Featured Content</a> menu.",
				"id" => $shortname."featuredContentActive",
				"label" => "Enable",
				"default" => "1",
				"format" => "checkbox"),
		
	array(	"format" => "end"),
	
	//Home Page Content Starts 
	array(
			"format" => "start",
			"title" => "Home Page Content"),

			array(
				"name" => "Source",
				//"options"=>array('category'=>'Posts from Category','page'=>'Page','post'=>'Single Post'),
				"options"=>array('page'=>'Page','categories'=>'Post List'),
				"desc" => "Select a source for your home page content. ",
				"format"=>"radio",
				"id"=>$shortname."homeContentSource",
				"default" => "categories"),
			array(
				'name' => 'Select category',
				"desc" => "Select categories to use as the home page posts source.<br />(Ctrl+Click to select/deselect multiple categories, Mac users Option+Click)",
				'id' => $shortname.'homeContentCategory',
				'options' => $GLOBALS['categoryList'],
				'format' => 'multiselect'),
			array(
				'name' => 'Select Page',
				"desc" => "Select a page to use as the content source of the home page.",
				'id' => $shortname.'homeContentPage',
				'options' => $GLOBALS['pageList'],
				'format'=>'select'),
			array(
				'name' => 'Page Title',
				"id" => $shortname."homeContentPageTitle",
				"label" => "Show Page Title",
				"default" => "1",
				"format" => "checkbox"),
//			array(
//				'name' => 'Select Post',
//				'id' => $shortname.'homeContentPost',
//				'options' => $GLOBALS['postList'],
//				'format'=>'select' ),
			
	array(	"format" => "end")

);

$appendJs = '
<script type="text/javascript">
jQuery(document).ready(function($) {

	// setup show/hide home page source options
	var homeContentSource = $("input[name=\'traject_homeContentSource\']");
	var p = $("#traject_homeContentPage").parents("tr");
	var pT = $("#traject_homeContentPageTitle").parents("tr");
	var c = $("#traject_homeContentCategory").parents("tr");
	pHtml = p.html();
	pTHtml = pT.html();
	cHtml = c.html();

	// add click event for home content source
	homeContentSource.click( function() { 
		if (jQuery(this).val() == "page") {
			p.html(pHtml).css("visibility","visible");
			pT.html(pTHtml).css("visibility","visible");
		} else {
			p.html("").css("visibility","hidden");
			pT.html("").css("visibility","hidden");
		}
		(jQuery(this).val() == "categories") 	? c.html(cHtml).css("visibility","visible") : c.html("").css("visibility","hidden");
	});
	
	// trigger after load to initialize
	$(homeContentSource + ":checked:not([type=\'checkbox\'])").click();
	
});	
</script>
';

?>

