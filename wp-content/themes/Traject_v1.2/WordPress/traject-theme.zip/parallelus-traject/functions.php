<?php
#==================================================================
#
#	Admin control panel setup
#
#==================================================================


#-----------------------------------------------------------------
# Default theme variables and information
#-----------------------------------------------------------------

$themeInfo = get_theme_data(TEMPLATEPATH . '/style.css');
$themeVersion = trim($themeInfo['Version']);
$themeTitle= trim($themeInfo['Title']);
$shortname = strtolower(str_replace(" ","",$themeTitle)) . "_";


// set as constants
//................................................................

define('THEMENAME', $themeTitle);
define('THEMEVERSION', $themeVersion);

// shortcuts variables
//................................................................

$cssPath = get_bloginfo('stylesheet_directory') . "/";
$themePath = get_bloginfo('template_url') . "/";
$themeUrlArray = parse_url(get_bloginfo('template_url'));
$themeLocalUrl = $themeUrlArray['path'] . "/";

// setup info (category list, page list, etc)
//................................................................

$allCategories = get_categories('hide_empty=0');
$allPages = get_pages('hide_empty=0');
$pageList = array();
$categoryList = array();

// create category and page list arrays
//................................................................

foreach ($allPages as $thisPage) {
	$pageList[$thisPage->ID] = $thisPage->post_title;
	$pages_ids[] = $thisPage->ID;
}

foreach ($allCategories as $thisCategory) {
	$categoryList[$thisCategory->cat_ID] = $thisCategory->cat_name;
	$cats_ids[] = $thisCategory->cat_ID;
}


#-----------------------------------------------------------------
# Admin Menu Options
#-----------------------------------------------------------------

// include options functions
//................................................................

include_once('theme_admin/includes/option_functions.php');

// Menu structure
//................................................................

function this_theme_menu() {
	add_menu_page('Theme Options', THEMENAME, 10, 'theme-setup', 'loadOptionsPage', get_template_directory_uri().'/theme_admin/images/themePanelIcon.png');
	add_submenu_page('theme-setup', 'General Settings', 'General Options', 10, 'theme-setup', 'loadOptionsPage');
	add_submenu_page('theme-setup', 'Main Menu', 'Main Menu', 10, 'mainmenu-options', 'loadOptionsPage');
	add_submenu_page('theme-setup', 'Home Page', 'Home Page', 10,  'homepage-options', 'loadOptionsPage');
	add_submenu_page('theme-setup', 'Slideshow', 'Slideshow', 10, 'slideshow-options', 'loadOptionsPage');
	add_submenu_page('theme-setup', 'Featured Content', 'Featured Content', 10,  'featured-options', 'loadOptionsPage');
	add_submenu_page('theme-setup', 'Sidebar', 'Sidebar', 10, 'sidebar-options', 'loadOptionsPage');
	add_submenu_page('theme-setup', 'Blog', 'Blog Pages', 10, 'blog-options', 'loadOptionsPage');
	add_submenu_page('theme-setup', 'Portfolio', 'Portfolio Pages', 10, 'portfolio-options', 'loadOptionsPage');
	add_submenu_page('theme-setup', 'Contact Page', 'Contact Page', 10, 'contact-options', 'loadOptionsPage');
}
	
// Create menu
//................................................................

add_action('admin_menu','this_theme_menu');

// call and display the requested options page
//................................................................

function loadOptionsPage() {
	global $themeTitle,$shortname,$pageList,$categoryList,$wp_deprecated_widgets_callbacks;

	include_once('theme_admin/includes/options_pages/'. $_GET['page'] .'.php');
	
	$customOptionsPages = array('slideshow-options', 'mainmenu-options', 'blog-options', 'portfolio-options', 'featured-options', 'sidebar-options');
	
	if ( !in_array($_GET['page'], $customOptionsPages) ) {
		include_once("theme_admin/options.php");
	}
}



#-----------------------------------------------------------------
# Addon Functions and Content
#-----------------------------------------------------------------


// include custom functions
//................................................................

include_once("theme_admin/includes/addon-functions.php");

// include meta boxes and sidebar registrations
//................................................................

include_once("theme_admin/includes/sidebars-metaboxes.php");

// include widgets
#-----------------------------------------------------------------

include_once('theme_admin/includes/widgets.php');



?>