<?php
/*
Template Name: Left Sidebar
*/
get_header();
		// Get options for page
		//-----------------------------------------------------------
		
		// title
		$pageTitle = get_the_title();
		
		// breadcrumbs
		$hideBreadcrumbs = get_post_meta($post->ID, 'breadcrumbOff', true);
	
		// sub-title
		$subTitle = get_post_meta($post->ID, 'subTitle', true);
		
		// page icon
		$pageIcon = get_post_meta($post->ID, 'pageIcon', true);
		if ( $pageIcon == 'custom' ) {
			$pageIcon = '<img src="'. get_post_meta($post->ID, 'pageIcon_custom', true) .'" width="128" height="128" alt="'. $pageTitle .'" />';	// Custom
		} elseif ( $pageIcon == '' ) {
			$pageIcon = '<img src="'. $themePath .'images/icons/write.png" width="128" height="128" alt="'. $pageTitle .'" />';	// Default
		} else {
			$pageIcon = '<img src="'. $pageIcon .'" width="128" height="128" alt="'. $pageTitle .'" />';	// Selected Icon
		}
		?>

		<div id="PageOverlay">
			<div id="PageOverlayContent">
				<div class="contentArea">
					<h1 class="pageTitle"><?php echo $pageTitle; ?></h1>
					<div class="pageIcon"><?php echo $pageIcon;?></div>
				</div>
			</div>
		</div> <!-- END id="PageOveraly" -->

		<div id="Showcase">
			<div id="ShowcaseContent">
				<div class="contentArea">
					<h2 class="pageTagLine"><?php echo $subTitle; ?></h2>
				</div>
			</div>
		</div> <!-- END id="Showcase" -->
	
	
		<div id="MainPage">
			<div id="MainPageContent">
				<div class="contentArea">
					
				<?php 
				
				$leftSidebar = true;
				get_sidebar(); 
				
				if (have_posts()) : 
				while (have_posts()) : the_post();	
						
					?>
					
					<div class="two_third last">
						<div class="breadcrumbs" <?php  if ($hideBreadcrumbs) { echo 'style="background: none;"'; } ?>>
							<?php  if (!$hideBreadcrumbs) { show_breadcrumbs(); } ?>
						</div>

						<?php the_content('More Information...'); ?>
	
						<!-- Extras -->
						<div class="postFooter">
							<?php edit_post_link('Edit','<p class="postEdit">','</p>'); ?>
						</div>
	
						<!-- End of Content -->
						<div class="clear"></div>
	
					</div> <!-- end  <div class="two-thirds"> -->	
					<?php 
					
				endwhile; 
				endif; 
				?>

<?php get_footer(); ?>