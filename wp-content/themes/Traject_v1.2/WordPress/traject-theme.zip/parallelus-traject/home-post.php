<?php get_header();

	// Display content of single post
	query_posts(array( 'p' => get_theme_var('homeContentPost') ));
	
	?>
	<div <?php if(is_active_sidebar(2)) : ?>class="two_third"<?php endif; ?>>
		<?php 
		if ( have_posts() ) : 
			while ( have_posts() ) : the_post();
				?>
				
				<h2 class="title"><?php the_title(); ?></h2>
				<div class="hr"></div>
				
				<?php
				the_content('More Information...'); 
				
			endwhile; 
		endif; // End while have_posts() ?>

		<!-- Extras -->
		<div class="postFooter">
			<?php edit_post_link('Edit','<p class="postEdit">','</p>'); ?>
		</div>
		
		<!-- End of Content -->
		<div class="clear"></div>
	
		<?php get_pagination(); ?>
		
	</div> <!-- end  <div class="two-thirds"> -->

	<?php if(is_active_sidebar(2)) : ?>
		<div class="one_third last">
			<div class="sidebar">
				<div class="sidebarBox-1">
					<div class="sidebarBox-2">
		
						<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage Sidebar')) : endif; ?>
		
					</div>
				</div>
			</div> <!-- END class="sidebar" -->
			
		</div>
		
		<!-- End of Content -->
		<div class="clear"></div>
	<?php endif; ?>
	
	<?php


// reset query
wp_reset_query();

// include WP footer
get_footer(); ?>
